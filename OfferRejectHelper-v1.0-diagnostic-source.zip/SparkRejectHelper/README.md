# Cheese 1.1 Diagnostic

Diagnostic continuation of the working v0.9 helper.

## Changes from v0.9

- No hard-coded Grand Blanc or Burton store switches.
- Stores are added manually by store number.
- Every saved store has its own ON/OFF switch and Remove button.
- Existing v0.9 automatic reject/check-only behavior is preserved.
- Adds a privacy-filtered Accessibility diagnostic snapshot so the next scanner version can be built against Spark's actual node tree instead of screenshots alone.
- Diagnostic captures structural node information, decision-relevant values/tags and scrollability while redacting unrelated text such as names and addresses.
- Accessibility service remains limited to `com.walmart.sparkdriver` and the app declares no Internet permission.

## Test workflow

1. Install the diagnostic build and enable Cheese in Android Accessibility settings.
2. Keep **Accessibility diagnostic mode** ON.
3. For safest testing, keep **Automatically reject by store and pay** OFF until the diagnostic is verified.
4. Open Spark and visit, one at a time:
   - fully expanded main offer list,
   - a single offer detail/drop-off screen,
   - an individual product list.
5. Return to Cheese after each screen and capture the **Last Accessibility diagnostic** text.

## Build

Requires Android SDK platform 35 and build-tools 35.0.0. Either open in Android Studio or set `ANDROID_HOME` and run `./build-local.sh`.


## Cheese 1.1 Shopping rule
- Adds an adjustable minimum dollars-per-item setting for Shopping orders only.
- Default: $1.00 per item.
- Uses item count, not total quantity (qty).
- Non-Shopping offers ignore this rule.
- When automatic mode is enabled and a Shopping card passes the store and $/mile checks, Cheese opens the offer details to read the item count before deciding whether to reject.
