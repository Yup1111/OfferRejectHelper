# Current scan-only repair

- Scan-only reads/scrolls the list and never opens Shopping details or clicks offer buttons.
- One scheduled scan callback preserves settling delays; drawer status logs only on transition.
- Return to a selected offer requires its header to be visible, not just its Reject button.
- Unreadable/stalled scans pause for 30 seconds; a scan times out after 45 seconds without claiming completion.
- Detail pay/mileage must match a recent offer opened from the list with the same store; otherwise the rating is UNKNOWN and no automatic decision is allowed. This deliberately requires manual review when total trip mileage cannot be verified.
- Screenshot capability is declared for the existing optional local screenshot feature (Android 11+). Screenshots can contain private customer information; they are not uploaded automatically.
- Debug reports include installed version/build. Actions supplies a new version code and uses the required permanent signing secret.
- Live Spark scrolling still needs device testing. No heavy-item or ranking expansion is included in this repair.

## Regression checks

The Actions workflow runs the three Java check programs in `checks/` before building the APK. DecisionCheck includes the reported 5-mile versus 0.1-mile mismatch, stale context, changed pay, and matching values.

## Historical notes (older version labels below are historical)

# Cheese 1.5 Diagnostic

Diagnostic continuation of the working v0.9 helper.

## Changes from v0.9

- No hard-coded Grand Blanc or Burton store switches.
- Stores are added manually by store number.
- Every saved store has its own ON/OFF switch and Remove button.
- Existing v0.9 automatic reject/check-only behavior is preserved.
- Adds a privacy-filtered Accessibility diagnostic snapshot so the next scanner version can be built against Spark's actual node tree instead of screenshots alone.
- Diagnostic captures structural node information, decision-relevant values/tags and scrollability while redacting unrelated text such as names and addresses.
- Accessibility service remains limited to `com.walmart.sparkdriver` and the app declares no Internet permission.

## Test workflow

1. Install the diagnostic build and enable Cheese in Android Accessibility settings.
2. Keep **Accessibility diagnostic mode** ON.
3. For safest testing, keep **Automatically reject by store and pay** OFF until the diagnostic is verified.
4. Open Spark and visit, one at a time:
   - fully expanded main offer list,
   - a single offer detail/drop-off screen,
   - an individual product list.
5. Return to Cheese after each screen and capture the **Last Accessibility diagnostic** text.

## Build

Requires Android SDK platform 35 and build-tools 35.0.0. Either open in Android Studio or set `ANDROID_HOME` and run `./build-local.sh`.


## Cheese 1.1 Shopping rule
- Adds an adjustable minimum dollars-per-item setting for Shopping orders only.
- Default: $1.00 per item.
- Uses item count, not total quantity (qty).
- Non-Shopping offers ignore this rule.
- When automatic mode is enabled and a Shopping card passes the store and $/mile checks, Cheese opens the offer details to read the item count before deciding whether to reject.


## Cheese 1.2 automation behavior
- Store switches are now a reject list: ON = auto-reject this store; OFF/unlisted = no store-based rejection.
- Shopping-only minimum $/item stays adjustable, default $1.00/item, using item count rather than qty.
- In automatic mode, a Shopping offer that passes the immediate store and $/mile checks is opened automatically when item count is missing on the offer card.
- On the Shopping detail screen Cheese reads item count and rejects there if pay/items is below the configured minimum.
- Non-Shopping offers never use the $/item rule.


## Cheese 1.2 pay parsing fix
- On opened Spark offer details, uses `estimatedValueView` as the total offer pay.
- Ignores separate delivery/surge/tip dollar components when deciding the Shopping $/item rule.


## Cheese 1.3 detail-screen parsing fix
- Position-based parsing now labels Spark's `estimatedValueView` as total offer pay.
- This fixes Shopping detail screens where total pay appears beside separate base-pay/tip amounts.

## Cheese 1.4 Offer Unavailable handling
- Diagnostics now preserve the exact safe phrase `Offer Unavailable` and classify that popup explicitly.
- Automatic mode dismisses the popup only when the exact phrase is present and a unique visible/clickable `gotItButton` is found.
- No guessing from title length, popup shape, or unrelated `ACCEPT` text.

## Cheese 1.5 Shopping-card opener fix
- Fixes a case where a Shopping offer was recognized and marked `open details to check`, but Cheese could not locate the card body to tap.
- Cheese now pairs the visible Reject button with the nearest clickable offer body above it, so it can open the correct Shopping card even when another offer is partly visible below.

## Cheese 1.6 ranking + overlay
- Reads every currently accessible offer card before acting and ranks candidates by dollars per mile, highest first.
- Protects the best valid offer: it will not waste time opening/rejecting worse offers while a better candidate is present.
- If the best candidate is Shopping and item count is missing, Cheese opens that specific card first and checks the configured dollars-per-item rule.
- Carries the exact store number from the list card into the opened Shopping detail screen when pay and miles match, fixing detail screens that omit/conflict on store text.
- Adds an Accessibility overlay over Spark showing the best offer and DECLINE / CLOSE / ACCEPT controls.
- CLOSE hides the overlay for the current offer and does not touch Spark.
- Bulky/heavy offers show BROKE BACK ALERT in the overlay.
- Existing exact Offer Unavailable handling and safe Got it dismissal are retained.


## Cheese 1.7 full-list scan
- Automatically scrolls Spark's offer RecyclerView from the current position to the bottom so every materialized offer card is actually inspected.
- Deduplicates repeated cards while scrolling.
- Ranks all readable passing offers by $/mile only after the full list has been checked.
- Scrolls back to the globally best candidate before opening Shopping details or showing the decision overlay.
- Overlay says `BEST OFFER — FULL LIST CHECKED` when the selected card came from a completed scan.


## Cheese 2.0 live-list scan fix
- Detects Spark notices that offers disappeared while a scan is running.
- Cancels the stale scan instead of treating a transient RecyclerView redraw as the bottom.
- Waits briefly for Spark to settle, then restarts from the top against the current offer list.
- No hard page/card limit.
- Final overlay now says `BOTTOM CONFIRMED` only after the current list passes the end-of-list checks.
- If the selected best offer disappears while Cheese is returning to it, Cheese rescans rather than acting on stale data.


## Cheese 2.1
- Manual touch takes priority: touching Spark pauses Cheese immediately; it resumes 2 seconds after touch ends.
- Overlay DECLINE now completes Spark's second Reject Offer confirmation even when the user manually declines an otherwise-good offer.
- Bottom-of-list confirmation now requires the final offer card to be fully exposed with visible space below it.
- Android versionCode/versionName are now 21 / 2.1-diagnostic.
