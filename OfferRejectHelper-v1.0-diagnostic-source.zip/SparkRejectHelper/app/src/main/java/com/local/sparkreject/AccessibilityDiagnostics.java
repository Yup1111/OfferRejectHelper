package com.local.sparkreject;

import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Privacy-filtered snapshot of the Spark Accessibility tree for development/testing. */
public final class AccessibilityDiagnostics {
    private static final int MAX_LINES = 140;
    private static final int MAX_CHARS = 14000;
    private static final Pattern MONEY = Pattern.compile("\\$\\s*[0-9]{1,4}(?:\\.[0-9]{1,2})?");
    private static final Pattern MILES = Pattern.compile("(?i)\\b[0-9]{1,3}(?:\\.[0-9]{1,2})?\\s*(?:mi|miles?)\\b");
    private static final Pattern ITEMS = Pattern.compile("(?i)\\b[0-9]{1,4}\\s+items?(?:\\s*\\(\\s*[0-9]{1,4}\\s+qty\\s*\\))?");
    private static final Pattern QTY = Pattern.compile("(?i)\\bqty\\s*:?\\s*[0-9]{1,4}\\b");
    private static final Pattern STOPS = Pattern.compile("(?i)\\b[0-9]{1,3}\\s+(?:stops?|drop-?offs?)\\b");
    private static final Pattern STORE = Pattern.compile("(?i)(?:walmart|sam['’]?s(?:\\s+club)?)?[^#\\n]{0,60}#\\s*[0-9]{1,5}");

    private AccessibilityDiagnostics() {}

    public static String snapshot(AccessibilityNodeInfo root) {
        if (root == null) return "No readable Spark root.";
        Stats stats = new Stats();
        StringBuilder body = new StringBuilder();
        walk(root, 0, stats, body);
        StringBuilder out = new StringBuilder();
        out.append("Screen: ").append(classify(stats)).append('\n');
        out.append("Nodes: ").append(stats.nodes)
                .append(" | visible: ").append(stats.visible)
                .append(" | clickable: ").append(stats.clickable)
                .append(" | scrollable: ").append(stats.scrollable).append('\n');
        out.append("Buttons: Reject=").append(stats.reject)
                .append(" Accept=").append(stats.accept)
                .append(" Reject Offer=").append(stats.confirm)
                .append(" Keep Offer=").append(stats.keep).append('\n');
        if (!stats.tags.isEmpty()) out.append("Detected: ").append(String.join(" | ", stats.tags)).append('\n');
        out.append("--- accessibility nodes ---\n");
        out.append(body);
        if (stats.truncated) out.append("\n…diagnostic truncated…");
        return out.toString();
    }

    private static void walk(AccessibilityNodeInfo node, int depth, Stats stats, StringBuilder out) {
        if (node == null || stats.lines >= MAX_LINES || out.length() >= MAX_CHARS) {
            stats.truncated = true;
            return;
        }
        stats.nodes++;
        boolean visible = node.isVisibleToUser();
        if (visible) stats.visible++;
        if (node.isClickable()) stats.clickable++;
        if (node.isScrollable()) stats.scrollable++;

        String raw = combine(node.getText(), node.getContentDescription());
        String normalized = raw.toLowerCase(Locale.US).replaceAll("\\s+", " ").trim();
        countButtons(normalized, stats);
        collectTags(raw, stats.tags);

        String safe = sanitize(raw);
        String viewId = node.getViewIdResourceName();
        boolean structural = node.isClickable() || node.isScrollable() || (viewId != null && !viewId.isEmpty());
        if (visible && (!safe.isEmpty() || structural)) {
            Rect r = new Rect();
            node.getBoundsInScreen(r);
            String cls = node.getClassName() == null ? "?" : simpleName(node.getClassName().toString());
            out.append(String.format(Locale.US, "%02d %s [%d,%d-%d,%d] %s%s%s%s",
                    depth, cls, r.left, r.top, r.right, r.bottom,
                    node.isClickable() ? "C" : "-",
                    node.isScrollable() ? "S" : "-",
                    node.isEnabled() ? "E" : "-",
                    node.isVisibleToUser() ? "V" : "-"));
            if (viewId != null && !viewId.isEmpty()) out.append(" id=").append(shortId(viewId));
            if (!safe.isEmpty()) out.append(" text=").append(safe);
            out.append('\n');
            stats.lines++;
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            if (stats.lines >= MAX_LINES || out.length() >= MAX_CHARS) { stats.truncated = true; break; }
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) walk(child, depth + 1, stats, out);
        }
    }

    private static void countButtons(String normalized, Stats s) {
        if (normalized.equals("reject") || normalized.equals("decline")) s.reject++;
        else if (normalized.equals("accept")) s.accept++;
        else if (normalized.equals("reject offer")) s.confirm++;
        else if (normalized.equals("keep offer")) s.keep++;
        if (normalized.contains("are you sure you want to reject this offer")) s.rejectDialog = true;
        if (normalized.matches(".*\\bqty\\s*:?\\s*[0-9]+.*")) s.hasQty = true;
        if (normalized.contains("shopping")) s.hasShopping = true;
        if (normalized.contains("pickup")) s.hasPickup = true;
        if (normalized.contains("offer unavailable")) s.offerUnavailable = true;
    }

    private static void collectTags(String raw, Set<String> tags) {
        if (raw == null || raw.isEmpty()) return;
        String s = raw.toLowerCase(Locale.US);
        addIf(s, tags, "40–50 lb", "40–50 lb item", "40-50 lb item", "40 - 50 lb item");
        addIf(s, tags, "Bulky", "bulky item");
        addIf(s, tags, "Apartment", "apartment");
        addIf(s, tags, "House", "house");
        addIf(s, tags, "Shopping", "shopping");
        addIf(s, tags, "Pickup", "pickup");
        addIf(s, tags, "Pharmacy", "pharmacy");
        addIf(s, tags, "Alcohol", "alcohol");
        addIf(s, tags, "Perishable", "perishable");
        addIf(s, tags, "WATER keyword", "water");
    }

    private static void addIf(String s, Set<String> tags, String label, String... needles) {
        for (String n : needles) if (s.contains(n)) { tags.add(label); return; }
    }

    /** Keep decision-relevant tokens; hide customer names, addresses and unrelated product text. */
    static String sanitize(String raw) {
        if (raw == null) return "";
        String s = raw.replace('\n', ' ').replaceAll("\\s+", " ").trim();
        if (s.isEmpty()) return "";
        List<String> tokens = new ArrayList<>();
        extract(MONEY, s, tokens);
        extract(MILES, s, tokens);
        extract(ITEMS, s, tokens);
        extract(QTY, s, tokens);
        extract(STOPS, s, tokens);
        extract(STORE, s, tokens);
        String low = s.toLowerCase(Locale.US);
        keyword(low, tokens, "REJECT", "reject");
        keyword(low, tokens, "ACCEPT", "accept");
        keyword(low, tokens, "KEEP OFFER", "keep offer");
        keyword(low, tokens, "Shopping", "shopping");
        keyword(low, tokens, "Pickup", "pickup");
        keyword(low, tokens, "40-50 lb item", "40–50 lb item", "40-50 lb item", "40 - 50 lb item");
        keyword(low, tokens, "Bulky item", "bulky item");
        keyword(low, tokens, "Apartment", "apartment");
        keyword(low, tokens, "House", "house");
        keyword(low, tokens, "Pharmacy", "pharmacy");
        keyword(low, tokens, "Alcohol", "alcohol");
        keyword(low, tokens, "Perishable", "perishable");
        keyword(low, tokens, "WATER", "water");
        keyword(low, tokens, "dog food", "dog food");
        keyword(low, tokens, "cat litter", "cat litter");
        keyword(low, tokens, "estimated shopping time", "estimated shopping time");
        keyword(low, tokens, "Offer Unavailable", "offer unavailable");
        keyword(low, tokens, "Got it", "got it");
        if (low.contains("are you sure you want to reject this offer")) tokens.add("reject confirmation text");
        if (tokens.isEmpty()) return "<redacted text len=" + s.length() + ">";
        return String.join(" | ", new LinkedHashSet<>(tokens));
    }

    private static void extract(Pattern p, String s, List<String> out) {
        Matcher m = p.matcher(s);
        while (m.find()) out.add(m.group().trim());
    }

    private static void keyword(String low, List<String> out, String label, String... needles) {
        for (String needle : needles) if (low.contains(needle.toLowerCase(Locale.US))) { out.add(label); return; }
    }

    private static String combine(CharSequence text, CharSequence description) {
        String a = text == null ? "" : text.toString();
        String b = description == null ? "" : description.toString();
        if (b.isEmpty() || b.equals(a)) return a;
        if (a.isEmpty()) return b;
        return a + " | " + b;
    }

    private static String classify(Stats s) {
        if (s.offerUnavailable) return "OFFER_UNAVAILABLE";
        if (s.rejectDialog || (s.confirm == 1 && s.keep == 1)) return "REJECT_CONFIRMATION";
        if (s.hasQty && s.accept == 0 && s.reject == 0) return "PRODUCT_LIST_OR_ITEM_VIEW";
        if (s.reject == 1 && s.accept == 1) return "SINGLE_OFFER_DETAIL_OR_CARD";
        if (s.reject > 1 && s.accept > 1) return "MAIN_OFFER_LIST";
        if (s.hasShopping || s.hasPickup) return "SPARK_OTHER_OFFER_SCREEN";
        return "UNKNOWN_SPARK_SCREEN";
    }

    private static String simpleName(String name) {
        int p = name.lastIndexOf('.');
        return p >= 0 ? name.substring(p + 1) : name;
    }

    private static String shortId(String id) {
        int slash = id.lastIndexOf('/');
        return slash >= 0 ? id.substring(slash + 1) : id;
    }

    private static final class Stats {
        int nodes, visible, clickable, scrollable, lines;
        int reject, accept, confirm, keep;
        boolean rejectDialog, hasQty, hasShopping, hasPickup, offerUnavailable, truncated;
        final Set<String> tags = new LinkedHashSet<>();
    }
}
