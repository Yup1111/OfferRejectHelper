package com.local.sparkreject;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.File;
import java.io.FileNotFoundException;

/** Read-only export of a user-requested local screenshot, no external write access. */
public final class DebugScreenshotProvider extends ContentProvider {
    @Override public boolean onCreate() { return true; }
    @Override public String getType(Uri uri) { return "image/png"; }
    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        MatrixCursor c = new MatrixCursor(new String[]{"_display_name", "_size"});
        File file = new File(getContext().getFilesDir(), "cheese-debug-screen.png");
        if ("/screenshot".equals(uri.getPath()) && file.isFile())
            c.addRow(new Object[]{"cheese-debug-screen.png", file.length()});
        return c;
    }
    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"/screenshot".equals(uri.getPath()) || !"r".equals(mode))
            throw new FileNotFoundException("Unsupported screenshot operation");
        return ParcelFileDescriptor.open(new File(getContext().getFilesDir(), "cheese-debug-screen.png"),
                ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String where, String[] args) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String where, String[] args) { throw new UnsupportedOperationException(); }
}