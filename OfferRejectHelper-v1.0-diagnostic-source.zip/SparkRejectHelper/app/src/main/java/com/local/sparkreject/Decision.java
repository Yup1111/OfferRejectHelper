package com.local.sparkreject;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pure parsing/decision logic. A missing or conflicting field always yields UNKNOWN. */
public final class Decision {
    private static final Pattern MONEY = Pattern.compile("\\$\\s*([0-9]{1,4}(?:\\.[0-9]{1,2})?)");
    private static final Pattern MILES = Pattern.compile("(?<![0-9.])([0-9]{1,3}(?:\\.[0-9]{1,2})?)\\s*(?:mi\\b|miles?\\b)", Pattern.CASE_INSENSITIVE);
    private static final Pattern PAY_LABEL = Pattern.compile("(?i)(?:estimated|total|offer|trip)\\s*(?:earnings?|pay)|earnings?\\s*(?:estimate|total)");
    private static final Pattern DIST_LABEL = Pattern.compile("(?i)(?:trip|total|delivery|offer)\\s*(?:distance|mileage|miles)");
    private static final Pattern STOPS = Pattern.compile("(?i)\\b[0-9]+\\s+stops?\\b");
    private static final Pattern ITEMS = Pattern.compile("(?i)\\b([0-9]{1,4})\\s+items?(?:\\s*\\(\\s*[0-9]{1,4}\\s+qty\\s*\\))?");
    private static final Pattern SHOPPING = Pattern.compile("(?i)(?:^|\\b)shopping(?:\\b|$)");

    public enum Result { REJECT, KEEP, UNKNOWN }
    public final Result result;
    public final String explanation;
    public final BigDecimal pay, miles, perMile;

    private Decision(Result result, String explanation, BigDecimal pay, BigDecimal miles) {
        this.result = result;
        this.explanation = explanation;
        this.pay = pay; this.miles = miles;
        this.perMile = pay != null && miles != null && miles.signum() > 0
                ? pay.divide(miles, 2, RoundingMode.HALF_UP) : null;
    }

    public static Decision evaluate(List<String> fields, BigDecimal minimum) {
        List<BigDecimal> pays = new ArrayList<>(), distances = new ArrayList<>();
        for (String raw : fields) {
            String s = raw.trim().replace('\n', ' ');
            if (PAY_LABEL.matcher(s).find()) collect(MONEY.matcher(s), pays);
            if (DIST_LABEL.matcher(s).find()) collect(MILES.matcher(s), distances);
        }
        // Spark layouts sometimes place a single value in the next separate text node.
        for (int i = 0; i + 1 < fields.size(); i++) {
            String label = fields.get(i).trim(), next = fields.get(i + 1).trim();
            if (PAY_LABEL.matcher(label).find() && !MONEY.matcher(label).find() && MONEY.matcher(next).matches())
                collect(MONEY.matcher(next), pays);
            if (DIST_LABEL.matcher(label).find() && !MILES.matcher(label).find() && MILES.matcher(next).matches())
                collect(MILES.matcher(next), distances);
        }
        // The observed Spark card has a standalone total ($37.88) and a summary
        // such as "9 stops · 26.3 miles · 1 hr, 24 mins" with no field labels.
        // Use these only if each is unique. A tip like "$8.67 estimated tip"
        // is not a standalone amount and is never used as the total.
        if (pays.isEmpty()) {
            for (String raw : fields) {
                String s = raw.trim();
                if (MONEY.matcher(s).matches()) collect(MONEY.matcher(s), pays);
            }
        }
        // Within an isolated offer, stops and mileage can be separate accessibility
        // fields and the mileage field can also contain bullets or duration text.
        // Collect every distance in that scope so competing distances remain UNKNOWN.
        if (fields.stream().anyMatch(s -> STOPS.matcher(s).find())) {
            for (String raw : fields) collect(MILES.matcher(raw), distances);
        }
        BigDecimal pay = unique(pays), miles = unique(distances);
        if (pay == null || miles == null || miles.signum() <= 0 || minimum == null || minimum.signum() <= 0)
            return new Decision(Result.UNKNOWN, "Could not identify one offer total and one trip distance", pay, miles);
        int comparison = pay.compareTo(minimum.multiply(miles));
        return new Decision(comparison < 0 ? Result.REJECT : Result.KEEP,
                comparison < 0 ? "Below minimum $/mile" : "At or above minimum $/mile", pay, miles);
    }


    /** Fail closed when detail mileage cannot be tied to a recent list selection. */
    public static Decision verifyDetail(Decision detail, BigDecimal listPay,
            BigDecimal listMiles, boolean recentMatchingStore) {
        if (recentMatchingStore && listPay != null && listMiles != null
                && detail.pay != null && detail.miles != null
                && listPay.compareTo(detail.pay) == 0
                && listMiles.compareTo(detail.miles) == 0) return detail;
        return new Decision(Result.UNKNOWN,
                "Detail pay/distance does not match a recent verified list offer",
                detail.pay, null);
    }

    public static boolean isShopping(List<String> fields) {
        for (String raw : fields) if (SHOPPING.matcher(raw).find()) return true;
        return false;
    }

    public static Integer itemCount(List<String> fields) {
        Integer found = null;
        for (String raw : fields) {
            Matcher m = ITEMS.matcher(raw);
            while (m.find()) {
                int value = Integer.parseInt(m.group(1));
                if (found != null && found != value) return null;
                found = value;
            }
        }
        return found;
    }

    public static BigDecimal dollarsPerItem(BigDecimal pay, Integer items) {
        if (pay == null || items == null || items <= 0) return null;
        return pay.divide(new BigDecimal(items), 2, RoundingMode.HALF_UP);
    }

    /** Only numeric offer tokens and counts; never addresses or customer text. */
    public static String diagnostic(List<String> fields, BigDecimal minimum) {
        java.util.Set<String> money = new java.util.LinkedHashSet<>();
        java.util.Set<String> miles = new java.util.LinkedHashSet<>();
        int standaloneMoney = 0, stops = 0;
        for (String raw : fields) {
            Matcher m = MONEY.matcher(raw);
            while (m.find()) money.add(m.group(1));
            m = MILES.matcher(raw);
            while (m.find()) miles.add(m.group(1));
            if (MONEY.matcher(raw.trim()).matches()) standaloneMoney++;
            if (STOPS.matcher(raw).find()) stops++;
        }
        Decision d = evaluate(fields, minimum);
        return "texts=" + fields.size() + ", dollar values=" + money + ", mile values=" + miles
                + ", standalone pay=" + standaloneMoney + ", stop summaries=" + stops
                + ", parsed pay=" + d.pay + ", parsed miles=" + d.miles;
    }

    private static void collect(Matcher matcher, List<BigDecimal> values) {
        while (matcher.find()) values.add(new BigDecimal(matcher.group(1)));
    }
    private static BigDecimal unique(List<BigDecimal> values) {
        if (values.isEmpty()) return null;
        BigDecimal first = values.get(0);
        for (BigDecimal v : values) if (v.compareTo(first) != 0) return null;
        return first;
    }
}
