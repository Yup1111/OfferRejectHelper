package com.local.sparkreject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ScrollView;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import android.text.InputType;
import java.math.BigDecimal;

public final class MainActivity extends Activity {
    static final String PREFS = "rules";
    static final String ENABLED = "enabled";
    static final String OBSERVE = "observe";
    static final String DIAGNOSTIC = "diagnostic";
    static final String MINIMUM = "minimum";
    static final String SHOPPING_DOLLARS_PER_ITEM = "shopping_dollars_per_item";
    static final String LAST = "last";
    static final String LAST_DIAGNOSTIC = "last_diagnostic";
    static final String ALLOWED_STORES = "allowed_stores"; // legacy v1.1 key; no longer used for decisions
    static final String REJECT_STORES = "reject_stores";
    static final String LISTED_STORES = "listed_stores";

    /** No store is hard-coded in 1.0. Stores exist only after the user adds them. */
    static Set<String> defaultAllowed() { return new HashSet<>(); }

    private LinearLayout storeRows;
    private TextView status;
    private TextView serviceStatus;
    private TextView diagnosticStatus;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32, 44, 32, 32);
        box.setBackgroundColor(Color.WHITE);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        setContentView(scroll);

        box.addView(line("Cheese 2.0 Diagnostic", 27));
        box.addView(line("Diagnostic build based on v0.9. It keeps the existing reject logic, removes permanent store presets, and records a privacy-filtered view of what Android Accessibility can see inside Spark.", 17));

        Switch diagnostic = new Switch(this);
        diagnostic.setText("Accessibility diagnostic mode");
        diagnostic.setTextSize(18);
        diagnostic.setChecked(getPreferences().getBoolean(DIAGNOSTIC, true));
        box.addView(diagnostic);
        diagnostic.setOnCheckedChangeListener((button, checked) -> getPreferences().edit().putBoolean(DIAGNOSTIC, checked).apply());
        box.addView(line("Leave this ON while we test. Open Spark, visit the offer list/detail/item screens, then return here to see the last Accessibility snapshot. Names and addresses are not saved in the diagnostic.", 15));

        Switch observe = new Switch(this);
        observe.setText("Show offer checks (automatic rejection overrides this)");
        observe.setTextSize(18);
        observe.setChecked(getPreferences().getBoolean(OBSERVE, true));
        box.addView(observe);
        observe.setOnCheckedChangeListener((button, checked) -> getPreferences().edit().putBoolean(OBSERVE, checked).apply());

        Switch enabled = new Switch(this);
        enabled.setText("Automatically reject by store, pay, and Shopping $/item");
        enabled.setTextSize(18);
        enabled.setChecked(getPreferences().getBoolean(ENABLED, false));
        box.addView(enabled);
        enabled.setOnCheckedChangeListener((button, checked) -> getPreferences().edit().putBoolean(ENABLED, checked).apply());

        box.addView(line("Minimum dollars per mile", 18));
        EditText minimum = new EditText(this);
        minimum.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        minimum.setSingleLine(true);
        minimum.setText(getPreferences().getString(MINIMUM, "2.00"));
        box.addView(minimum);
        Button save = new Button(this);
        save.setText("Save threshold");
        box.addView(save);
        save.setOnClickListener(v -> {
            try {
                BigDecimal value = new BigDecimal(minimum.getText().toString());
                if (value.signum() <= 0 || value.compareTo(new BigDecimal("20")) > 0) throw new NumberFormatException();
                getPreferences().edit().putString(MINIMUM, value.toPlainString()).apply();
                status.setText("Saved. Last result: " + getPreferences().getString(LAST, "none yet"));
            } catch (NumberFormatException e) {
                status.setText("Enter a dollar amount above 0 and no more than 20.");
            }
        });

        box.addView(line("Minimum dollars per item (Shopping orders only)", 18));
        EditText shoppingPerItem = new EditText(this);
        shoppingPerItem.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        shoppingPerItem.setSingleLine(true);
        shoppingPerItem.setText(getPreferences().getString(SHOPPING_DOLLARS_PER_ITEM, "1.00"));
        box.addView(shoppingPerItem);
        box.addView(line("Only the item count is used, not total quantity (qty). Non-Shopping offers ignore this setting.", 15));
        Button saveShopping = new Button(this);
        saveShopping.setText("Save Shopping threshold");
        box.addView(saveShopping);
        saveShopping.setOnClickListener(v -> {
            try {
                BigDecimal value = new BigDecimal(shoppingPerItem.getText().toString());
                if (value.signum() <= 0 || value.compareTo(new BigDecimal("50")) > 0) throw new NumberFormatException();
                getPreferences().edit().putString(SHOPPING_DOLLARS_PER_ITEM, value.toPlainString()).apply();
                status.setText("Saved Shopping minimum: $" + value.toPlainString() + " per item. Last result: " + getPreferences().getString(LAST, "none yet"));
            } catch (NumberFormatException e) {
                status.setText("Enter a Shopping dollars-per-item amount above 0 and no more than 50.");
            }
        });

        box.addView(line("Stores to auto-reject", 20));
        box.addView(line("Add a store by number. ON means automatically reject that store. OFF means the store is not rejected just because of its store number. Stores not listed are evaluated normally by your other rules.", 15));
        storeRows = new LinearLayout(this);
        storeRows.setOrientation(LinearLayout.VERTICAL);
        box.addView(storeRows);
        refreshStores();

        EditText storeNumber = new EditText(this);
        storeNumber.setHint("Store number, e.g. 3726");
        storeNumber.setInputType(InputType.TYPE_CLASS_NUMBER);
        storeNumber.setSingleLine(true);
        box.addView(storeNumber);
        Button addStore = new Button(this);
        addStore.setText("Add store (starts OFF)");
        box.addView(addStore);
        addStore.setOnClickListener(v -> {
            String raw = storeNumber.getText().toString().trim();
            if (!raw.matches("[0-9]{1,5}") || Integer.parseInt(raw) == 0) {
                storeNumber.setError("Enter a store number");
                return;
            }
            String id = Integer.toString(Integer.parseInt(raw));
            Set<String> listed = listedStores();
            listed.add(id);
            getPreferences().edit().putStringSet(LISTED_STORES, listed).apply();
            storeNumber.setText("");
            refreshStores();
        });

        Button settings = new Button(this);
        settings.setText("Open Accessibility settings");
        box.addView(settings);
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        serviceStatus = line("Accessibility service: checking", 16);
        box.addView(serviceStatus);
        status = line("Last result: " + getPreferences().getString(LAST, "none yet"), 16);
        box.addView(status);

        box.addView(line("Last Accessibility diagnostic", 20));
        diagnosticStatus = line(getPreferences().getString(LAST_DIAGNOSTIC, "No Spark diagnostic captured yet."), 14);
        diagnosticStatus.setTextIsSelectable(true);
        box.addView(diagnosticStatus);

        box.addView(line("Diagnostic data stays on this phone in the helper's local preferences. The app has no Internet permission and does not save screenshots.", 15));
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) status.setText("Last result: " + getPreferences().getString(LAST, "none yet"));
        if (diagnosticStatus != null) diagnosticStatus.setText(getPreferences().getString(LAST_DIAGNOSTIC, "No Spark diagnostic captured yet."));
        if (serviceStatus != null) {
            AccessibilityManager manager = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
            boolean active = manager.getEnabledAccessibilityServiceList(-1).stream()
                    .anyMatch(info -> info.getId().contains(getPackageName()) && info.getId().contains("OfferService"));
            serviceStatus.setText("Accessibility service: " + (active ? "ON" : "OFF"));
        }
    }

    private Set<String> listedStores() {
        Set<String> values = new HashSet<>(getPreferences().getStringSet(LISTED_STORES, new HashSet<>()));
        // Keep any v1.1 stores visible after upgrading, but do not carry the old
        // opposite ON/allow meaning into the new reject-list behavior.
        values.addAll(getPreferences().getStringSet(ALLOWED_STORES, defaultAllowed()));
        values.addAll(getPreferences().getStringSet(REJECT_STORES, new HashSet<>()));
        return values;
    }

    private void refreshStores() {
        storeRows.removeAllViews();
        Set<String> listed = new TreeSet<>(listedStores());
        if (listed.isEmpty()) {
            TextView empty = line("No stores added yet.", 16);
            storeRows.addView(empty);
            return;
        }
        Set<String> rejected = new HashSet<>(getPreferences().getStringSet(REJECT_STORES, new HashSet<>()));
        for (String id : listed) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);

            Switch toggle = new Switch(this);
            toggle.setText("Store #" + id);
            toggle.setTextSize(18);
            toggle.setChecked(rejected.contains(id));
            LinearLayout.LayoutParams switchParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            row.addView(toggle, switchParams);

            Button remove = new Button(this);
            remove.setText("Remove");
            row.addView(remove);
            storeRows.addView(row);

            toggle.setOnCheckedChangeListener((button, checked) -> {
                Set<String> next = new HashSet<>(getPreferences().getStringSet(REJECT_STORES, new HashSet<>()));
                if (checked) next.add(id); else next.remove(id);
                getPreferences().edit().putStringSet(REJECT_STORES, next).apply();
            });
            remove.setOnClickListener(v -> {
                Set<String> nextListed = listedStores();
                nextListed.remove(id);
                Set<String> nextRejected = new HashSet<>(getPreferences().getStringSet(REJECT_STORES, new HashSet<>()));
                nextRejected.remove(id);
                getPreferences().edit()
                        .putStringSet(LISTED_STORES, nextListed)
                        .putStringSet(REJECT_STORES, nextRejected)
                        .apply();
                refreshStores();
            });
        }
    }

    private android.content.SharedPreferences getPreferences() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private TextView line(String value, int size) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(Color.BLACK);
        view.setPadding(0, 10, 0, 16);
        return view;
    }
}
