package com.local.sparkreject;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.net.Uri;
import android.widget.Toast;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ScrollView;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import android.text.InputType;
import java.math.BigDecimal;

public final class MainActivity extends Activity {
    static final String PREFS = "rules";
    static final String ENABLED = "enabled";
    static final String SCAN_ONLY = "scan_only";
    static final String OBSERVE = "observe";
    static final String DIAGNOSTIC = "diagnostic";
    static final String MINIMUM = "minimum";
    static final String SHOPPING_DOLLARS_PER_ITEM = "shopping_dollars_per_item";
    static final String LAST = "last";
    static final String LAST_DIAGNOSTIC = "last_diagnostic";
    static final String ACTIVITY_LOG = "activity_log";
    static final String CAPTURE_REQUEST = "capture_request";
    static final String AUTO_SCREENSHOT = "auto_screenshot";
    static final String ALLOWED_STORES = "allowed_stores"; // legacy v1.1 key; no longer used for decisions
    static final String REJECT_STORES = "reject_stores";
    static final String LISTED_STORES = "listed_stores";

    /** No store is hard-coded in 1.0. Stores exist only after the user adds them. */
    static Set<String> defaultAllowed() { return new HashSet<>(); }

    private LinearLayout storeRows;
    private TextView status;
    private TextView serviceStatus;
    private TextView diagnosticStatus;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32, 44, 32, 32);
        box.setBackgroundColor(Color.WHITE);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        setContentView(scroll);

        box.addView(line("Cheese scan-only test", 27));
        try {
            android.content.pm.PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            box.addView(line("Version " + info.versionName + " | Build " + info.versionCode, 16));
        } catch (android.content.pm.PackageManager.NameNotFoundException e) {
            box.addView(line("Build information unavailable", 16));
        }
        box.addView(line("Scan fix: list-only mode, paced scrolling, and mileage verification.\nDiagnostic build based on v0.9. It keeps the existing reject logic, removes permanent store presets, and records a privacy-filtered view of what Android Accessibility can see inside Spark.", 17));

        Switch diagnostic = new Switch(this);
        diagnostic.setText("Accessibility diagnostic mode");
        diagnostic.setTextSize(18);
        diagnostic.setChecked(getPreferences().getBoolean(DIAGNOSTIC, true));
        box.addView(diagnostic);
        diagnostic.setOnCheckedChangeListener((button, checked) -> getPreferences().edit().putBoolean(DIAGNOSTIC, checked).apply());
        box.addView(line("Leave this ON while we test. Open Spark, visit the offer list/detail/item screens, then return here to see the last Accessibility snapshot. Names and addresses are not saved in the diagnostic.", 15));

        Switch observe = new Switch(this);
        observe.setText("Show offer checks (automatic rejection overrides this)");
        observe.setTextSize(18);
        observe.setChecked(getPreferences().getBoolean(OBSERVE, true));
        box.addView(observe);
        observe.setOnCheckedChangeListener((button, checked) -> getPreferences().edit().putBoolean(OBSERVE, checked).apply());

        Switch scanOnly = new Switch(this);
        scanOnly.setText("Scan all offers (NO automatic rejection)");
        scanOnly.setTextSize(18);
        scanOnly.setChecked(getPreferences().getBoolean(SCAN_ONLY, true));
        box.addView(scanOnly);
        box.addView(line("Test scrolling safely. Cheese only reads and scrolls the list: no reject, accept, or Shopping-detail taps while this is ON.", 15));
        Switch enabled = new Switch(this);
        enabled.setText("Automatically reject by store, pay, and Shopping $/item");
        enabled.setTextSize(18);
        enabled.setChecked(getPreferences().getBoolean(ENABLED, false)
                && !getPreferences().getBoolean(SCAN_ONLY, true));
        box.addView(enabled);
        enabled.setOnCheckedChangeListener((button, checked) -> {
            getPreferences().edit().putBoolean(ENABLED, checked).apply();
            if (checked) scanOnly.setChecked(false);
        });
        scanOnly.setOnCheckedChangeListener((button, checked) -> {
            getPreferences().edit().putBoolean(SCAN_ONLY, checked).apply();
            if (checked) enabled.setChecked(false);
        });

        box.addView(line("Minimum dollars per mile", 18));
        EditText minimum = new EditText(this);
        minimum.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        minimum.setSingleLine(true);
        minimum.setText(getPreferences().getString(MINIMUM, "2.00"));
        box.addView(minimum);
        Button save = new Button(this);
        save.setText("Save threshold");
        box.addView(save);
        save.setOnClickListener(v -> {
            try {
                BigDecimal value = new BigDecimal(minimum.getText().toString());
                if (value.signum() <= 0 || value.compareTo(new BigDecimal("20")) > 0) throw new NumberFormatException();
                getPreferences().edit().putString(MINIMUM, value.toPlainString()).apply();
                status.setText("Saved. Last result: " + getPreferences().getString(LAST, "none yet"));
            } catch (NumberFormatException e) {
                status.setText("Enter a dollar amount above 0 and no more than 20.");
            }
        });

        box.addView(line("Minimum dollars per item (Shopping orders only)", 18));
        EditText shoppingPerItem = new EditText(this);
        shoppingPerItem.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        shoppingPerItem.setSingleLine(true);
        shoppingPerItem.setText(getPreferences().getString(SHOPPING_DOLLARS_PER_ITEM, "1.00"));
        box.addView(shoppingPerItem);
        box.addView(line("Only the item count is used, not total quantity (qty). Non-Shopping offers ignore this setting.", 15));
        Button saveShopping = new Button(this);
        saveShopping.setText("Save Shopping threshold");
        box.addView(saveShopping);
        saveShopping.setOnClickListener(v -> {
            try {
                BigDecimal value = new BigDecimal(shoppingPerItem.getText().toString());
                if (value.signum() <= 0 || value.compareTo(new BigDecimal("50")) > 0) throw new NumberFormatException();
                getPreferences().edit().putString(SHOPPING_DOLLARS_PER_ITEM, value.toPlainString()).apply();
                status.setText("Saved Shopping minimum: $" + value.toPlainString() + " per item. Last result: " + getPreferences().getString(LAST, "none yet"));
            } catch (NumberFormatException e) {
                status.setText("Enter a Shopping dollars-per-item amount above 0 and no more than 50.");
            }
        });

        box.addView(line("Stores to auto-reject", 20));
        box.addView(line("Add a store by number. ON means automatically reject that store. OFF means the store is not rejected just because of its store number. Stores not listed are evaluated normally by your other rules.", 15));
        storeRows = new LinearLayout(this);
        storeRows.setOrientation(LinearLayout.VERTICAL);
        box.addView(storeRows);
        refreshStores();

        EditText storeNumber = new EditText(this);
        storeNumber.setHint("Store number, e.g. 3726");
        storeNumber.setInputType(InputType.TYPE_CLASS_NUMBER);
        storeNumber.setSingleLine(true);
        box.addView(storeNumber);
        Button addStore = new Button(this);
        addStore.setText("Add store (starts OFF)");
        box.addView(addStore);
        addStore.setOnClickListener(v -> {
            String raw = storeNumber.getText().toString().trim();
            if (!raw.matches("[0-9]{1,5}") || Integer.parseInt(raw) == 0) {
                storeNumber.setError("Enter a store number");
                return;
            }
            String id = Integer.toString(Integer.parseInt(raw));
            Set<String> listed = listedStores();
            listed.add(id);
            getPreferences().edit().putStringSet(LISTED_STORES, listed).apply();
            storeNumber.setText("");
            refreshStores();
        });

        Button settings = new Button(this);
        settings.setText("Open Accessibility settings");
        box.addView(settings);
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        serviceStatus = line("Accessibility service: checking", 16);
        box.addView(serviceStatus);
        status = line("Last result: " + getPreferences().getString(LAST, "none yet"), 16);
        box.addView(status);

        box.addView(line("Debug tools", 21));
        Button copy = new Button(this);
        copy.setText("COPY DIAGNOSTICS + ACTIVITY LOG");
        box.addView(copy);
        copy.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("Cheese diagnostic", debugText()));
            Toast.makeText(this, "Diagnostics copied. Paste them into chat.", Toast.LENGTH_LONG).show();
        });
        Button capture = new Button(this);
        capture.setText("TAKE SCREENSHOT ON NEXT SPARK SCREEN");
        box.addView(capture);
        capture.setOnClickListener(v -> {
            getPreferences().edit().putBoolean(CAPTURE_REQUEST, true).apply();
            Toast.makeText(this, "Armed. Switch to Spark; Cheese will capture the next screen.", Toast.LENGTH_LONG).show();
        });
        Switch autoCapture = new Switch(this);
        autoCapture.setText("Capture screenshots automatically on scan failures (optional)");
        autoCapture.setChecked(getPreferences().getBoolean(AUTO_SCREENSHOT, true));
        box.addView(autoCapture);
        autoCapture.setOnCheckedChangeListener((b, checked) -> getPreferences().edit().putBoolean(AUTO_SCREENSHOT, checked).apply());
        box.addView(line("Screenshots may contain private delivery/customer information. They remain on your phone until you choose to share them. Automatic capture defaults ON during testing; you can turn it OFF.", 14));
        Button share = new Button(this);
        share.setText("SHARE DEBUG REPORT + LATEST SCREENSHOT");
        box.addView(share);
        share.setOnClickListener(v -> {
            try {
                java.io.File screenshot = new java.io.File(getFilesDir(), "cheese-debug-screen.png");
                if (!screenshot.isFile()) {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, debugText());
                    startActivity(Intent.createChooser(send, "Share Cheese diagnostics"));
                    return;
                }
                Uri image = Uri.parse("content://" + getPackageName() + ".debug/screenshot");
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("image/png");
                send.putExtra(Intent.EXTRA_STREAM, image);
                send.putExtra(Intent.EXTRA_TEXT, debugText());
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                send.setClipData(ClipData.newUri(getContentResolver(), "Cheese screenshot", image));
                startActivity(Intent.createChooser(send, "Share Cheese debug report"));
            } catch (Exception e) {
                Toast.makeText(this, "Unable to share: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        box.addView(line("Recent activity (newest last)", 20));
        TextView activityText = line(getPreferences().getString(ACTIVITY_LOG, "No activity yet"), 13);
        activityText.setTextIsSelectable(true);
        box.addView(activityText);

        box.addView(line("Last Accessibility diagnostic", 20));
        diagnosticStatus = line(getPreferences().getString(LAST_DIAGNOSTIC, "No Spark diagnostic captured yet."), 14);
        diagnosticStatus.setTextIsSelectable(true);
        box.addView(diagnosticStatus);

        box.addView(line("Diagnostics stay on the phone; screenshots save only when requested or enabled. Cheese has no Internet permission.", 15));
    }

    private String debugText() {
        String build = "unavailable";
        try {
            android.content.pm.PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            build = info.versionName + " | Build " + info.versionCode;
        } catch (android.content.pm.PackageManager.NameNotFoundException ignored) { }
        return "Cheese debug report | Version " + build + "\nLast result: " + getPreferences().getString(LAST, "none")
                + "\n\nActivity log:\n" + getPreferences().getString(ACTIVITY_LOG, "none")
                + "\n\nAccessibility diagnostic:\n"
                + getPreferences().getString(LAST_DIAGNOSTIC, "none");
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) status.setText("Last result: " + getPreferences().getString(LAST, "none yet"));
        if (diagnosticStatus != null) diagnosticStatus.setText(getPreferences().getString(LAST_DIAGNOSTIC, "No Spark diagnostic captured yet."));
        if (serviceStatus != null) {
            AccessibilityManager manager = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
            boolean active = manager.getEnabledAccessibilityServiceList(-1).stream()
                    .anyMatch(info -> info.getId().contains(getPackageName()) && info.getId().contains("OfferService"));
            serviceStatus.setText("Accessibility service: " + (active ? "ON" : "OFF"));
        }
    }

    private Set<String> listedStores() {
        Set<String> values = new HashSet<>(getPreferences().getStringSet(LISTED_STORES, new HashSet<>()));
        // Keep any v1.1 stores visible after upgrading, but do not carry the old
        // opposite ON/allow meaning into the new reject-list behavior.
        values.addAll(getPreferences().getStringSet(ALLOWED_STORES, defaultAllowed()));
        values.addAll(getPreferences().getStringSet(REJECT_STORES, new HashSet<>()));
        return values;
    }

    private void refreshStores() {
        storeRows.removeAllViews();
        Set<String> listed = new TreeSet<>(listedStores());
        if (listed.isEmpty()) {
            TextView empty = line("No stores added yet.", 16);
            storeRows.addView(empty);
            return;
        }
        Set<String> rejected = new HashSet<>(getPreferences().getStringSet(REJECT_STORES, new HashSet<>()));
        for (String id : listed) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);

            Switch toggle = new Switch(this);
            toggle.setText("Store #" + id);
            toggle.setTextSize(18);
            toggle.setChecked(rejected.contains(id));
            LinearLayout.LayoutParams switchParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            row.addView(toggle, switchParams);

            Button remove = new Button(this);
            remove.setText("Remove");
            row.addView(remove);
            storeRows.addView(row);

            toggle.setOnCheckedChangeListener((button, checked) -> {
                Set<String> next = new HashSet<>(getPreferences().getStringSet(REJECT_STORES, new HashSet<>()));
                if (checked) next.add(id); else next.remove(id);
                getPreferences().edit().putStringSet(REJECT_STORES, next).apply();
            });
            remove.setOnClickListener(v -> {
                Set<String> nextListed = listedStores();
                nextListed.remove(id);
                Set<String> nextRejected = new HashSet<>(getPreferences().getStringSet(REJECT_STORES, new HashSet<>()));
                nextRejected.remove(id);
                getPreferences().edit()
                        .putStringSet(LISTED_STORES, nextListed)
                        .putStringSet(REJECT_STORES, nextRejected)
                        .apply();
                refreshStores();
            });
        }
    }

    private android.content.SharedPreferences getPreferences() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private TextView line(String value, int size) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(Color.BLACK);
        view.setPadding(0, 10, 0, 16);
        return view;
    }
}
