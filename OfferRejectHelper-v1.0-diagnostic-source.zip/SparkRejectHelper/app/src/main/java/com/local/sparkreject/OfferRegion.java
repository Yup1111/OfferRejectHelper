package com.local.sparkreject;

import java.util.ArrayList;
import java.util.List;

/** Select only text wholly inside a visible offer's vertical region. */
public final class OfferRegion {
    public static final class Text {
        public final String value;
        public final int left, top, right, bottom;
        public Text(String value, int left, int top, int right, int bottom) {
            this.value=value; this.left=left; this.top=top; this.right=right; this.bottom=bottom;
        }
    }
    public static List<String> select(List<Text> texts, int left, int top, int right, int bottom) {
        List<String> result = new ArrayList<>();
        for (Text t : texts) {
            if (t.right > t.left && t.bottom > t.top && t.left >= left && t.right <= right
                    && t.top >= top && t.bottom <= bottom) result.add(t.value);
        }
        return result;
    }
}
