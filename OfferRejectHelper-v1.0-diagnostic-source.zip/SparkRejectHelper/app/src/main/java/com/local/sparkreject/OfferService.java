package com.local.sparkreject;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.WindowManager;
import android.view.Gravity;
import android.view.View;
import android.graphics.Color;
import android.content.Context;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;
import java.util.Locale;
import java.util.HashSet;
import java.util.Set;

public final class OfferService extends AccessibilityService {
    private static final String SPARK = "com.walmart.sparkdriver";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private AccessibilityNodeInfo handledButton = null;
    private String handledOffer = null;
    private long pendingUntil = 0L;
    private boolean busy = false;
    private Candidate pendingCard;
    private String cardDiagnostic = "";
    private String lastInspectedOffer = null;
    private long lastInspectedAt = 0L;
    private String pendingInspectStore = null;
    private BigDecimal pendingInspectPay = null;
    private BigDecimal pendingInspectMiles = null;
    private Candidate overlayCandidate = null;
    private String overlaySuppressedSignature = null;
    private WindowManager windowManager;
    private LinearLayout overlayView;
    private TextView overlayStatus;
    private Button overlayDecline, overlayClose, overlayAccept;
    private boolean manualPendingConfirm = false;
    private boolean manualControlActive = false;
    private long manualControlUntil = 0L;

    // Full-list scanner. Spark only exposes a window of RecyclerView cards at a time,
    // so Cheese must physically scroll the offer list to inspect every card.
    private boolean fullListMovingToTop = false;
    private String lastBottomProbe = null;
    private int bottomStableProbes = 0;
    private boolean fullListScanning = false;
    private boolean seekingFullListBest = false;
    private final Set<String> fullListSeen = new HashSet<>();
    private String fullListBestSignature = null;
    private BigDecimal fullListBestRate = null;
    private String fullListBestRejectSignature = null;
    private BigDecimal fullListBestRejectRate = null;
    private int fullListPages = 0;
    private long lastFullListScanAt = 0L;
    private String lastFullListBestSignature = null;
    // No page/card limit: keep scanning until two consecutive forward-scroll attempts
    // produce no viewport movement and no newly discovered offer cards.
    private String fullListLastViewportFingerprint = null;
    private boolean fullListAwaitingForwardResult = false;
    private int fullListNoProgressPasses = 0;
    private int fullListTopNoProgressPasses = 0;
    private long fullListRestartNotBefore = 0L;
    private int incompleteBottomSwipeAttempts = 0;
    private boolean scrollGestureInFlight = false;
    private long scanGeneration = 0L;
    // Expansion is a separate step from RecyclerView scrolling.
    private boolean drawerExpanded = false;
    private int drawerExpandAttempts = 0;
    private int drawerPreviousListTop = -1;
    private boolean drawerExpansionAwaitingResult = false;



    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        record("Accessibility service active; waiting for a Spark offer");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getPackageName() == null || !SPARK.contentEquals(event.getPackageName())) { return; }

        // Human touch always wins. If the user starts touching/scrolling Spark,
        // immediately stop Cheese's scan/action loop. After touch ends, wait two
        // seconds before re-reading the current Spark screen and starting fresh.
        // Android may emit touch-interaction events for accessibility-dispatched
        // gestures. Do not classify Cheese's own swipe as a human interruption.
        if (scrollGestureInFlight && (event.getEventType() == AccessibilityEvent.TYPE_TOUCH_INTERACTION_START
                || event.getEventType() == AccessibilityEvent.TYPE_TOUCH_INTERACTION_END)) return;
        if (event.getEventType() == AccessibilityEvent.TYPE_TOUCH_INTERACTION_START) {
            manualControlActive = true;
            manualControlUntil = Long.MAX_VALUE;
            resetFullListScan();
            updateScanOverlay("MANUAL CONTROL\nCheese paused while you use Spark");
            record("Manual control: Cheese paused while user is touching Spark");
            return;
        }
        if (event.getEventType() == AccessibilityEvent.TYPE_TOUCH_INTERACTION_END) {
            manualControlActive = false;
            manualControlUntil = SystemClock.elapsedRealtime() + 2000L;
            resetFullListScan();
            updateScanOverlay("MANUAL CONTROL\nResuming in 2 seconds…");
            record("Manual control ended; Cheese will resume in 2 seconds");
            handler.postDelayed(this::examine, 2050);
            return;
        }
        if (manualControlActive || SystemClock.elapsedRealtime() < manualControlUntil) return;

        if (!getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.SCAN_ONLY, false)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.OBSERVE, true)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.DIAGNOSTIC, true)) return;
        if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.LAST, "").contains("waiting for a Spark offer"))
            record("Spark event received; waiting for an offer card");
        if (busy) return;
        busy = true;
        handler.postDelayed(() -> { busy = false; examine(); }, 350);
    }

    private void examine() {
        if (manualControlActive || scrollGestureInFlight
                || SystemClock.elapsedRealtime() < manualControlUntil) return;
        if (!getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.SCAN_ONLY, false)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.OBSERVE, true)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.DIAGNOSTIC, true)) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) { record("Spark event received, but no readable window"); return; }
        if (root.getPackageName() == null || !SPARK.contentEquals(root.getPackageName())) {
            // A delayed Spark event can run after the user switches back to
            // this helper. Preserve the last Spark observation in that case.
            return;
        }
        if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.DIAGNOSTIC, true))
            recordDiagnostic(AccessibilityDiagnostics.snapshot(root));
        List<String> fields = new ArrayList<>();
        List<AccessibilityNodeInfo> rejectButtons = new ArrayList<>();
        List<AccessibilityNodeInfo> acceptButtons = new ArrayList<>();
        List<AccessibilityNodeInfo> confirmButtons = new ArrayList<>();
        List<AccessibilityNodeInfo> keepButtons = new ArrayList<>();
        scan(root, fields, rejectButtons, acceptButtons, confirmButtons, keepButtons);
        String visibleText = String.join(" ", fields).toLowerCase(Locale.US).replaceAll("\\s+", " ");

        // Spark can mutate the live offer list while Cheese is scanning (for example,
        // when another driver accepts an offer). Never interpret that transient redraw
        // as the end of the list. If Spark explicitly reports that offers disappeared,
        // abandon the in-progress snapshot, let the RecyclerView settle, then restart
        // from the top against the CURRENT list.
        if (visibleText.contains("some offers are no longer available")
                || visibleText.contains("offers are no longer available")
                || visibleText.contains("offer is no longer available")
                || visibleText.contains("another driver accepted")) {
            resetFullListScan();
            fullListRestartNotBefore = SystemClock.elapsedRealtime() + 1800L;
            updateScanOverlay("OFFER LIST CHANGED\nWaiting for Spark to settle…\nRestarting full scan");
            record("Offer list changed while scanning; waiting for Spark to settle, then restarting from top");
            handler.postDelayed(this::examine, 1900);
            return;
        }

        // Handle Spark's exact "Offer Unavailable" popup safely. Do not infer from
        // title length or generic bottom-sheet structure. We act only when the
        // actual phrase is present and the popup's gotItButton is uniquely found.
        if (visibleText.contains("offer unavailable")) {
            List<AccessibilityNodeInfo> gotItButtons = new ArrayList<>();
            findByShortId(root, "gotItButton", gotItButtons);
            AccessibilityNodeInfo gotIt = null;
            for (AccessibilityNodeInfo candidate : gotItButtons) {
                if (candidate.isVisibleToUser() && candidate.isClickable()) {
                    if (gotIt != null) { gotIt = null; break; } // ambiguous: don't act
                    gotIt = candidate;
                }
            }
            if (gotIt != null) {
                if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false)) {
                    boolean clicked = gotIt.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    record(clicked ? "Dismissed Offer Unavailable; resumed watching"
                                   : "Offer Unavailable detected; could not dismiss popup");
                    if (clicked) handler.postDelayed(this::examine, 700);
                } else {
                    record("Check only: Offer Unavailable popup detected");
                }
                return;
            }
            record("Offer Unavailable detected, but popup button was not uniquely identifiable");
            return;
        }

        boolean autoWouldReject = pendingCard != null
                && action(pendingCard, currentShoppingMinimum()) == Decision.Result.REJECT;
        if (!getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.SCAN_ONLY, false)
                && (manualPendingConfirm || (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false) && autoWouldReject))
                && pendingUntil > SystemClock.elapsedRealtime()
                && pendingCard != null
                && visibleText.contains("are you sure you want to reject this offer")
                && visibleText.contains("once you reject an offer")
                && keepButtons.size() == 1 && confirmButtons.size() == 1
                && confirmButtons.get(0).isVisibleToUser()) {
            pendingUntil = 0L; // Do not click this dialog twice if it redraws.
            manualPendingConfirm = false;
            boolean clicked = confirmButtons.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK);
            record(clicked ? "Confirmed automatic rejection" : "Could not click Reject Offer confirmation");
            if (clicked) handler.postDelayed(this::examine, 700);
            return;
        }
        boolean scanOnly = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.SCAN_ONLY, false);
        boolean automatic = !scanOnly && getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.ENABLED, false);
        if (!automatic) { pendingUntil = 0L; manualPendingConfirm = false; }
        if (pendingUntil > SystemClock.elapsedRealtime()) return;
        pendingUntil = 0L;
        // Never act on underlying cards while a confirmation is open.
        if (!confirmButtons.isEmpty()) return;
        BigDecimal minimum;
        BigDecimal shoppingMinimum;
        try {
            minimum = new BigDecimal(getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.MINIMUM, "2.00"));
            shoppingMinimum = new BigDecimal(getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.SHOPPING_DOLLARS_PER_ITEM, "1.00"));
        } catch (NumberFormatException e) { record("Invalid pay threshold"); return; }
        if (handledButton != null && !rejectButtons.contains(handledButton)) {
            handledButton = null;
            handledOffer = null;
        }
        List<String> summaries = new ArrayList<>();
        List<Candidate> cards = new ArrayList<>();
        int unreadable = 0;
        for (AccessibilityNodeInfo button : rejectButtons) {
            if (!button.isVisibleToUser()) continue;
            Candidate card = findCard(button, minimum);
            if (card == null || card.store == null) {
                Candidate positioned = findPositionedCard(root, button, minimum);
                if (positioned != null) card = positioned;
            }
            if (card == null) { unreadable++; summaries.add("Unreadable card: " + cardDiagnostic); continue; }

            // On an opened Shopping detail screen, carry forward the store from
            // the exact list card we opened. The detail screen does not always
            // repeat the store cleanly. Matching pay + miles + item count makes
            // this handoff specific to the opened offer rather than a guess.
            if (card.shopping && card.items != null && pendingInspectStore != null
                    && sameAmount(card.decision.pay, pendingInspectPay)
                    && sameAmount(card.decision.miles, pendingInspectMiles)) {
                card = new Candidate(card, pendingInspectStore);
            }
            if (card.shopping && card.items == null && card.detailsTarget == null)
                card.detailsTarget = findPositionedDetailsTarget(root, button);

            cards.add(card);
            summaries.add(describe(card, shoppingMinimum));
        }

        // In automatic mode, scan the entire Spark offer RecyclerView before choosing
        // an offer. Accessibility only exposes the currently materialized rows, so this
        // intentionally scrolls the real list, deduplicates cards, reaches the bottom,
        // then scrolls back to the globally best candidate before normal action logic.
        if ((automatic || scanOnly) && handleFullListScan(root, cards, shoppingMinimum)) return;
        if (scanOnly) {
            // Absolutely no offer detail / accept / reject actions in scanner-only mode.
            // Avoid a misleading actionable candidate overlay after returning from scanning.
            record("SCAN ONLY: " + cards.size() + " visible offer(s); no actions enabled");
            return;
        }

        record((automatic ? "Auto: " : "Check only: ") + String.join("; ", summaries)
                + (unreadable > 0 ? "; skipped " + unreadable + " card(s)" : "")
                + (summaries.isEmpty() && unreadable == 0 ? "Waiting for visible offer cards" : ""));

        if (cards.isEmpty()) {
            if (scanOnly) updateScanOverlay("SCAN ONLY\nWaiting for visible offer cards…");
            else hideOverlay();
            return;
        }

        // Read the full currently accessible offer list before acting. Rank all
        // offers that pass the immediate store + $/mile checks by $/mile, best first.
        List<Candidate> survivors = new ArrayList<>();
        List<Candidate> rejects = new ArrayList<>();
        for (Candidate card : cards) {
            Decision.Result a = action(card, shoppingMinimum);
            if (a == Decision.Result.REJECT) rejects.add(card);
            else if (a == Decision.Result.KEEP) survivors.add(card);
        }
        Comparator<Candidate> bestRateFirst = (a,b) -> {
            BigDecimal ar = a.decision.perMile == null ? BigDecimal.ZERO : a.decision.perMile;
            BigDecimal br = b.decision.perMile == null ? BigDecimal.ZERO : b.decision.perMile;
            return br.compareTo(ar);
        };
        survivors.sort(bestRateFirst);
        rejects.sort(bestRateFirst);

        Candidate best = survivors.isEmpty() ? null : survivors.get(0);
        Candidate chosen = null;
        Candidate inspect = null;

        // Protect the best valid offer first. Only inspect Shopping details when
        // that Shopping offer is the best currently available candidate.
        if (best != null) {
            if (best.shopping && best.items == null && best.detailsTarget != null
                    && !(signature(best).equals(lastInspectedOffer)
                        && SystemClock.elapsedRealtime() - lastInspectedAt < 30000L)) {
                inspect = best;
            }
            updateOverlay(best, shoppingMinimum);
        } else if (!rejects.isEmpty()) {
            chosen = rejects.get(0);
            updateOverlay(chosen, shoppingMinimum);
        }

        if (!automatic) return;

        if (inspect != null) {
            lastInspectedOffer = signature(inspect);
            lastInspectedAt = SystemClock.elapsedRealtime();
            pendingInspectStore = inspect.store;
            pendingInspectPay = inspect.decision.pay;
            pendingInspectMiles = inspect.decision.miles;
            boolean opened = inspect.detailsTarget.refresh() && inspect.detailsTarget.isVisibleToUser()
                    && inspect.detailsTarget.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            record(opened ? "Opened BEST Shopping offer to check item count: " + describe(inspect, shoppingMinimum)
                    : "Could not open best Shopping offer details");
            if (opened) handler.postDelayed(this::examine, 700);
            return;
        }

        // If the best surviving offer is valid, leave it alone. Do not waste time
        // rejecting or opening worse offers while a better candidate is available.
        if (best != null) {
            if (best.shopping && best.items != null) {
                pendingInspectStore = null; pendingInspectPay = null; pendingInspectMiles = null;
            }
            return;
        }

        if (chosen == null) return;
        // Re-read the same card immediately before clicking; arrivals can change the list.
        if (!chosen.button.refresh() || !chosen.button.isVisibleToUser()) return;
        AccessibilityNodeInfo freshRoot = getRootInActiveWindow();
        if (freshRoot == null || freshRoot.getPackageName() == null || !SPARK.contentEquals(freshRoot.getPackageName())) return;
        Candidate fresh = findCard(chosen.button, minimum);
        if (fresh == null || fresh.store == null) {
            Candidate positioned = findPositionedCard(freshRoot, chosen.button, minimum);
            if (positioned != null) fresh = positioned;
        }
        if (fresh == null || action(fresh, shoppingMinimum) != Decision.Result.REJECT
                || !signature(fresh).equals(signature(chosen))) return;
        if (!getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false)) return;
        handledButton = fresh.button;
        handledOffer = signature(fresh);
        pendingCard = fresh;
        pendingUntil = SystemClock.elapsedRealtime() + 15000L;
        if (!fresh.button.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            pendingUntil = 0L;
            record("Reject button click failed: " + describe(fresh, shoppingMinimum));
        } else {
            record("Pressed Reject; waiting for confirmation: " + describe(fresh, shoppingMinimum));
            handler.postDelayed(this::examine, 700);
        }
    }

    private boolean handleFullListScan(AccessibilityNodeInfo root, List<Candidate> cards, BigDecimal shoppingMinimum) {
        List<AccessibilityNodeInfo> lists = new ArrayList<>();
        findByShortId(root, "homeBottomSheetRecyclerView", lists);
        AccessibilityNodeInfo list = null;
        for (AccessibilityNodeInfo n : lists) {
            if (n.isVisibleToUser()) { list = n; break; }
        }
        if (list == null) {
            resetFullListScan();
            return false; // detail screen or non-list Spark screen
        }

        // Spark's bottom sheet must be fully opened *before* we attempt to
        // scroll cards. Scrolling an only-partly-open sheet can stall mid-card.
        if (!ensureOfferDrawerExpanded(list)) return true;

        long now = SystemClock.elapsedRealtime();
        if (now < fullListRestartNotBefore) {
            long waitMs = fullListRestartNotBefore - now;
            updateScanOverlay("OFFER LIST CHANGED\nWaiting for Spark to settle…\nRestarting full scan");
            handler.postDelayed(this::examine, Math.max(250L, waitMs + 50L));
            return true;
        }
        if (!fullListMovingToTop && !fullListScanning && !seekingFullListBest
                && now - lastFullListScanAt < (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                    .getBoolean(MainActivity.SCAN_ONLY, false) ? 12000L : 3000L))
            return false;

        if (seekingFullListBest) {
            for (Candidate c : cards) {
                String sig = signature(c);
                if (sig.equals(fullListBestSignature)) {
                    lastFullListScanAt = now;
                    lastFullListBestSignature = sig;
                    fullListScanning = false;
                    seekingFullListBest = false;
                    int checked = fullListSeen.size();
                    fullListSeen.clear();
                    record("Full list checked to bottom (" + checked + " unique offers); located best offer: "
                            + describe(c, shoppingMinimum));
                    return false;
                }
            }
            boolean moved = list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
            if (moved) {
                updateScanOverlay("FULL LIST CHECKED\nReturning to best offer…");
                record("Full list checked to bottom; returning to best offer…");
                handler.postDelayed(this::examine, 450);
                return true;
            }
            resetFullListScan();
            record("Offer list changed while locating the best card; rescanning from top");
            handler.postDelayed(this::examine, 250);
            return true;
        }

        if (!fullListMovingToTop && !fullListScanning) {
            fullListMovingToTop = true;
            fullListSeen.clear();
            fullListBestSignature = null;
            fullListBestRate = null;
            fullListBestRejectSignature = null;
            fullListBestRejectRate = null;
            fullListPages = 0;
            fullListLastViewportFingerprint = null;
            fullListAwaitingForwardResult = false;
            fullListNoProgressPasses = 0;
            fullListTopNoProgressPasses = 0;
            incompleteBottomSwipeAttempts = 0;
            updateScanOverlay("PREPARING FULL-LIST SCAN\nMoving to first offer…");
        }

        if (fullListMovingToTop) {
            boolean movedUp = list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
            if (movedUp) {
                fullListTopNoProgressPasses = 0;
                updateScanOverlay("PREPARING FULL-LIST SCAN\nMoving to first offer…");
                record("Preparing full-list scan: moving to first offer…");
                handler.postDelayed(this::examine, 500);
                return true;
            }
            // A single failed accessibility scroll can be transient. Do not assume
            // we are at the top until the list refuses to move upward three times.
            fullListTopNoProgressPasses++;
            if (fullListTopNoProgressPasses < 3) {
                updateScanOverlay("VERIFYING TOP OF LIST\nNo upward movement "
                        + fullListTopNoProgressPasses + "/3…");
                record("Verifying top of offer list: no upward movement "
                        + fullListTopNoProgressPasses + "/3");
                handler.postDelayed(this::examine, 650);
                return true;
            }
            fullListTopNoProgressPasses = 0;
            fullListMovingToTop = false;
            fullListScanning = true;
            updateScanOverlay("TOP CONFIRMED\nStarting full-list scan…");
        }

        int newCards = 0;
        for (Candidate c : cards) {
            String sig = signature(c);
            if (!fullListSeen.add(sig)) continue;
            newCards++;
            Decision.Result result = action(c, shoppingMinimum);
            BigDecimal rate = c.decision.perMile == null ? BigDecimal.ZERO : c.decision.perMile;
            if (result == Decision.Result.KEEP) {
                if (fullListBestSignature == null || rate.compareTo(fullListBestRate) > 0) {
                    fullListBestSignature = sig;
                    fullListBestRate = rate;
                }
            } else if (result == Decision.Result.REJECT) {
                if (fullListBestRejectSignature == null || rate.compareTo(fullListBestRejectRate) > 0) {
                    fullListBestRejectSignature = sig;
                    fullListBestRejectRate = rate;
                }
            }
        }
        fullListPages++;

        String viewport = viewportFingerprint(cards);
        if (fullListAwaitingForwardResult) {
            boolean viewportChanged = fullListLastViewportFingerprint == null
                    || !fullListLastViewportFingerprint.equals(viewport);
            if (!viewportChanged && newCards == 0) fullListNoProgressPasses++;
            else { fullListNoProgressPasses = 0; incompleteBottomSwipeAttempts = 0; lastBottomProbe = null; bottomStableProbes = 0; }
            fullListAwaitingForwardResult = false;
        }

        // No page cap, and no early two-pass finish: a momentary RecyclerView
        // stall is not proof that the user can actually see the final card.
        String previousViewport = fullListLastViewportFingerprint;
        fullListLastViewportFingerprint = viewport;
        boolean moved = list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
        if (moved) {
            fullListAwaitingForwardResult = true;
            updateScanOverlay("SCANNING ALL OFFERS\n" + fullListSeen.size()
                    + " unique offer(s) checked\nScrolling toward bottom…");
            record("Scanning all offers: " + fullListSeen.size() + " unique card(s) checked; scrolling…");
            handler.postDelayed(this::examine, 600);
            return true;
        }

        // Do NOT treat one failed ACTION_SCROLL_FORWARD as the bottom. RecyclerView
        // can transiently reject accessibility scroll actions while it is laying out.
        // Confirm the same viewport, with no new offers, on three separate failed
        // forward attempts before declaring the list exhausted. There is still no
        // maximum number of pages/cards: this is purely an end-of-list proof.
        boolean sameViewport = previousViewport != null
                && previousViewport.equals(viewport);
        if (sameViewport && newCards == 0) fullListNoProgressPasses++;
        else fullListNoProgressPasses = 1;
        fullListLastViewportFingerprint = viewport;
        fullListAwaitingForwardResult = false;

        if (fullListNoProgressPasses >= 3) {
            if (!lastOfferFullyExposedWithSpace(list, cards)) {
                updateScanOverlay("BOTTOM NOT YET EXPOSED\nLast card is still clipped\nScrolling to expose full card…");
                record("Bottom not confirmed: last offer card is not fully visible with space below it");
                // An accessibility ACTION_SCROLL_FORWARD failure often occurs before
                // the final RecyclerView item becomes visible. Actually swipe the
                // offer-list region, then read the newly settled viewport.
                if (incompleteBottomSwipeAttempts >= 4) {
                    updateScanOverlay("SCROLL STALLED — NOT AT BOTTOM\nLast offer is still clipped\nWaiting to retry scan…");
                    record("Scroll stalled: last card clipped after gesture retries; BOTTOM NOT CONFIRMED");
                    resetFullListScan();
                    fullListRestartNotBefore = SystemClock.elapsedRealtime() + 4500L;
                    handler.postDelayed(this::examine, 4600L);
                    return true;
                }
                incompleteBottomSwipeAttempts++;
                fullListNoProgressPasses = 0;
                fullListAwaitingForwardResult = false;
                performPhysicalListSwipe(list);
                return true;
            }
            // A fresh offer may arrive between the last two scroll attempts.
            // Require two stable bottom observations, separated by settling time.
            if (!viewport.equals(lastBottomProbe)) {
                lastBottomProbe = viewport;
                bottomStableProbes = 1;
                updateScanOverlay("VERIFYING STABLE BOTTOM\nWaiting for Spark updates…");
                handler.postDelayed(this::examine, 1100L);
                return true;
            }
            bottomStableProbes++;
            if (bottomStableProbes < 2) {
                handler.postDelayed(this::examine, 850L);
                return true;
            }
            updateScanOverlay("BOTTOM CONFIRMED\n" + fullListSeen.size()
                    + " unique offer(s) checked\nFull last card + space below verified");
            record("Bottom confirmed: full last offer card is visible with space below it; "
                    + fullListSeen.size() + " unique offer(s) checked");
            return finishFullListScan(shoppingMinimum);
        }

        updateScanOverlay("VERIFYING BOTTOM\n" + fullListSeen.size()
                + " unique offer(s) checked\nNo movement " + fullListNoProgressPasses + "/3…");
        record("Verifying bottom of offer list: no movement "
                + fullListNoProgressPasses + "/3; " + fullListSeen.size() + " unique offer(s)");
        handler.postDelayed(this::examine, 750);
        return true;
    }

    /**
     * First expand Spark's draggable offer sheet by swiping its upper handle.
     * This is deliberately separate from scrolling the RecyclerView content.
     * If expansion cannot be established, report it instead of claiming bottom.
     */
    private boolean ensureOfferDrawerExpanded(AccessibilityNodeInfo list) {
        if (scrollGestureInFlight) return false;
        Rect r = new Rect();
        list.getBoundsInScreen(r);
        if (r.isEmpty()) return false;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        float density = getResources().getDisplayMetrics().density;
        // Spark's partially expanded drawer can already place the list at
        // y=505 on a 2340px display. The old 38% limit (889px!) wrongly
        // called that fully expanded and began scanning too soon. Verify the
        // actual handle position on each pass and require it near the top.
        List<AccessibilityNodeInfo> handles = new ArrayList<>();
        AccessibilityNodeInfo screenRoot = getRootInActiveWindow();
        if (screenRoot != null) findByShortId(screenRoot, "swipeHandle", handles);
        Rect handleRect = new Rect();
        boolean handleVisible = false;
        for (AccessibilityNodeInfo h : handles) {
            if (h.isVisibleToUser()) { h.getBoundsInScreen(handleRect); handleVisible = true; break; }
        }
        // On this Spark layout, the expanded drawer has been observed with
        // the handle around y=436 and RecyclerView around y=505 on a 2340px
        // screen. The previous 18%/16% limits (421/374) mistakenly reject
        // this position forever. Accept the observed expanded snap position;
        // still check both the handle AND RecyclerView so an ordinary lower
        // drawer cannot start an offer scan.
        int expandedTopLimit = (int) (screenHeight * 0.24f);
        boolean fullyExpanded = r.top <= expandedTopLimit
                && handleVisible && handleRect.top <= (int) (screenHeight * 0.215f);
        if (fullyExpanded) {
            drawerExpanded = true;
            drawerExpansionAwaitingResult = false;
            updateScanOverlay("DRAWER EXPANDED\nStarting full-list scan…");
            record("Offer drawer is expanded; beginning offer-list scan");
            return true;
        }
        drawerExpanded = false;
        if (drawerExpansionAwaitingResult) {
            drawerExpansionAwaitingResult = false;
            if (drawerPreviousListTop > 0 && drawerPreviousListTop - r.top > 45 * density)
                drawerExpandAttempts = Math.max(0, drawerExpandAttempts - 1);
        }
        if (drawerExpandAttempts >= 4) {
            updateScanOverlay("DRAWER NOT EXPANDED\nCould not open Spark offer sheet\nScan paused — no actions");
            record("Could not verify offer drawer expansion; scan paused rather than falsely confirming bottom");
            resetFullListScan();
            fullListRestartNotBefore = SystemClock.elapsedRealtime() + 4500L;
            handler.postDelayed(this::examine, 4600L);
            return false;
        }
        drawerPreviousListTop = r.top;
        drawerExpandAttempts++;
        // Find a parent encompassing the sheet header, so the swipe starts
        // above the list (at the draggable handle), not on an offer card.
        int sheetTop = -1;
        AccessibilityNodeInfo parent = list.getParent();
        for (int depth = 0; parent != null && depth < 7; depth++, parent = parent.getParent()) {
            Rect pr = new Rect(); parent.getBoundsInScreen(pr);
            if (pr.top > 24 * density && pr.top < r.top - 32 * density
                    && pr.bottom >= r.bottom - 16 * density && pr.width() >= r.width() * .8f) {
                sheetTop = pr.top;
            }
        }
        int startY = handleVisible ? handleRect.centerY()
                : (sheetTop > 0 ? sheetTop + (int)(23 * density) : r.top - (int)(92 * density));
        startY = Math.min(r.top - (int)(14 * density), Math.max((int)(75 * density), startY));
        // Don't finish the swipe underneath our top overlay. Repeated drags
        // can snap Spark's sheet to the fully expanded position.
        int endY = Math.max((int)(screenHeight * .13f), startY - (int)(screenHeight * .48f));
        if (startY - endY < 90 * density) {
            updateScanOverlay("DRAWER POSITION UNCLEAR\nWaiting before scanning offers…");
            handler.postDelayed(this::examine, 750L);
            return false;
        }
        Path path = new Path();
        int x = r.left + r.width()/2;
        path.moveTo(x, startY);
        path.lineTo(x, endY);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 520));
        long generation = scanGeneration;
        scrollGestureInFlight = true;
        updateScanOverlay("EXPANDING OFFER DRAWER\nDragging top handle upward…\nAttempt " + drawerExpandAttempts + "/4");
        boolean accepted = dispatchGesture(builder.build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                scrollGestureInFlight = false;
                if (generation == scanGeneration) {
                    drawerExpansionAwaitingResult = true;
                    handler.postDelayed(OfferService.this::examine, 900L);
                }
            }
            @Override public void onCancelled(GestureDescription gestureDescription) {
                scrollGestureInFlight = false;
                if (generation == scanGeneration) handler.postDelayed(OfferService.this::examine, 900L);
            }
        }, handler);
        if (!accepted) {
            scrollGestureInFlight = false;
            handler.postDelayed(this::examine, 900L);
        }
        return false;
    }

    private void performPhysicalListSwipe(AccessibilityNodeInfo list) {
        if (scrollGestureInFlight) return;
        Rect r = new Rect();
        list.getBoundsInScreen(r);
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int startY = Math.min(r.bottom - 65, screenHeight - 100);
        int endY = Math.max(r.top + 90, startY - Math.max(310, r.height() / 2));
        if (r.width() < 150 || startY - endY < 120) {
            updateScanOverlay("SCROLL STALLED — NOT AT BOTTOM\nNo safe swipe area available");
            resetFullListScan();
            fullListRestartNotBefore = SystemClock.elapsedRealtime() + 4500L;
            handler.postDelayed(this::examine, 4600L);
            return;
        }
        int x = r.left + r.width() / 2;
        Path path = new Path();
        path.moveTo(x, startY);
        path.lineTo(x, endY);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 390));
        long generation = scanGeneration;
        scrollGestureInFlight = true;
        updateScanOverlay("LAST CARD CLIPPED\nSwiping down the offer list…\nRetry "
                + incompleteBottomSwipeAttempts + "/4");
        boolean accepted = dispatchGesture(builder.build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                scrollGestureInFlight = false;
                if (generation == scanGeneration) {
                    fullListAwaitingForwardResult = true;
                    handler.postDelayed(OfferService.this::examine, 850L);
                }
            }
            @Override public void onCancelled(GestureDescription gestureDescription) {
                scrollGestureInFlight = false;
                if (generation == scanGeneration) {
                    record("Swipe interrupted; bottom not confirmed");
                    handler.postDelayed(OfferService.this::examine, 850L);
                }
            }
        }, handler);
        if (!accepted) {
            scrollGestureInFlight = false;
            handler.postDelayed(this::examine, 850L);
        }
    }

    private boolean lastOfferFullyExposedWithSpace(AccessibilityNodeInfo list, List<Candidate> cards) {
        if (list == null || cards == null || cards.isEmpty()) return false;
        Rect listRect = new Rect();
        list.getBoundsInScreen(listRect);
        if (listRect.isEmpty()) return false;

        // Use the bottom-most visible offer's card container. A true end-of-list
        // state must show the complete final card plus visible list padding below it.
        Candidate bottom = null;
        int bottomButtonBottom = Integer.MIN_VALUE;
        for (Candidate c : cards) {
            if (c == null || c.button == null || !c.button.isVisibleToUser()) continue;
            Rect br = new Rect(); c.button.getBoundsInScreen(br);
            if (!br.isEmpty() && br.bottom > bottomButtonBottom) {
                bottomButtonBottom = br.bottom; bottom = c;
            }
        }
        if (bottom == null) return false;

        Rect cardRect = findSingleOfferCardBounds(bottom.button, list);
        if (cardRect == null || cardRect.isEmpty()) return false;
        int margin = Math.max(12, (int) (12f * getResources().getDisplayMetrics().density));
        return cardRect.top >= listRect.top && cardRect.bottom <= listRect.bottom - margin;
    }

    private Rect findSingleOfferCardBounds(AccessibilityNodeInfo button, AccessibilityNodeInfo list) {
        AccessibilityNodeInfo scope = button;
        Rect best = null;
        for (int depth = 0; scope != null && depth < 24; depth++, scope = scope.getParent()) {
            if (scope.equals(list)) break;
            List<String> fields = new ArrayList<>();
            List<AccessibilityNodeInfo> reject = new ArrayList<>(), accept = new ArrayList<>();
            List<AccessibilityNodeInfo> confirm = new ArrayList<>(), keep = new ArrayList<>();
            scan(scope, fields, reject, accept, confirm, keep);
            if (reject.size() > 1 || accept.size() > 1 || !confirm.isEmpty()) break;
            if (reject.size() == 1 && reject.get(0).equals(button) && accept.size() == 1) {
                Rect r = new Rect(); scope.getBoundsInScreen(r);
                if (!r.isEmpty()) best = r;
            }
        }
        return best;
    }

    private boolean finishFullListScan(BigDecimal shoppingMinimum) {
        if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.SCAN_ONLY, false)) {
            int count = fullListSeen.size();
            lastFullListScanAt = SystemClock.elapsedRealtime();
            resetFullListScan();
            updateScanOverlay("BOTTOM CONFIRMED — SCAN ONLY\n" + count
                    + " unique offer(s) checked\nNo offers accepted or rejected");
            record("SCAN ONLY COMPLETE: " + count + " unique offer(s); no actions performed");
            handler.postDelayed(this::examine, 12000L);
            return true;
        }
        if (fullListBestSignature == null) fullListBestSignature = fullListBestRejectSignature;
        fullListBestRejectSignature = null;
        fullListAwaitingForwardResult = false;
        fullListNoProgressPasses = 0;
        if (fullListBestSignature == null) {
            int checked = fullListSeen.size();
            resetFullListScan();
            record("Full list checked to bottom; " + checked + " unique offer(s), none readable/eligible");
            return true;
        }
        seekingFullListBest = true;
        fullListScanning = false;
        updateScanOverlay("BOTTOM CONFIRMED\n" + fullListSeen.size()
                + " CURRENT unique offer(s) checked\nLocating best offer…");
        record("Bottom confirmed: full current list checked; " + fullListSeen.size()
                + " unique offer(s); locating best offer…");
        // Keep the proof visible long enough for the user to actually see it.
        handler.postDelayed(this::examine, 1200);
        return true;
    }

    private String viewportFingerprint(List<Candidate> cards) {
        List<String> parts = new ArrayList<>();
        for (Candidate c : cards) {
            Rect r = new Rect();
            if (c.button != null) c.button.getBoundsInScreen(r);
            parts.add(signature(c) + "@" + r.top + ":" + r.bottom);
        }
        java.util.Collections.sort(parts);
        return String.join("|", parts);
    }

    private void resetFullListScan() {
        fullListMovingToTop = false;
        fullListScanning = false;
        seekingFullListBest = false;
        fullListSeen.clear();
        fullListBestSignature = null;
        fullListBestRate = null;
        fullListBestRejectSignature = null;
        fullListBestRejectRate = null;
        fullListPages = 0;
        fullListLastViewportFingerprint = null;
        fullListAwaitingForwardResult = false;
        fullListNoProgressPasses = 0;
        fullListTopNoProgressPasses = 0;
        lastBottomProbe = null;
        bottomStableProbes = 0;
        incompleteBottomSwipeAttempts = 0;
        scanGeneration++;
        drawerExpanded = false;
        drawerExpandAttempts = 0;
        drawerPreviousListTop = -1;
        drawerExpansionAwaitingResult = false;
    }

    private void findByShortId(AccessibilityNodeInfo node, String shortId, List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        String id = node.getViewIdResourceName();
        if (id != null && (id.equals(shortId) || id.endsWith(":id/" + shortId) || id.endsWith("/" + shortId)))
            out.add(node);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) findByShortId(child, shortId, out);
        }
    }

    private static final class Candidate {
        final AccessibilityNodeInfo button;
        AccessibilityNodeInfo detailsTarget;
        final Decision decision;
        final String store;
        final boolean shopping;
        final Integer items;
        final boolean bulky;
        Candidate(AccessibilityNodeInfo button, AccessibilityNodeInfo detailsTarget, Decision decision, List<String> fields) {
            this(button, detailsTarget, decision, fields, null);
        }
        Candidate(AccessibilityNodeInfo button, AccessibilityNodeInfo detailsTarget, Decision decision, List<String> fields, String forcedStore) {
            this.button = button;
            this.detailsTarget = detailsTarget;
            this.decision = decision;
            String parsedStore = StoreRule.identify(fields);
            this.store = forcedStore != null ? forcedStore : parsedStore;
            this.shopping = Decision.isShopping(fields);
            this.items = Decision.itemCount(fields);
            String joined = String.join(" ", fields).toLowerCase(Locale.US);
            this.bulky = joined.contains("bulky item") || joined.contains("heavy item");
        }
        Candidate(Candidate base, String forcedStore) {
            this.button = base.button;
            this.detailsTarget = base.detailsTarget;
            this.decision = base.decision;
            this.store = forcedStore;
            this.shopping = base.shopping;
            this.items = base.items;
            this.bulky = base.bulky;
        }
    }

    private Candidate findCard(AccessibilityNodeInfo button, BigDecimal minimum) {
        cardDiagnostic = "No ancestor with one Reject/Accept pair";
        String lastPair = "no single-button pair found";
        AccessibilityNodeInfo scope = button;
        for (int depth = 0; scope != null && depth < 30; depth++, scope = scope.getParent()) {
            List<String> fields = new ArrayList<>();
            List<AccessibilityNodeInfo> reject = new ArrayList<>(), accept = new ArrayList<>();
            List<AccessibilityNodeInfo> confirm = new ArrayList<>(), keep = new ArrayList<>();
            scan(scope, fields, reject, accept, confirm, keep);
            // Count even offscreen buttons for boundaries: never join neighboring cards.
            if (reject.size() > 1 || accept.size() > 1 || !confirm.isEmpty()) {
                cardDiagnostic = "Reached shared container (Reject=" + reject.size() + ", Accept=" + accept.size()
                        + "). Last individual scope: " + lastPair;
                return null;
            }
            if (reject.size() == 1 && reject.get(0).equals(button) && accept.size() == 1) {
                lastPair = Decision.diagnostic(fields, minimum);
                cardDiagnostic = lastPair;
                Decision decision = Decision.evaluate(fields, minimum);
                if (decision.result != Decision.Result.UNKNOWN) return new Candidate(button, findDetailsTarget(scope), decision, fields);
            }
        }
        return null;
    }

    private Candidate findPositionedCard(AccessibilityNodeInfo root, AccessibilityNodeInfo button, BigDecimal minimum) {
        List<String> all = new ArrayList<>();
        List<AccessibilityNodeInfo> reject = new ArrayList<>(), accept = new ArrayList<>();
        List<AccessibilityNodeInfo> confirm = new ArrayList<>(), keep = new ArrayList<>();
        scan(root, all, reject, accept, confirm, keep);
        if (!confirm.isEmpty() || !reject.contains(button)) return null;
        Rect target = new Rect(), window = new Rect();
        button.getBoundsInScreen(target);
        root.getBoundsInScreen(window);
        if (target.isEmpty() || !window.contains(target)) return null;
        int top = window.top;
        for (AccessibilityNodeInfo other : reject) {
            if (other.equals(button)) continue;
            Rect r = new Rect(); other.getBoundsInScreen(r);
            if (r.isEmpty()) continue;
            // Reject overlapping rows: these could be duplicate or side-by-side cards.
            if (r.top < target.bottom && r.bottom > target.top) {
                cardDiagnostic = "Overlapping Reject buttons; cannot identify a single row";
                return null;
            }
            if (r.bottom <= target.top) top = Math.max(top, r.bottom);
        }
        int paired = 0;
        for (AccessibilityNodeInfo other : accept) {
            if (!other.isVisibleToUser()) continue;
            Rect r = new Rect(); other.getBoundsInScreen(r);
            int overlap = Math.min(r.bottom, target.bottom) - Math.max(r.top, target.top);
            if (!r.isEmpty() && r.left >= target.right && overlap > 0
                    && overlap * 2 >= Math.min(r.height(), target.height())) paired++;
        }
        if (paired != 1) { cardDiagnostic = "Position check: matching Accept buttons=" + paired; return null; }
        List<OfferRegion.Text> positioned = new ArrayList<>();
        scanPositions(root, positioned);
        List<String> fields = OfferRegion.select(positioned, window.left, top, window.right, target.top);
        Decision decision = Decision.evaluate(fields, minimum);
        cardDiagnostic = "Position check: " + Decision.diagnostic(fields, minimum);
        return decision.result == Decision.Result.UNKNOWN ? null : new Candidate(button, null, decision, fields);
    }

    private void scanPositions(AccessibilityNodeInfo node, List<OfferRegion.Text> fields) {
        if (node.isVisibleToUser()) {
            Rect r = new Rect(); node.getBoundsInScreen(r);
            CharSequence text = node.getText(), description = node.getContentDescription();
            String viewId = node.getViewIdResourceName();
            // Spark offer details expose the total offer amount in estimatedValueView.
            // Preserve that label during position-based parsing so component amounts
            // such as base pay, surge, or tip cannot make the total ambiguous.
            if (text != null && text.length() > 0 && viewId != null
                    && viewId.endsWith(":id/estimatedValueView")) {
                fields.add(new OfferRegion.Text("Estimated pay " + text.toString(), r.left, r.top, r.right, r.bottom));
            }
            if (text != null && text.length() > 0) fields.add(new OfferRegion.Text(text.toString(), r.left, r.top, r.right, r.bottom));
            if (description != null && description.length() > 0 && (text == null || !description.toString().contentEquals(text)))
                fields.add(new OfferRegion.Text(description.toString(), r.left, r.top, r.right, r.bottom));
        }
        for (int i=0; i<node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) scanPositions(child, fields);
        }
    }

    private Decision.Result action(Candidate c, BigDecimal shoppingMinimum) {
        Decision.Result base = StoreRule.result(c.store, getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getStringSet(MainActivity.REJECT_STORES, java.util.Collections.emptySet()), c.decision);
        if (base != Decision.Result.KEEP) return base;
        if (!c.shopping || c.items == null) return base;
        if (c.items <= 0 || c.decision.pay == null || shoppingMinimum == null || shoppingMinimum.signum() <= 0)
            return Decision.Result.UNKNOWN;
        return c.decision.pay.compareTo(shoppingMinimum.multiply(new BigDecimal(c.items))) < 0
                ? Decision.Result.REJECT : Decision.Result.KEEP;
    }

    private boolean sameAmount(BigDecimal a, BigDecimal b) {
        return a != null && b != null && a.compareTo(b) == 0;
    }

    private AccessibilityNodeInfo findPositionedDetailsTarget(AccessibilityNodeInfo root, AccessibilityNodeInfo rejectButton) {
        if (root == null || rejectButton == null) return null;
        Rect rejectRect = new Rect();
        rejectButton.getBoundsInScreen(rejectRect);
        if (rejectRect.isEmpty()) return null;
        List<AccessibilityNodeInfo> candidates = new ArrayList<>();
        findByShortId(root, "clickableLayout", candidates);
        findByShortId(root, "buttonDetailsCta", candidates);
        AccessibilityNodeInfo best = null;
        int bestGap = Integer.MAX_VALUE;
        for (AccessibilityNodeInfo node : candidates) {
            if (!node.isVisibleToUser()) continue;
            AccessibilityNodeInfo clickable = node;
            for (int i = 0; i < 3 && clickable != null && !clickable.isClickable(); i++) clickable = clickable.getParent();
            if (clickable == null || !clickable.isClickable() || !clickable.isVisibleToUser()) continue;
            Rect r = new Rect(); clickable.getBoundsInScreen(r);
            if (r.isEmpty()) continue;
            int horizontalOverlap = Math.min(r.right, rejectRect.right) - Math.max(r.left, rejectRect.left);
            if (horizontalOverlap <= 0 || r.bottom > rejectRect.top || r.top >= rejectRect.top) continue;
            int gap = rejectRect.top - r.bottom;
            if (gap < bestGap) { bestGap = gap; best = clickable; }
        }
        return best;
    }

    private AccessibilityNodeInfo matchingAccept(AccessibilityNodeInfo rejectButton) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || rejectButton == null) return null;
        List<String> fields = new ArrayList<>();
        List<AccessibilityNodeInfo> rejects = new ArrayList<>(), accepts = new ArrayList<>(), confirms = new ArrayList<>(), keeps = new ArrayList<>();
        scan(root, fields, rejects, accepts, confirms, keeps);
        Rect rr = new Rect(); rejectButton.getBoundsInScreen(rr);
        AccessibilityNodeInfo match = null;
        for (AccessibilityNodeInfo a : accepts) {
            if (!a.isVisibleToUser()) continue;
            Rect ar = new Rect(); a.getBoundsInScreen(ar);
            int overlap = Math.min(ar.bottom, rr.bottom) - Math.max(ar.top, rr.top);
            if (!ar.isEmpty() && ar.left >= rr.right && overlap > 0 && overlap * 2 >= Math.min(ar.height(), rr.height())) {
                if (match != null) return null;
                match = a;
            }
        }
        return match;
    }

    private void updateOverlay(Candidate card, BigDecimal shoppingMinimum) {
        if (card == null) { hideOverlay(); return; }
        String sig = signature(card);
        if (sig.equals(overlaySuppressedSignature)) { hideOverlay(); return; }
        overlayCandidate = card;
        if (overlayView == null) createOverlay();
        boolean scanOnlyMode = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.SCAN_ONLY, false);
        overlayDecline.setEnabled(!scanOnlyMode);
        overlayClose.setEnabled(true);
        overlayAccept.setEnabled(!scanOnlyMode);
        String status = describe(card, shoppingMinimum);
        String alert = card.bulky ? "BROKE BACK ALERT — bulky/heavy item\n" : "";
        if (card.shopping && card.items == null) status = alert + "BEST OFFER → checking Shopping items\n" + status;
        else if (sig.equals(lastFullListBestSignature) && SystemClock.elapsedRealtime() - lastFullListScanAt < 8000L)
            status = alert + "BEST OFFER — FULL LIST CHECKED\n" + status;
        else status = alert + "BEST VISIBLE OFFER\n" + status;
        overlayStatus.setText(status);
        if (overlayView.getParent() == null) {
            try { windowManager.addView(overlayView, overlayParams()); } catch (Exception ignored) {}
        }
    }

    private void updateScanOverlay(String status) {
        overlayCandidate = null;
        if (overlayView == null) createOverlay();
        overlayStatus.setText(status);
        overlayDecline.setEnabled(false);
        overlayAccept.setEnabled(false);
        overlayClose.setEnabled(true);
        if (overlayView.getParent() == null) {
            try { windowManager.addView(overlayView, overlayParams()); } catch (Exception ignored) {}
        }
    }

    private WindowManager.LayoutParams overlayParams() {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                android.graphics.PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        return p;
    }

    private void createOverlay() {
        overlayView = new LinearLayout(this);
        overlayView.setOrientation(LinearLayout.VERTICAL);
        overlayView.setPadding(18, 12, 18, 12);
        overlayView.setBackgroundColor(Color.argb(235, 30, 30, 30));
        overlayStatus = new TextView(this);
        overlayStatus.setTextColor(Color.WHITE);
        overlayStatus.setTextSize(13f);
        overlayStatus.setMaxLines(4);
        overlayView.addView(overlayStatus, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        overlayDecline = new Button(this); overlayDecline.setText("DECLINE");
        overlayClose = new Button(this); overlayClose.setText("CLOSE");
        overlayAccept = new Button(this); overlayAccept.setText("ACCEPT");
        row.addView(overlayDecline, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(overlayClose, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(overlayAccept, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        overlayView.addView(row);

        overlayDecline.setOnClickListener(v -> {
            if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                    .getBoolean(MainActivity.SCAN_ONLY, false)) return;
            Candidate c = overlayCandidate;
            if (c == null || c.button == null || !c.button.refresh() || !c.button.isVisibleToUser()) return;
            pendingCard = c; pendingUntil = SystemClock.elapsedRealtime() + 15000L; manualPendingConfirm = true;
            if (c.button.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                record("Overlay DECLINE pressed: " + describe(c, currentShoppingMinimum()));
                handler.postDelayed(this::examine, 500);
            } else { manualPendingConfirm = false; pendingUntil = 0L; }
        });
        overlayClose.setOnClickListener(v -> {
            if (overlayCandidate != null) overlaySuppressedSignature = signature(overlayCandidate);
            hideOverlay();
        });
        overlayAccept.setOnClickListener(v -> {
            if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                    .getBoolean(MainActivity.SCAN_ONLY, false)) return;
            Candidate c = overlayCandidate;
            AccessibilityNodeInfo a = c == null ? null : matchingAccept(c.button);
            if (a != null && a.refresh() && a.isVisibleToUser() && a.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                record("Overlay ACCEPT pressed: " + describe(c, currentShoppingMinimum()));
                hideOverlay();
            }
        });
    }

    private void hideOverlay() {
        overlayCandidate = null;
        if (overlayView != null && overlayView.getParent() != null) {
            try { windowManager.removeView(overlayView); } catch (Exception ignored) {}
        }
    }

    private AccessibilityNodeInfo findDetailsTarget(AccessibilityNodeInfo node) {
        if (node == null) return null;
        String id = node.getViewIdResourceName();
        if (node.isClickable() && id != null && (id.endsWith(":id/clickableLayout") || id.endsWith(":id/buttonDetailsCta")))
            return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo found = findDetailsTarget(child);
            if (found != null) return found;
        }
        return null;
    }

    private String signature(Candidate c) { return c.store + "/" + c.decision.pay + "/" + c.decision.miles; }
    private String describe(Candidate c, BigDecimal shoppingMinimum) {
        Decision d = c.decision;
        if (c.store == null) return "SKIP: store number missing or conflicting; $" + d.pay + " / " + d.miles + " mi";
        boolean storeRejected = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getStringSet(MainActivity.REJECT_STORES, java.util.Collections.emptySet()).contains(c.store);
        String extra = "";
        if (c.shopping) {
            if (c.items == null) extra = " / Shopping items: open details to check";
            else {
                BigDecimal perItem = Decision.dollarsPerItem(d.pay, c.items);
                extra = " / Shopping " + c.items + " items" + (perItem == null ? "" : " / $" + perItem + "/item")
                        + " (min $" + shoppingMinimum + "/item)";
            }
        }
        String reason;
        if (storeRejected) reason = "store is on auto-reject list";
        else if (d.result == Decision.Result.REJECT) reason = d.explanation;
        else if (c.shopping && c.items != null && action(c, shoppingMinimum) == Decision.Result.REJECT) reason = "Below Shopping $/item minimum";
        else reason = d.explanation;
        return action(c, shoppingMinimum) + " #" + c.store + " $" + d.pay + " / " + d.miles + " mi / $" + d.perMile + "/mi"
                + extra + " — " + reason;
    }

    private BigDecimal currentShoppingMinimum() {
        try { return new BigDecimal(getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getString(MainActivity.SHOPPING_DOLLARS_PER_ITEM, "1.00")); }
        catch (NumberFormatException e) { return new BigDecimal("1.00"); }
    }

    private void record(String value) {
        if (!value.equals(getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.LAST, "")))
            getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit().putString(MainActivity.LAST, value).apply();
    }

    private void recordDiagnostic(String value) {
        if (!value.equals(getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.LAST_DIAGNOSTIC, "")))
            getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit().putString(MainActivity.LAST_DIAGNOSTIC, value).apply();
    }

    private void scan(AccessibilityNodeInfo node, List<String> fields,
                      List<AccessibilityNodeInfo> reject, List<AccessibilityNodeInfo> accept,
                      List<AccessibilityNodeInfo> confirm, List<AccessibilityNodeInfo> keep) {
        CharSequence text = node.getText(), description = node.getContentDescription();
        String viewId = node.getViewIdResourceName();
        // On Spark's opened offer-detail screen, estimatedValueView is the
        // actual total offer pay. Other nearby dollar values can be base pay,
        // surge, or tip. Add a synthetic labeled field so Decision.evaluate()
        // can identify the total without confusing those components.
        if (text != null && text.length() > 0 && viewId != null
                && viewId.endsWith(":id/estimatedValueView")) {
            fields.add("Estimated pay " + text.toString());
        }
        if (text != null && text.length() > 0) fields.add(text.toString());
        if (description != null && description.length() > 0 && (text == null || !description.toString().contentEquals(text))) fields.add(description.toString());
        String label = text != null ? text.toString().trim() : description != null ? description.toString().trim() : "";
        String normalized = label.toLowerCase(Locale.US).replaceAll("\\s+", " ");
        List<AccessibilityNodeInfo> buttons = null;
        if (normalized.matches("reject|decline")) buttons = reject;
        else if (normalized.equals("accept")) buttons = accept;
        else if (normalized.equals("reject offer")) buttons = confirm;
        else if (normalized.equals("keep offer")) buttons = keep;
        if (buttons != null && node.isEnabled()) {
            AccessibilityNodeInfo clickable = node;
            for (int i = 0; i < 2 && clickable != null && !clickable.isClickable(); i++) clickable = clickable.getParent();
            if (clickable != null && clickable.isClickable() && !buttons.contains(clickable)) buttons.add(clickable);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) scan(child, fields, reject, accept, confirm, keep);
        }
    }
    @Override public void onInterrupt() { handler.removeCallbacksAndMessages(null); busy = false; hideOverlay(); }

    @Override public void onDestroy() {
        hideOverlay();
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
