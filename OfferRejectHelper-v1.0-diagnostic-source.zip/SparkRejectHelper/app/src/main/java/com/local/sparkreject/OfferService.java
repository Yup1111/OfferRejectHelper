package com.local.sparkreject;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Bitmap;
import android.hardware.HardwareBuffer;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.WindowManager;
import android.view.Gravity;
import android.view.View;
import android.graphics.Color;
import android.content.Context;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;
import java.util.Locale;
import java.util.HashSet;
import java.util.Set;

public final class OfferService extends AccessibilityService {
    private static final String SPARK = "com.walmart.sparkdriver";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private AccessibilityNodeInfo handledButton = null;
    private String handledOffer = null;
    private long pendingUntil = 0L;
    private boolean examineScheduled = false;
    private long examineDueAt = 0L;
    private long lastExamineAt = 0L;
    private long gestureStartedAt = 0L;
    private long bottomCaptureStartedAt = 0L;
    private boolean bottomCapturePending = false;
    private String lastPauseReason = "";
    private final Runnable scanWatchdog = new Runnable() {
        @Override public void run() {
            checkScanProgress();
            handler.postDelayed(this, 2000L);
        }
    };
    private final Runnable examineTask = () -> {
        examineScheduled = false;
        examine();
    };
    private long pendingInspectAt = 0L;
    private long fullListStartedAt = 0L;
    private int bestHeaderScrollAttempts = 0;
    private final ScanEvidence.RefreshGate refreshGate = new ScanEvidence.RefreshGate();
    private boolean refreshBannerWasVisible = false;
    private long refreshWaitingSince = 0L;
    private Candidate pendingCard;
    private String cardDiagnostic = "";
    private String lastInspectedOffer = null;
    private long lastInspectedAt = 0L;
    private String pendingInspectStore = null;
    private BigDecimal pendingInspectPay = null;
    private BigDecimal pendingInspectMiles = null;
    private Candidate overlayCandidate = null;
    private String overlaySuppressedSignature = null;
    private WindowManager windowManager;
    private LinearLayout overlayView;
    private TextView overlayStatus;
    private Button overlayDecline, overlayClose, overlayAccept;
    private boolean manualPendingConfirm = false;
    private long lastDebugCaptureAt = 0L;
    private String lastItemDiscoverySignature = null;
    private boolean manualControlActive = false;
    private long manualControlUntil = 0L;

    // Full-list scanner. Spark only exposes a window of RecyclerView cards at a time,
    // so Cheese must physically scroll the offer list to inspect every card.
    private boolean fullListMovingToTop = false;
    private String lastBottomProbe = null;
    private int bottomStableProbes = 0;
    private boolean fullListScanning = false;
    private boolean seekingFullListBest = false;
    private final Set<String> fullListSeen = new HashSet<>();
    private String fullListBestSignature = null;
    private BigDecimal fullListBestRate = null;
    private String fullListBestRejectSignature = null;
    private BigDecimal fullListBestRejectRate = null;
    private int fullListPages = 0;
    private long lastFullListScanAt = 0L;
    private String lastFullListBestSignature = null;
    // No page/card limit: keep scanning until two consecutive forward-scroll attempts
    // produce no viewport movement and no newly discovered offer cards.
    private String fullListLastViewportFingerprint = null;
    private boolean fullListAwaitingForwardResult = false;
    private int fullListNoProgressPasses = 0;
    private int fullListTopNoProgressPasses = 0;
    private long fullListRestartNotBefore = 0L;
    private int incompleteBottomSwipeAttempts = 0;
    private boolean scrollGestureInFlight = false;
    private long scanGeneration = 0L;
    // Expansion is a separate step from RecyclerView scrolling.
    private boolean drawerExpanded = false;
    private int drawerStableDrags = 0;
    private int verifiedDrawerTop = -1;
    private int drawerExpandAttempts = 0;
    private int drawerPreviousListTop = -1;
    private boolean drawerExpansionAwaitingResult = false;



    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        record("Accessibility service active; waiting for a Spark offer");
        handler.removeCallbacks(scanWatchdog);
        handler.postDelayed(scanWatchdog, 2000L);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getPackageName() == null || !SPARK.contentEquals(event.getPackageName())) { return; }

        // Human touch always wins. If the user starts touching/scrolling Spark,
        // immediately stop Cheese's scan/action loop. After touch ends, wait two
        // seconds before re-reading the current Spark screen and starting fresh.
        // Android may emit touch-interaction events for accessibility-dispatched
        // gestures. Do not classify Cheese's own swipe as a human interruption.
        if (scrollGestureInFlight && (event.getEventType() == AccessibilityEvent.TYPE_TOUCH_INTERACTION_START
                || event.getEventType() == AccessibilityEvent.TYPE_TOUCH_INTERACTION_END)) return;
        if (event.getEventType() == AccessibilityEvent.TYPE_TOUCH_INTERACTION_START) {
            manualControlActive = true;
            manualControlUntil = Long.MAX_VALUE;
            resetFullListScan();
            updateScanOverlay("MANUAL CONTROL\nCheese paused while you use Spark");
            record("Manual control: Cheese paused while user is touching Spark");
            return;
        }
        if (event.getEventType() == AccessibilityEvent.TYPE_TOUCH_INTERACTION_END) {
            manualControlActive = false;
            manualControlUntil = SystemClock.elapsedRealtime() + 2000L;
            resetFullListScan();
            updateScanOverlay("MANUAL CONTROL\nResuming in 2 seconds…");
            record("Manual control ended; Cheese will resume in 2 seconds");
            scheduleExamine(2050);
            return;
        }
        if (manualControlActive || SystemClock.elapsedRealtime() < manualControlUntil) return;

        if (!getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.SCAN_ONLY, true)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.OBSERVE, true)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.DIAGNOSTIC, true)) return;
        if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.LAST, "").contains("waiting for a Spark offer"))
            record("Spark event received; waiting for an offer card");
        // A content event must not bypass the settling delay of an in-flight scan.
        if (!examineScheduled || (!scrollGestureInFlight && !bottomCapturePending
                && examineDueAt - SystemClock.elapsedRealtime() > 1500L)) scheduleExamine(350L);
    }

    private void scheduleExamine(long delayMillis) {
        handler.removeCallbacks(examineTask);
        examineScheduled = true;
        examineDueAt = SystemClock.elapsedRealtime() + delayMillis;
        handler.postDelayed(examineTask, delayMillis);
    }

    private boolean handleNewOffersRefresh(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> lists = new ArrayList<>();
        findByShortId(root, "homeBottomSheetRecyclerView", lists);
        boolean onList = false;
        for (AccessibilityNodeInfo n : lists) if (n.isVisibleToUser()) onList = true;
        List<AccessibilityNodeInfo> messages = new ArrayList<>();
        findRefreshMessages(root, messages);
        boolean bannerVisible = onList && !messages.isEmpty();
        refreshGate.observe(bannerVisible);
        long now = SystemClock.elapsedRealtime();
        if (!bannerVisible) {
            if (refreshBannerWasVisible) {
                refreshBannerWasVisible = false;
                resetFullListScan();
                lastFullListScanAt = 0L;
                fullListRestartNotBefore = now + 1500L;
                record("Refresh banner cleared; waiting for list to settle, then scanning from top");
                scheduleExamine(1550L);
                return true;
            }
            return false;
        }
        boolean enabled = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.SCAN_ONLY, true)
                || getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false);
        if (!enabled) return false;
        if (!refreshBannerWasVisible) {
            refreshBannerWasVisible = true;
            refreshWaitingSince = now;
            resetFullListScan();
            lastFullListScanAt = 0L;
            pendingUntil = 0L;
            pendingCard = null;
            manualPendingConfirm = false;
            pendingInspectAt = 0L;
            pendingInspectStore = null;
            pendingInspectPay = null;
            pendingInspectMiles = null;
            lastInspectedOffer = null;
            lastFullListBestSignature = null;
            overlayCandidate = null;
            record("New-offer banner detected; discarded old scan and selected offer");
        }
        AccessibilityNodeInfo refresh = messages.size() == 1 ? bannerRefreshButton(messages.get(0), root) : null;
        if (refresh != null && refreshGate.canAttempt(now)) {
            // Bounded retries for a stale/failed click; never use guessed coordinates.
            refreshGate.attempted(now);
            boolean clicked = refresh.refresh() && refresh.isVisibleToUser() && refresh.isEnabled()
                    && refresh.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            record(clicked ? "Tapped new-offer REFRESH; waiting for updated list"
                    : "New-offer REFRESH tap failed; will retry after cooldown");
            updateScanOverlay("REFRESHING OFFERS\nOld scan cleared; waiting for new list");
        } else {
            updateScanOverlay("NEW OFFERS — SCAN PAUSED\nWaiting for refresh banner to clear");
            if (refresh == null) record("New-offer banner found, but REFRESH is not uniquely clickable; refresh manually");
        }
        // Do not scan stale offers under the banner or repeatedly hammer its action.
        scheduleExamine(1000L);
        if (now - refreshWaitingSince >= 8000L)
            pauseReason("refresh banner remains; bounded retries, waiting for it to clear");
        return true;
    }

    private void findRefreshMessages(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        if (node.isVisibleToUser() && (ScanEvidence.newOffersBanner(node.getText() == null ? null : node.getText().toString())
                || ScanEvidence.newOffersBanner(node.getContentDescription() == null ? null : node.getContentDescription().toString())))
            out.add(node);
        for (int i = 0; i < node.getChildCount(); i++) findRefreshMessages(node.getChild(i), out);
    }

    private AccessibilityNodeInfo bannerRefreshButton(AccessibilityNodeInfo message, AccessibilityNodeInfo root) {
        Rect window = new Rect(), messageBounds = new Rect();
        root.getBoundsInScreen(window); message.getBoundsInScreen(messageBounds);
        AccessibilityNodeInfo scope = message.getParent();
        for (int level = 0; scope != null && level < 3; level++, scope = scope.getParent()) {
            Rect bounds = new Rect(); scope.getBoundsInScreen(bounds);
            if (bounds.isEmpty() || bounds.height() > window.height() / 4) break;
            List<AccessibilityNodeInfo> matches = new ArrayList<>();
            findExactRefresh(scope, matches);
            AccessibilityNodeInfo chosen = null;
            for (AccessibilityNodeInfo label : matches) {
                AccessibilityNodeInfo button = label;
                for (int i = 0; i < 2 && button != null && !button.isClickable(); i++) button = button.getParent();
                if (button == null || !button.isEnabled() || !button.isClickable() || !button.isVisibleToUser()) continue;
                Rect br = new Rect(); button.getBoundsInScreen(br);
                if (br.isEmpty() || !bounds.contains(br) || br.left < messageBounds.right
                        || br.bottom <= messageBounds.top || br.top >= messageBounds.bottom) continue;
                if (chosen != null && !chosen.equals(button)) return null;
                chosen = button;
            }
            if (chosen != null) return chosen;
        }
        return null;
    }

    private void findExactRefresh(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        String text = node.getText() == null ? "" : node.getText().toString().trim();
        String description = node.getContentDescription() == null ? "" : node.getContentDescription().toString().trim();
        if (node.isVisibleToUser() && ("refresh".equalsIgnoreCase(text) || "refresh".equalsIgnoreCase(description))) out.add(node);
        for (int i = 0; i < node.getChildCount(); i++) findExactRefresh(node.getChild(i), out);
    }

    private void pauseReason(String reason) {
        if (!reason.equals(lastPauseReason)) {
            lastPauseReason = reason;
            appendActivity("Scan status: " + reason);
        }
    }

    private void checkScanProgress() {
        if (!(fullListMovingToTop || fullListScanning || seekingFullListBest
                || scrollGestureInFlight || bottomCapturePending)) return;
        long now = SystemClock.elapsedRealtime();
        boolean active = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.SCAN_ONLY, true)
                || getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false);
        if (!active) { pauseReason("scanning disabled"); resetFullListScan(); return; }
        if (manualControlActive || now < manualControlUntil) {
            pauseReason("manual control; no automatic recovery while user is touching Spark"); return;
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null || !SPARK.contentEquals(root.getPackageName())) {
            pauseReason("Spark is not the readable foreground window"); return;
        }
        String recovery = ScanEvidence.recovery(now, scrollGestureInFlight, gestureStartedAt,
                bottomCapturePending, bottomCaptureStartedAt, examineScheduled, examineDueAt, lastExamineAt);
        if ("gesture".equals(recovery)) {
            appendActivity("RECOVERY: scroll gesture callback missing after 4 seconds; restarting scan");
            scrollGestureInFlight = false;
            resetFullListScan(); // invalidates late gesture callbacks
            scheduleExamine(900L);
            return;
        }
        if ("capture".equals(recovery)) {
            appendActivity("RECOVERY: bottom screenshot callback timed out; discarding scan and retrying");
            resetFullListScan();
            scheduleExamine(900L);
            return;
        }
        if (scrollGestureInFlight || bottomCapturePending) return;
        if ("schedule".equals(recovery)) {
            appendActivity("RECOVERY: scan has no timely next check; resuming current state");
            scheduleExamine(100L);
        }
    }

    private void examine() {
        lastExamineAt = SystemClock.elapsedRealtime();
        if (bottomCapturePending) { pauseReason("capturing bottom proof before moving list"); return; }

        if (manualControlActive || scrollGestureInFlight
                || SystemClock.elapsedRealtime() < manualControlUntil) {
            pauseReason(scrollGestureInFlight ? "waiting for scroll gesture callback" : "manual control");
            return;
        }
        if (!getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.SCAN_ONLY, true)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.OBSERVE, true)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.DIAGNOSTIC, true)) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) { pauseReason("no readable foreground window"); return; }
        if (root.getPackageName() == null || !SPARK.contentEquals(root.getPackageName())) {
            pauseReason("Spark is not the readable foreground window");
            // A delayed Spark event can run after the user switches back to
            // this helper. Preserve the last Spark observation in that case.
            return;
        }
        if (!lastPauseReason.isEmpty()) { appendActivity("Scan status: resumed in Spark"); lastPauseReason = ""; }
        if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.DIAGNOSTIC, true))
            recordDiagnostic(AccessibilityDiagnostics.snapshot(root));
        if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.CAPTURE_REQUEST, false)) {
            getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit().putBoolean(MainActivity.CAPTURE_REQUEST, false).apply();
            captureDebugScreenshot("Manually requested screenshot");
        }
        List<String> fields = new ArrayList<>();
        List<AccessibilityNodeInfo> rejectButtons = new ArrayList<>();
        List<AccessibilityNodeInfo> acceptButtons = new ArrayList<>();
        List<AccessibilityNodeInfo> confirmButtons = new ArrayList<>();
        List<AccessibilityNodeInfo> keepButtons = new ArrayList<>();
        scan(root, fields, rejectButtons, acceptButtons, confirmButtons, keepButtons);
        String visibleText = String.join(" ", fields).toLowerCase(Locale.US).replaceAll("\\s+", " ");

        if (handleNewOffersRefresh(root)) return;

        // Spark can mutate the live offer list while Cheese is scanning (for example,
        // when another driver accepts an offer). Never interpret that transient redraw
        // as the end of the list. If Spark explicitly reports that offers disappeared,
        // abandon the in-progress snapshot, let the RecyclerView settle, then restart
        // from the top against the CURRENT list.
        if (visibleText.contains("some offers are no longer available")
                || visibleText.contains("offers are no longer available")
                || visibleText.contains("offer is no longer available")
                || visibleText.contains("another driver accepted")) {
            resetFullListScan();
            fullListRestartNotBefore = SystemClock.elapsedRealtime() + 1800L;
            updateScanOverlay("OFFER LIST CHANGED\nWaiting for Spark to settle…\nRestarting full scan");
            record("Offer list changed while scanning; waiting for Spark to settle, then restarting from top");
            scheduleExamine(1900);
            return;
        }

        // Handle Spark's exact "Offer Unavailable" popup safely. Do not infer from
        // title length or generic bottom-sheet structure. We act only when the
        // actual phrase is present and the popup's gotItButton is uniquely found.
        if (visibleText.contains("offer unavailable")) {
            List<AccessibilityNodeInfo> gotItButtons = new ArrayList<>();
            findByShortId(root, "gotItButton", gotItButtons);
            AccessibilityNodeInfo gotIt = null;
            for (AccessibilityNodeInfo candidate : gotItButtons) {
                if (candidate.isVisibleToUser() && candidate.isClickable()) {
                    if (gotIt != null) { gotIt = null; break; } // ambiguous: don't act
                    gotIt = candidate;
                }
            }
            if (gotIt != null) {
                if (!getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.SCAN_ONLY, true)
                        && getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false)) {
                    boolean clicked = gotIt.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    record(clicked ? "Dismissed Offer Unavailable; resumed watching"
                                   : "Offer Unavailable detected; could not dismiss popup");
                    if (clicked) scheduleExamine(700);
                } else {
                    record("Check only: Offer Unavailable popup detected");
                }
                return;
            }
            record("Offer Unavailable detected, but popup button was not uniquely identifiable");
            return;
        }

        boolean autoWouldReject = pendingCard != null
                && action(pendingCard, currentShoppingMinimum()) == Decision.Result.REJECT;
        if (!getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.SCAN_ONLY, true)
                && (manualPendingConfirm || (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false) && autoWouldReject))
                && pendingUntil > SystemClock.elapsedRealtime()
                && pendingCard != null
                && visibleText.contains("are you sure you want to reject this offer")
                && visibleText.contains("once you reject an offer")
                && keepButtons.size() == 1 && confirmButtons.size() == 1
                && confirmButtons.get(0).isVisibleToUser()) {
            pendingUntil = 0L; // Do not click this dialog twice if it redraws.
            manualPendingConfirm = false;
            boolean clicked = confirmButtons.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK);
            record(clicked ? "Confirmed automatic rejection" : "Could not click Reject Offer confirmation");
            if (clicked) scheduleExamine(700);
            return;
        }
        boolean scanOnly = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.SCAN_ONLY, true);
        boolean automatic = !scanOnly && getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.ENABLED, false);
        if (!automatic) { pendingUntil = 0L; manualPendingConfirm = false; }
        if (pendingUntil > SystemClock.elapsedRealtime()) return;
        pendingUntil = 0L;
        // Never act on underlying cards while a confirmation is open.
        if (!confirmButtons.isEmpty()) return;
        BigDecimal minimum;
        BigDecimal shoppingMinimum;
        try {
            minimum = new BigDecimal(getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.MINIMUM, "2.00"));
            shoppingMinimum = new BigDecimal(getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.SHOPPING_DOLLARS_PER_ITEM, "1.00"));
        } catch (NumberFormatException e) { record("Invalid pay threshold"); return; }
        if (handledButton != null && !rejectButtons.contains(handledButton)) {
            handledButton = null;
            handledOffer = null;
        }
        List<AccessibilityNodeInfo> offerLists = new ArrayList<>();
        findByShortId(root, "homeBottomSheetRecyclerView", offerLists);
        boolean onOfferList = false;
        for (AccessibilityNodeInfo n : offerLists) if (n.isVisibleToUser()) onOfferList = true;
        List<String> summaries = new ArrayList<>();
        List<Candidate> cards = new ArrayList<>();
        int unreadable = 0;
        for (AccessibilityNodeInfo button : rejectButtons) {
            if (!button.isVisibleToUser()) continue;
            Candidate card = findCard(button, minimum);
            if (card == null || card.store == null) {
                Candidate positioned = findPositionedCard(root, button, minimum);
                if (positioned != null) card = positioned;
            }
            if (card == null) { unreadable++; summaries.add("Unreadable card: " + cardDiagnostic); continue; }

            // Details can expose distance to pickup or one leg, not the list's
            // total trip mileage. Never rank/act on a different number or guess
            // that equal pay alone identifies the offer the user has opened.
            if (!onOfferList) {
                boolean recentContext = pendingInspectAt > 0L
                        && SystemClock.elapsedRealtime() - pendingInspectAt < 60000L
                        && pendingInspectStore != null
                        && pendingInspectStore.equals(card.store);
                Decision verified = Decision.verifyDetail(card.decision, pendingInspectPay,
                        pendingInspectMiles, recentContext);
                card = new Candidate(card, verified);
            }
            if (card.shopping && card.items == null && card.detailsTarget == null)
                card.detailsTarget = findPositionedDetailsTarget(root, button);

            cards.add(card);
            summaries.add(describe(card, shoppingMinimum));
        }

        // In automatic mode, scan the entire Spark offer RecyclerView before choosing
        // an offer. Accessibility only exposes the currently materialized rows, so this
        // intentionally scrolls the real list, deduplicates cards, reaches the bottom,
        // then scrolls back to the globally best candidate before normal action logic.
        if ((automatic || scanOnly) && handleFullListScan(root, cards, shoppingMinimum)) return;
        if (scanOnly) {
            // Offer detail is READ ONLY. No accept/reject actions.
            if (!cards.isEmpty() && cards.get(0).shopping && cards.get(0).items != null) {
                Candidate c = cards.get(0);
                updateScanOverlay("SHOPPING DETAILS READ\n" + describe(c, shoppingMinimum)
                        + "\nNo accept/reject actions");
                record("INSPECTED SHOPPING: " + describe(c, shoppingMinimum)
                        + "; discovering how to open product list (read-only)");
                discoverShoppingItems(root, c);
            }
            return;
        }

        record((automatic ? "Auto: " : "Check only: ") + String.join("; ", summaries)
                + (unreadable > 0 ? "; skipped " + unreadable + " card(s)" : "")
                + (summaries.isEmpty() && unreadable == 0 ? "Waiting for visible offer cards" : ""));

        if (cards.isEmpty()) {
            if (scanOnly) updateScanOverlay("SCAN ONLY\nWaiting for visible offer cards…");
            else hideOverlay();
            return;
        }

        // Read the full currently accessible offer list before acting. Rank all
        // offers that pass the immediate store + $/mile checks by $/mile, best first.
        List<Candidate> survivors = new ArrayList<>();
        List<Candidate> rejects = new ArrayList<>();
        for (Candidate card : cards) {
            Decision.Result a = action(card, shoppingMinimum);
            if (a == Decision.Result.REJECT) rejects.add(card);
            else if (a == Decision.Result.KEEP) survivors.add(card);
        }
        Comparator<Candidate> bestRateFirst = (a,b) -> {
            BigDecimal ar = a.decision.perMile == null ? BigDecimal.ZERO : a.decision.perMile;
            BigDecimal br = b.decision.perMile == null ? BigDecimal.ZERO : b.decision.perMile;
            return br.compareTo(ar);
        };
        survivors.sort(bestRateFirst);
        rejects.sort(bestRateFirst);

        Candidate best = survivors.isEmpty() ? null : survivors.get(0);
        Candidate chosen = null;
        Candidate inspect = null;

        // Protect the best valid offer first. Only inspect Shopping details when
        // that Shopping offer is the best currently available candidate.
        if (best != null) {
            if (best.shopping && best.items == null && best.detailsTarget != null
                    && !(signature(best).equals(lastInspectedOffer)
                        && SystemClock.elapsedRealtime() - lastInspectedAt < 30000L)) {
                inspect = best;
            }
            updateOverlay(best, shoppingMinimum);
        } else if (!rejects.isEmpty()) {
            chosen = rejects.get(0);
            updateOverlay(chosen, shoppingMinimum);
        }

        if (!automatic) return;

        if (inspect != null) {
            lastInspectedOffer = signature(inspect);
            lastInspectedAt = SystemClock.elapsedRealtime();
            pendingInspectStore = inspect.store;
            pendingInspectPay = inspect.decision.pay;
            pendingInspectMiles = inspect.decision.miles;
            pendingInspectAt = SystemClock.elapsedRealtime();
            boolean opened = inspect.detailsTarget.refresh() && inspect.detailsTarget.isVisibleToUser()
                    && inspect.detailsTarget.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            record(opened ? "Opened BEST Shopping offer to check item count: " + describe(inspect, shoppingMinimum)
                    : "Could not open best Shopping offer details");
            if (opened) scheduleExamine(700);
            else pendingInspectAt = 0L;
            return;
        }

        // If the best surviving offer is valid, leave it alone. Do not waste time
        // rejecting or opening worse offers while a better candidate is available.
        if (best != null) {
            if (best.shopping && best.items != null) {
                pendingInspectStore = null; pendingInspectPay = null; pendingInspectMiles = null;
            }
            return;
        }

        if (chosen == null) return;
        // Re-read the same card immediately before clicking; arrivals can change the list.
        if (!chosen.button.refresh() || !chosen.button.isVisibleToUser()) return;
        AccessibilityNodeInfo freshRoot = getRootInActiveWindow();
        if (freshRoot == null || freshRoot.getPackageName() == null || !SPARK.contentEquals(freshRoot.getPackageName())) return;
        Candidate fresh = findCard(chosen.button, minimum);
        if (fresh == null || fresh.store == null) {
            Candidate positioned = findPositionedCard(freshRoot, chosen.button, minimum);
            if (positioned != null) fresh = positioned;
        }
        if (fresh == null || action(fresh, shoppingMinimum) != Decision.Result.REJECT
                || !signature(fresh).equals(signature(chosen))) return;
        if (!getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false)) return;
        handledButton = fresh.button;
        handledOffer = signature(fresh);
        pendingCard = fresh;
        pendingUntil = SystemClock.elapsedRealtime() + 15000L;
        if (!fresh.button.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            pendingUntil = 0L;
            record("Reject button click failed: " + describe(fresh, shoppingMinimum));
        } else {
            record("Pressed Reject; waiting for confirmation: " + describe(fresh, shoppingMinimum));
            scheduleExamine(700);
        }
    }

    private boolean handleFullListScan(AccessibilityNodeInfo root, List<Candidate> cards, BigDecimal shoppingMinimum) {
        List<AccessibilityNodeInfo> lists = new ArrayList<>();
        findByShortId(root, "homeBottomSheetRecyclerView", lists);
        AccessibilityNodeInfo list = null;
        for (AccessibilityNodeInfo n : lists) {
            if (n.isVisibleToUser()) { list = n; break; }
        }
        if (list == null) {
            resetFullListScan();
            return false; // inspect details separately, don't scroll blindly
        }

        long now = SystemClock.elapsedRealtime();
        if (now < fullListRestartNotBefore) {
            scheduleExamine(Math.min(1000L, fullListRestartNotBefore - now + 50L));
            return true;
        }
        // Expansion and scrolling are separate states, both respecting backoff.
        if (!ensureOfferDrawerExpanded(list)) return true;
        if (!fullListMovingToTop && !fullListScanning && !seekingFullListBest
                && now - lastFullListScanAt < (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                    .getBoolean(MainActivity.SCAN_ONLY, true) ? 12000L : 3000L)) {
            scheduleExamine(1000L); // Check refresh while leaving the completed result readable.
            return true;
        }

        if (fullListStartedAt > 0L && now - fullListStartedAt > 45000L) {
            pauseFullListScan("Scan timed out; full list NOT confirmed. Waiting before retry");
            return true;
        }

        if (seekingFullListBest) {
            for (Candidate c : cards) {
                String sig = signature(c);
                if (sig.equals(fullListBestSignature)) {
                    AccessibilityNodeInfo header = c.detailsTarget;
                    if (header == null) header = findPositionedDetailsTarget(root, c.button);
                    Rect listBounds = new Rect(), headerBounds = new Rect();
                    list.getBoundsInScreen(listBounds);
                    if (header != null) header.getBoundsInScreen(headerBounds);
                    // A visible Reject button is not proof that the header above
                    // it is on screen (the reported failure had a clipped header).
                    if (header == null || !header.isVisibleToUser() || headerBounds.isEmpty()
                            || !listBounds.contains(headerBounds)) {
                        if (++bestHeaderScrollAttempts > 4
                                || !list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) {
                            pauseFullListScan("Selected offer header is clipped or unavailable; scan paused");
                        } else {
                            record("Returning to selected offer: revealing its header");
                            scheduleExamine(650L);
                        }
                        return true;
                    }
                    lastFullListScanAt = now;
                    fullListStartedAt = 0L;
                    lastFullListBestSignature = sig;
                    fullListScanning = false;
                    seekingFullListBest = false;
                    int checked = fullListSeen.size();
                    fullListSeen.clear();
                    record("Full list checked to bottom (" + checked + " unique offers); located best offer: "
                            + describe(c, shoppingMinimum));
                    // Scan-only strictly reads and scrolls. The user can open
                    // details manually; this branch must never dispatch a click.
                    if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                            .getBoolean(MainActivity.SCAN_ONLY, true)) {
                        updateScanOverlay("SCAN COMPLETE — LIST ONLY\n"
                                + checked + " offers scanned; no taps\n"
                                + describe(c, shoppingMinimum));
                        scheduleExamine(1000L);
                        return true;
                    }
                    return false;
                }
            }
            boolean moved = list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
            if (moved) {
                updateScanOverlay("FULL LIST CHECKED\nReturning to best offer…");
                record("Full list checked to bottom; returning to best offer…");
                scheduleExamine(350);
                return true;
            }
            resetFullListScan();
            record("Offer list changed while locating the best card; rescanning from top");
            scheduleExamine(250);
            return true;
        }

        if (!fullListMovingToTop && !fullListScanning) {
            fullListMovingToTop = true;
            fullListStartedAt = now;
            bestHeaderScrollAttempts = 0;
            fullListSeen.clear();
            fullListBestSignature = null;
            fullListBestRate = null;
            fullListBestRejectSignature = null;
            fullListBestRejectRate = null;
            fullListPages = 0;
            fullListLastViewportFingerprint = null;
            fullListAwaitingForwardResult = false;
            fullListNoProgressPasses = 0;
            fullListTopNoProgressPasses = 0;
            incompleteBottomSwipeAttempts = 0;
            updateScanOverlay("PREPARING FULL-LIST SCAN\nMoving to first offer…");
        }

        if (fullListMovingToTop) {
            boolean movedUp = list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
            if (movedUp) {
                fullListTopNoProgressPasses = 0;
                updateScanOverlay("PREPARING FULL-LIST SCAN\nMoving to first offer…");
                record("Preparing full-list scan: moving to first offer…");
                scheduleExamine(500);
                return true;
            }
            // A single failed accessibility scroll can be transient. Do not assume
            // we are at the top until the list refuses to move upward three times.
            fullListTopNoProgressPasses++;
            if (fullListTopNoProgressPasses < 3) {
                updateScanOverlay("VERIFYING TOP OF LIST\nNo upward movement "
                        + fullListTopNoProgressPasses + "/3…");
                record("Verifying top of offer list: no upward movement "
                        + fullListTopNoProgressPasses + "/3");
                scheduleExamine(650);
                return true;
            }
            fullListTopNoProgressPasses = 0;
            fullListMovingToTop = false;
            fullListScanning = true;
            updateScanOverlay("TOP CONFIRMED\nStarting full-list scan…");
        }

        if (cards.isEmpty()) {
            pauseFullListScan("No readable offer cards; bottom NOT confirmed. Waiting before retry");
            return true;
        }
        int newCards = 0;
        for (Candidate c : cards) {
            String sig = signature(c);
            if (!fullListSeen.add(sig)) continue;
            newCards++;
            // Scan-only still evaluates the visible card data for navigating back
            // to one candidate. It NEVER invokes accept or reject actions.
            Decision.Result result = action(c, shoppingMinimum);
            BigDecimal rate = c.decision.perMile == null ? BigDecimal.ZERO : c.decision.perMile;
            if (result == Decision.Result.KEEP) {
                if (fullListBestSignature == null || rate.compareTo(fullListBestRate) > 0) {
                    fullListBestSignature = sig;
                    fullListBestRate = rate;
                }
            } else if (result == Decision.Result.REJECT) {
                if (fullListBestRejectSignature == null || rate.compareTo(fullListBestRejectRate) > 0) {
                    fullListBestRejectSignature = sig;
                    fullListBestRejectRate = rate;
                }
            }
        }
        fullListPages++;

        String viewport = viewportFingerprint(cards);
        if (fullListAwaitingForwardResult) {
            boolean viewportChanged = fullListLastViewportFingerprint == null
                    || !fullListLastViewportFingerprint.equals(viewport);
            if (!viewportChanged && newCards == 0) fullListNoProgressPasses++;
            else { fullListNoProgressPasses = 0; incompleteBottomSwipeAttempts = 0; lastBottomProbe = null; bottomStableProbes = 0; }
            fullListAwaitingForwardResult = false;
        }

        // No page cap, and no early two-pass finish: a momentary RecyclerView
        // stall is not proof that the user can actually see the final card.
        String previousViewport = fullListLastViewportFingerprint;
        fullListLastViewportFingerprint = viewport;
        boolean moved = list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
        if (moved) {
            fullListAwaitingForwardResult = true;
            updateScanOverlay("SCANNING ALL OFFERS\n" + fullListSeen.size()
                    + " unique offer(s) checked\nScrolling toward bottom…");
            record("Scanning all offers: " + fullListSeen.size() + " unique card(s) checked; scrolling…");
            scheduleExamine(250);
            return true;
        }

        // Do NOT treat one failed ACTION_SCROLL_FORWARD as the bottom. RecyclerView
        // can transiently reject accessibility scroll actions while it is laying out.
        // Confirm the same viewport, with no new offers, on three separate failed
        // forward attempts before declaring the list exhausted. There is still no
        // maximum number of pages/cards: this is purely an end-of-list proof.
        boolean sameViewport = previousViewport != null
                && previousViewport.equals(viewport);
        if (sameViewport && newCards == 0) fullListNoProgressPasses++;
        else fullListNoProgressPasses = 1;
        fullListLastViewportFingerprint = viewport;
        fullListAwaitingForwardResult = false;

        if (fullListNoProgressPasses >= 2 && lastOfferFullyExposedWithSpace(list, cards)) {
            // Full card and bottom padding are exposed, verify stable viewport.
            if (!viewport.equals(lastBottomProbe)) {
                lastBottomProbe = viewport;
                bottomStableProbes = 1;
                updateScanOverlay("VERIFYING BOTTOM\nLast card fully exposed\nChecking stability…");
                scheduleExamine(180L);
                return true;
            }
            updateScanOverlay("BOTTOM CONFIRMED\n" + fullListSeen.size()
                    + " unique offers checked\nReturning to candidate…");
            return finishFullListScan(shoppingMinimum);
        }
        if (fullListNoProgressPasses >= 3) {
            if (!lastOfferFullyExposedWithSpace(list, cards)) {
                updateScanOverlay("BOTTOM NOT YET EXPOSED\nLast card is still clipped\nScrolling to expose full card…");
                record("Bottom not confirmed: last offer card is not fully visible with space below it");
                // An accessibility ACTION_SCROLL_FORWARD failure often occurs before
                // the final RecyclerView item becomes visible. Actually swipe the
                // offer-list region, then read the newly settled viewport.
                if (incompleteBottomSwipeAttempts >= 4) {
                    updateScanOverlay("SCROLL STALLED — NOT AT BOTTOM\nLast offer is still clipped\nWaiting to retry scan…");
                    record("Scroll stalled: last card clipped after gesture retries; BOTTOM NOT CONFIRMED");
                    captureDebugScreenshotOnFailure("Scroll stalled before full card was exposed");
                    pauseFullListScan("Scroll stalled; bottom NOT confirmed. Waiting before retry");
                    return true;
                }
                incompleteBottomSwipeAttempts++;
                fullListNoProgressPasses = 0;
                fullListAwaitingForwardResult = false;
                performPhysicalListSwipe(list);
                return true;
            }
            // A fresh offer may arrive between the last two scroll attempts.
            // Require two stable bottom observations, separated by settling time.
            if (!viewport.equals(lastBottomProbe)) {
                lastBottomProbe = viewport;
                bottomStableProbes = 1;
                updateScanOverlay("VERIFYING STABLE BOTTOM\nWaiting for Spark updates…");
                scheduleExamine(180L);
                return true;
            }
            bottomStableProbes++;
            if (bottomStableProbes < 2) {
                scheduleExamine(400L);
                return true;
            }
            updateScanOverlay("BOTTOM CONFIRMED\n" + fullListSeen.size()
                    + " unique offer(s) checked\nFull last card + space below verified");
            record("Bottom confirmed: full last offer card is visible with space below it; "
                    + fullListSeen.size() + " unique offer(s) checked");
            return finishFullListScan(shoppingMinimum);
        }

        updateScanOverlay("VERIFYING BOTTOM\n" + fullListSeen.size()
                + " unique offer(s) checked\nNo movement " + fullListNoProgressPasses + "/3…");
        record("Verifying bottom of offer list: no movement "
                + fullListNoProgressPasses + "/3; " + fullListSeen.size() + " unique offer(s)");
        scheduleExamine(180);
        return true;
    }

    /**
     * First expand Spark's draggable offer sheet by swiping its upper handle.
     * This is deliberately separate from scrolling the RecyclerView content.
     * If expansion cannot be established, report it instead of claiming bottom.
     */
    private boolean ensureOfferDrawerExpanded(AccessibilityNodeInfo list) {
        if (scrollGestureInFlight) return false;
        Rect r = new Rect();
        list.getBoundsInScreen(r);
        if (r.isEmpty()) return false;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        float density = getResources().getDisplayMetrics().density;
        List<AccessibilityNodeInfo> handles = new ArrayList<>();
        AccessibilityNodeInfo screenRoot = getRootInActiveWindow();
        if (screenRoot != null) findByShortId(screenRoot, "swipeHandle", handles);
        Rect handleRect = new Rect();
        boolean handleVisible = false;
        for (AccessibilityNodeInfo h : handles) {
            if (h.isVisibleToUser()) { h.getBoundsInScreen(handleRect); handleVisible = true; break; }
        }
        int tolerance = Math.max(4, (int)(4 * density));
        if (drawerExpanded && handleVisible && Math.abs(r.top - verifiedDrawerTop) <= tolerance)
            return true;
        if (drawerExpanded) drawerStableDrags = 0;
        drawerExpanded = false;
        if (drawerExpansionAwaitingResult) {
            drawerExpansionAwaitingResult = false;
            drawerStableDrags = Math.abs(drawerPreviousListTop - r.top) <= tolerance
                    ? drawerStableDrags + 1 : 0;
            record("Drawer expansion probe: list top=" + r.top + "; stable drags=" + drawerStableDrags);
        }
        // Height alone never proves expansion. Two completed handle drags must
        // reach the same upper snap position, with the overlay removed for both.
        if (ScanEvidence.drawerAtTop(screenHeight, r.top, handleRect.top, handleVisible, drawerStableDrags)) {
            drawerExpanded = true;
            verifiedDrawerTop = r.top;
            drawerExpandAttempts = 0;
            record("Offer drawer expansion verified by handle drags; beginning offer-list scan");
            return true;
        }
        if (drawerExpandAttempts >= 5 || !handleVisible) {
            updateScanOverlay("DRAWER NOT VERIFIED\nWaiting before retrying handle expansion");
            record("Could not verify full drawer expansion; not scanning a partial drawer");
            resetFullListScan();
            fullListRestartNotBefore = SystemClock.elapsedRealtime() + 2500L;
            scheduleExamine(1000L);
            return false;
        }
        drawerPreviousListTop = r.top;
        drawerExpandAttempts++;
        int startY = handleRect.centerY();
        // Hide our window below so the drag can reach the top of Spark.
        int endY = Math.max((int)(24 * density), (int)(screenHeight * .035f));
        if (startY - endY < 12 * density) {
            updateScanOverlay("DRAWER POSITION UNCLEAR\nWaiting before scanning offers…");
            scheduleExamine(750L);
            return false;
        }
        Path path = new Path();
        int x = r.left + r.width()/2;
        path.moveTo(x, startY);
        path.lineTo(x, endY);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 520));
        long generation = scanGeneration;
        scrollGestureInFlight = true;
        gestureStartedAt = SystemClock.elapsedRealtime();
        updateScanOverlay("EXPANDING OFFER DRAWER\nDragging top handle upward…\nAttempt " + drawerExpandAttempts + "/5");
        hideOverlay(); // The status window must not intercept the handle or drag endpoint.
        boolean accepted = dispatchGesture(builder.build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                if (generation != scanGeneration) return;
                scrollGestureInFlight = false;
                if (generation == scanGeneration) {
                    drawerExpansionAwaitingResult = true;
                    scheduleExamine(900L);
                }
            }
            @Override public void onCancelled(GestureDescription gestureDescription) {
                if (generation != scanGeneration) return;
                scrollGestureInFlight = false;
                if (generation == scanGeneration) scheduleExamine(900L);
            }
        }, handler);
        if (!accepted) {
            scrollGestureInFlight = false;
            scheduleExamine(900L);
        }
        return false;
    }

    private void performPhysicalListSwipe(AccessibilityNodeInfo list) {
        if (scrollGestureInFlight) return;
        Rect r = new Rect();
        list.getBoundsInScreen(r);
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int startY = Math.min(r.bottom - 65, screenHeight - 100);
        int endY = Math.max(r.top + 90, startY - Math.max(310, r.height() / 2));
        if (r.width() < 150 || startY - endY < 120) {
            updateScanOverlay("SCROLL STALLED — NOT AT BOTTOM\nNo safe swipe area available");
            resetFullListScan();
            fullListRestartNotBefore = SystemClock.elapsedRealtime() + 4500L;
            scheduleExamine(4600L);
            return;
        }
        int x = r.left + r.width() / 2;
        Path path = new Path();
        path.moveTo(x, startY);
        path.lineTo(x, endY);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 390));
        long generation = scanGeneration;
        scrollGestureInFlight = true;
        gestureStartedAt = SystemClock.elapsedRealtime();
        updateScanOverlay("LAST CARD CLIPPED\nSwiping down the offer list…\nRetry "
                + incompleteBottomSwipeAttempts + "/4");
        boolean accepted = dispatchGesture(builder.build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                if (generation != scanGeneration) return;
                scrollGestureInFlight = false;
                if (generation == scanGeneration) {
                    fullListAwaitingForwardResult = true;
                    scheduleExamine(850L);
                }
            }
            @Override public void onCancelled(GestureDescription gestureDescription) {
                if (generation != scanGeneration) return;
                scrollGestureInFlight = false;
                if (generation == scanGeneration) {
                    record("Swipe interrupted; bottom not confirmed");
                    scheduleExamine(850L);
                }
            }
        }, handler);
        if (!accepted) {
            scrollGestureInFlight = false;
            scheduleExamine(400L);
        }
    }

    private boolean lastOfferFullyExposedWithSpace(AccessibilityNodeInfo list, List<Candidate> cards) {
        if (list == null || cards == null || cards.isEmpty()) return false;
        Rect listRect = new Rect();
        list.getBoundsInScreen(listRect);
        if (listRect.isEmpty()) return false;

        // Use the bottom-most visible offer's card container. A true end-of-list
        // state must show the complete final card plus visible list padding below it.
        Candidate bottom = null;
        int bottomButtonBottom = Integer.MIN_VALUE;
        for (Candidate c : cards) {
            if (c == null || c.button == null || !c.button.isVisibleToUser()) continue;
            Rect br = new Rect(); c.button.getBoundsInScreen(br);
            if (!br.isEmpty() && br.bottom > bottomButtonBottom) {
                bottomButtonBottom = br.bottom; bottom = c;
            }
        }
        if (bottom == null) return false;

        Rect cardRect = findSingleOfferCardBounds(bottom.button, list);
        if (cardRect == null || cardRect.isEmpty()) return false;
        int margin = Math.max(12, (int) (12f * getResources().getDisplayMetrics().density));
        // Inspect all visible offer-shaped regions, including a following card
        // whose action buttons/pay are not yet available to Candidate parsing.
        List<AccessibilityNodeInfo> regions = new ArrayList<>();
        findByShortId(list, "body", regions);
        findByShortId(list, "clickableLayout", regions);
        findByShortId(list, "estimateValue", regions);
        List<int[]> visibleRegions = new ArrayList<>();
        boolean totalVisible = false;
        for (AccessibilityNodeInfo node : regions) {
            if (!node.isVisibleToUser()) continue;
            Rect bounds = new Rect(); node.getBoundsInScreen(bounds);
            if (bounds.isEmpty()) continue;
            visibleRegions.add(new int[] { bounds.top, bounds.bottom });
            String id = node.getViewIdResourceName();
            if (id != null && id.endsWith(":id/estimateValue") && node.getText() != null
                    && node.getText().toString().contains("$") && cardRect.contains(bounds)
                    && listRect.contains(bounds)) totalVisible = true;
        }
        AccessibilityNodeInfo accept = matchingAccept(bottom.button);
        Rect rejectBounds = new Rect(), acceptBounds = new Rect();
        bottom.button.getBoundsInScreen(rejectBounds);
        if (accept != null) accept.getBoundsInScreen(acceptBounds);
        boolean buttonsVisible = accept != null && accept.isVisibleToUser()
                && !rejectBounds.isEmpty() && !acceptBounds.isEmpty()
                && listRect.contains(rejectBounds) && listRect.contains(acceptBounds);
        return ScanEvidence.bottom(listRect.top, listRect.bottom, cardRect.top, cardRect.bottom,
                margin, totalVisible, buttonsVisible, visibleRegions.toArray(new int[0][]));
    }

    private Rect findSingleOfferCardBounds(AccessibilityNodeInfo button, AccessibilityNodeInfo list) {
        AccessibilityNodeInfo scope = button;
        Rect best = null;
        for (int depth = 0; scope != null && depth < 24; depth++, scope = scope.getParent()) {
            if (scope.equals(list)) break;
            List<String> fields = new ArrayList<>();
            List<AccessibilityNodeInfo> reject = new ArrayList<>(), accept = new ArrayList<>();
            List<AccessibilityNodeInfo> confirm = new ArrayList<>(), keep = new ArrayList<>();
            scan(scope, fields, reject, accept, confirm, keep);
            if (reject.size() > 1 || accept.size() > 1 || !confirm.isEmpty()) break;
            if (reject.size() == 1 && reject.get(0).equals(button) && accept.size() == 1) {
                Rect r = new Rect(); scope.getBoundsInScreen(r);
                if (!r.isEmpty()) best = r;
            }
        }
        return best;
    }

    private boolean finishFullListScan(BigDecimal shoppingMinimum) {
        if (!getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.AUTO_SCREENSHOT, true))
            return completeFullListScan(shoppingMinimum);
        bottomCapturePending = true;
        bottomCaptureStartedAt = SystemClock.elapsedRealtime();
        long generation = scanGeneration;
        updateScanOverlay("BOTTOM VERIFIED — SAVING PROOF\nHolding list still for screenshot");
        appendActivity("Bottom geometry verified; capturing proof before returning to candidate");
        captureDebugScreenshot("Bottom confirmation proof", "cheese-bottom-proof.png", () -> {
            if (generation != scanGeneration || !bottomCapturePending) return;
            bottomCapturePending = false;
            AccessibilityNodeInfo root = getRootInActiveWindow();
            boolean scanningEnabled = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.SCAN_ONLY, true)
                    || getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false);
            if (!scanningEnabled || manualControlActive || root == null || root.getPackageName() == null
                    || !SPARK.contentEquals(root.getPackageName())) {
                appendActivity("Bottom capture finished after screen/control changed; scan discarded");
                resetFullListScan();
                return;
            }
            completeFullListScan(shoppingMinimum);
        });
        return true;
    }

    private boolean completeFullListScan(BigDecimal shoppingMinimum) {
        boolean scanOnly = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.SCAN_ONLY, true);
        // Scan-only is observation-only: after one complete verified pass, navigate
        // back to a candidate but never click Accept, Reject, or an offer detail.
        if (fullListBestSignature == null) fullListBestSignature = fullListBestRejectSignature;
        fullListBestRejectSignature = null;
        fullListAwaitingForwardResult = false;
        fullListNoProgressPasses = 0;
        if (fullListBestSignature == null) {
            int checked = fullListSeen.size();
            resetFullListScan();
            lastFullListScanAt = SystemClock.elapsedRealtime();
            scheduleExamine(1000L);
            record("Full list checked to bottom; " + checked + " unique offer(s), none readable/eligible");
            return true;
        }
        seekingFullListBest = true;
        fullListScanning = false;
        updateScanOverlay("BOTTOM CONFIRMED\n" + fullListSeen.size()
                + " CURRENT unique offer(s) checked\nLocating best offer…");
        record("Bottom confirmed: full current list checked; " + fullListSeen.size()
                + " unique offer(s); locating best offer…");
        // Keep the proof visible long enough for the user to actually see it.
        scheduleExamine(220);
        return true;
    }

    private String viewportFingerprint(List<Candidate> cards) {
        List<String> parts = new ArrayList<>();
        for (Candidate c : cards) {
            Rect r = new Rect();
            if (c.button != null) c.button.getBoundsInScreen(r);
            parts.add(signature(c) + "@" + r.top + ":" + r.bottom);
        }
        java.util.Collections.sort(parts);
        return String.join("|", parts);
    }

    private void pauseFullListScan(String reason) {
        resetFullListScan();
        fullListRestartNotBefore = SystemClock.elapsedRealtime() + 2500L;
        updateScanOverlay("SCAN PAUSED — NO ACTIONS\n" + reason);
        record(reason);
        scheduleExamine(1000L);
    }

    private void resetFullListScan() {
        bottomCapturePending = false;
        fullListStartedAt = 0L;
        bestHeaderScrollAttempts = 0;
        fullListMovingToTop = false;
        fullListScanning = false;
        seekingFullListBest = false;
        fullListSeen.clear();
        fullListBestSignature = null;
        fullListBestRate = null;
        fullListBestRejectSignature = null;
        fullListBestRejectRate = null;
        fullListPages = 0;
        fullListLastViewportFingerprint = null;
        fullListAwaitingForwardResult = false;
        fullListNoProgressPasses = 0;
        fullListTopNoProgressPasses = 0;
        lastBottomProbe = null;
        bottomStableProbes = 0;
        incompleteBottomSwipeAttempts = 0;
        scanGeneration++;
        drawerExpanded = false;
        drawerExpandAttempts = 0;
        drawerStableDrags = 0;
        verifiedDrawerTop = -1;
        drawerPreviousListTop = -1;
        drawerExpansionAwaitingResult = false;
    }

    private void findByShortId(AccessibilityNodeInfo node, String shortId, List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        String id = node.getViewIdResourceName();
        if (id != null && (id.equals(shortId) || id.endsWith(":id/" + shortId) || id.endsWith("/" + shortId)))
            out.add(node);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) findByShortId(child, shortId, out);
        }
    }

    private static final class Candidate {
        final AccessibilityNodeInfo button;
        AccessibilityNodeInfo detailsTarget;
        final Decision decision;
        final String store;
        final boolean shopping;
        final Integer items;
        final boolean bulky;
        Candidate(AccessibilityNodeInfo button, AccessibilityNodeInfo detailsTarget, Decision decision, List<String> fields) {
            this(button, detailsTarget, decision, fields, null);
        }
        Candidate(AccessibilityNodeInfo button, AccessibilityNodeInfo detailsTarget, Decision decision, List<String> fields, String forcedStore) {
            this.button = button;
            this.detailsTarget = detailsTarget;
            this.decision = decision;
            String parsedStore = StoreRule.identify(fields);
            this.store = forcedStore != null ? forcedStore : parsedStore;
            this.shopping = Decision.isShopping(fields);
            this.items = Decision.itemCount(fields);
            String joined = String.join(" ", fields).toLowerCase(Locale.US);
            this.bulky = joined.contains("bulky item") || joined.contains("heavy item");
        }
        Candidate(Candidate base, Decision verifiedDecision) {
            this.button = base.button;
            this.detailsTarget = base.detailsTarget;
            this.decision = verifiedDecision;
            this.store = base.store;
            this.shopping = base.shopping;
            this.items = base.items;
            this.bulky = base.bulky;
        }
    }

    private Candidate findCard(AccessibilityNodeInfo button, BigDecimal minimum) {
        cardDiagnostic = "No ancestor with one Reject/Accept pair";
        String lastPair = "no single-button pair found";
        AccessibilityNodeInfo scope = button;
        for (int depth = 0; scope != null && depth < 30; depth++, scope = scope.getParent()) {
            List<String> fields = new ArrayList<>();
            List<AccessibilityNodeInfo> reject = new ArrayList<>(), accept = new ArrayList<>();
            List<AccessibilityNodeInfo> confirm = new ArrayList<>(), keep = new ArrayList<>();
            scan(scope, fields, reject, accept, confirm, keep);
            // Count even offscreen buttons for boundaries: never join neighboring cards.
            if (reject.size() > 1 || accept.size() > 1 || !confirm.isEmpty()) {
                cardDiagnostic = "Reached shared container (Reject=" + reject.size() + ", Accept=" + accept.size()
                        + "). Last individual scope: " + lastPair;
                return null;
            }
            if (reject.size() == 1 && reject.get(0).equals(button) && accept.size() == 1) {
                lastPair = Decision.diagnostic(fields, minimum);
                cardDiagnostic = lastPair;
                Decision decision = Decision.evaluate(fields, minimum);
                if (decision.result != Decision.Result.UNKNOWN) return new Candidate(button, findDetailsTarget(scope), decision, fields);
            }
        }
        return null;
    }

    private Candidate findPositionedCard(AccessibilityNodeInfo root, AccessibilityNodeInfo button, BigDecimal minimum) {
        List<String> all = new ArrayList<>();
        List<AccessibilityNodeInfo> reject = new ArrayList<>(), accept = new ArrayList<>();
        List<AccessibilityNodeInfo> confirm = new ArrayList<>(), keep = new ArrayList<>();
        scan(root, all, reject, accept, confirm, keep);
        if (!confirm.isEmpty() || !reject.contains(button)) return null;
        Rect target = new Rect(), window = new Rect();
        button.getBoundsInScreen(target);
        root.getBoundsInScreen(window);
        if (target.isEmpty() || !window.contains(target)) return null;
        int top = window.top;
        for (AccessibilityNodeInfo other : reject) {
            if (other.equals(button)) continue;
            Rect r = new Rect(); other.getBoundsInScreen(r);
            if (r.isEmpty()) continue;
            // Reject overlapping rows: these could be duplicate or side-by-side cards.
            if (r.top < target.bottom && r.bottom > target.top) {
                cardDiagnostic = "Overlapping Reject buttons; cannot identify a single row";
                return null;
            }
            if (r.bottom <= target.top) top = Math.max(top, r.bottom);
        }
        int paired = 0;
        for (AccessibilityNodeInfo other : accept) {
            if (!other.isVisibleToUser()) continue;
            Rect r = new Rect(); other.getBoundsInScreen(r);
            int overlap = Math.min(r.bottom, target.bottom) - Math.max(r.top, target.top);
            if (!r.isEmpty() && r.left >= target.right && overlap > 0
                    && overlap * 2 >= Math.min(r.height(), target.height())) paired++;
        }
        if (paired != 1) { cardDiagnostic = "Position check: matching Accept buttons=" + paired; return null; }
        List<OfferRegion.Text> positioned = new ArrayList<>();
        scanPositions(root, positioned);
        List<String> fields = OfferRegion.select(positioned, window.left, top, window.right, target.top);
        Decision decision = Decision.evaluate(fields, minimum);
        cardDiagnostic = "Position check: " + Decision.diagnostic(fields, minimum);
        return decision.result == Decision.Result.UNKNOWN ? null : new Candidate(button, null, decision, fields);
    }

    private void scanPositions(AccessibilityNodeInfo node, List<OfferRegion.Text> fields) {
        if (node.isVisibleToUser()) {
            Rect r = new Rect(); node.getBoundsInScreen(r);
            CharSequence text = node.getText(), description = node.getContentDescription();
            String viewId = node.getViewIdResourceName();
            // Spark offer details expose the total offer amount in estimatedValueView.
            // Preserve that label during position-based parsing so component amounts
            // such as base pay, surge, or tip cannot make the total ambiguous.
            if (text != null && text.length() > 0 && viewId != null
                    && viewId.endsWith(":id/estimatedValueView")) {
                fields.add(new OfferRegion.Text("Estimated pay " + text.toString(), r.left, r.top, r.right, r.bottom));
            }
            if (text != null && text.length() > 0) fields.add(new OfferRegion.Text(text.toString(), r.left, r.top, r.right, r.bottom));
            if (description != null && description.length() > 0 && (text == null || !description.toString().contentEquals(text)))
                fields.add(new OfferRegion.Text(description.toString(), r.left, r.top, r.right, r.bottom));
        }
        for (int i=0; i<node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) scanPositions(child, fields);
        }
    }

    private Decision.Result action(Candidate c, BigDecimal shoppingMinimum) {
        if (c.decision.result == Decision.Result.UNKNOWN) return Decision.Result.UNKNOWN;
        Decision.Result base = StoreRule.result(c.store, getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getStringSet(MainActivity.REJECT_STORES, java.util.Collections.emptySet()), c.decision);
        if (base != Decision.Result.KEEP) return base;
        if (!c.shopping || c.items == null) return base;
        if (c.items <= 0 || c.decision.pay == null || shoppingMinimum == null || shoppingMinimum.signum() <= 0)
            return Decision.Result.UNKNOWN;
        return c.decision.pay.compareTo(shoppingMinimum.multiply(new BigDecimal(c.items))) < 0
                ? Decision.Result.REJECT : Decision.Result.KEEP;
    }

    private boolean sameAmount(BigDecimal a, BigDecimal b) {
        return a != null && b != null && a.compareTo(b) == 0;
    }

    private AccessibilityNodeInfo findPositionedDetailsTarget(AccessibilityNodeInfo root, AccessibilityNodeInfo rejectButton) {
        if (root == null || rejectButton == null) return null;
        Rect rejectRect = new Rect();
        rejectButton.getBoundsInScreen(rejectRect);
        if (rejectRect.isEmpty()) return null;
        // Never borrow a previous card's header when this card's own header
        // is offscreen. Bound the search below the preceding Reject row.
        List<String> ignoredFields = new ArrayList<>();
        List<AccessibilityNodeInfo> rejects = new ArrayList<>(), accepts = new ArrayList<>();
        List<AccessibilityNodeInfo> confirms = new ArrayList<>(), keeps = new ArrayList<>();
        scan(root, ignoredFields, rejects, accepts, confirms, keeps);
        int precedingRowBottom = Integer.MIN_VALUE;
        for (AccessibilityNodeInfo other : rejects) {
            if (other.equals(rejectButton)) continue;
            Rect bounds = new Rect(); other.getBoundsInScreen(bounds);
            if (!bounds.isEmpty() && bounds.bottom <= rejectRect.top)
                precedingRowBottom = Math.max(precedingRowBottom, bounds.bottom);
        }
        List<AccessibilityNodeInfo> candidates = new ArrayList<>();
        findByShortId(root, "clickableLayout", candidates);
        findByShortId(root, "buttonDetailsCta", candidates);
        AccessibilityNodeInfo best = null;
        int bestGap = Integer.MAX_VALUE;
        for (AccessibilityNodeInfo node : candidates) {
            if (!node.isVisibleToUser()) continue;
            AccessibilityNodeInfo clickable = node;
            for (int i = 0; i < 3 && clickable != null && !clickable.isClickable(); i++) clickable = clickable.getParent();
            if (clickable == null || !clickable.isClickable() || !clickable.isVisibleToUser()) continue;
            Rect r = new Rect(); clickable.getBoundsInScreen(r);
            if (r.isEmpty()) continue;
            int horizontalOverlap = Math.min(r.right, rejectRect.right) - Math.max(r.left, rejectRect.left);
            if (horizontalOverlap <= 0 || r.top < precedingRowBottom
                    || r.bottom > rejectRect.top || r.top >= rejectRect.top) continue;
            int gap = rejectRect.top - r.bottom;
            if (gap < bestGap) { bestGap = gap; best = clickable; }
        }
        return best;
    }

    private AccessibilityNodeInfo matchingAccept(AccessibilityNodeInfo rejectButton) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || rejectButton == null) return null;
        List<String> fields = new ArrayList<>();
        List<AccessibilityNodeInfo> rejects = new ArrayList<>(), accepts = new ArrayList<>(), confirms = new ArrayList<>(), keeps = new ArrayList<>();
        scan(root, fields, rejects, accepts, confirms, keeps);
        Rect rr = new Rect(); rejectButton.getBoundsInScreen(rr);
        AccessibilityNodeInfo match = null;
        for (AccessibilityNodeInfo a : accepts) {
            if (!a.isVisibleToUser()) continue;
            Rect ar = new Rect(); a.getBoundsInScreen(ar);
            int overlap = Math.min(ar.bottom, rr.bottom) - Math.max(ar.top, rr.top);
            if (!ar.isEmpty() && ar.left >= rr.right && overlap > 0 && overlap * 2 >= Math.min(ar.height(), rr.height())) {
                if (match != null) return null;
                match = a;
            }
        }
        return match;
    }

    private void updateOverlay(Candidate card, BigDecimal shoppingMinimum) {
        if (card == null) { hideOverlay(); return; }
        String sig = signature(card);
        if (sig.equals(overlaySuppressedSignature)) { hideOverlay(); return; }
        overlayCandidate = card;
        if (overlayView == null) createOverlay();
        boolean scanOnlyMode = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.SCAN_ONLY, true);
        overlayDecline.setEnabled(!scanOnlyMode);
        overlayClose.setEnabled(true);
        overlayAccept.setEnabled(!scanOnlyMode);
        String status = describe(card, shoppingMinimum);
        String alert = card.bulky ? "BROKE BACK ALERT — bulky/heavy item\n" : "";
        if (card.shopping && card.items == null) status = alert + "BEST OFFER → checking Shopping items\n" + status;
        else if (sig.equals(lastFullListBestSignature) && SystemClock.elapsedRealtime() - lastFullListScanAt < 8000L)
            status = alert + "BEST OFFER — FULL LIST CHECKED\n" + status;
        else status = alert + "BEST VISIBLE OFFER\n" + status;
        overlayStatus.setText(status);
        if (overlayView.getParent() == null) {
            try { windowManager.addView(overlayView, overlayParams()); } catch (Exception ignored) {}
        }
    }

    private void updateScanOverlay(String status) {
        overlayCandidate = null;
        if (overlayView == null) createOverlay();
        overlayStatus.setText(status);
        overlayDecline.setEnabled(false);
        overlayAccept.setEnabled(false);
        overlayClose.setEnabled(true);
        if (overlayView.getParent() == null) {
            try { windowManager.addView(overlayView, overlayParams()); } catch (Exception ignored) {}
        }
    }

    private WindowManager.LayoutParams overlayParams() {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                android.graphics.PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        return p;
    }

    private void createOverlay() {
        overlayView = new LinearLayout(this);
        overlayView.setOrientation(LinearLayout.VERTICAL);
        overlayView.setPadding(18, 12, 18, 12);
        overlayView.setBackgroundColor(Color.argb(235, 30, 30, 30));
        overlayStatus = new TextView(this);
        overlayStatus.setTextColor(Color.WHITE);
        overlayStatus.setTextSize(13f);
        overlayStatus.setMaxLines(4);
        overlayView.addView(overlayStatus, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        overlayDecline = new Button(this); overlayDecline.setText("DECLINE");
        overlayClose = new Button(this); overlayClose.setText("CLOSE");
        overlayAccept = new Button(this); overlayAccept.setText("ACCEPT");
        row.addView(overlayDecline, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(overlayClose, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(overlayAccept, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        overlayView.addView(row);

        overlayDecline.setOnClickListener(v -> {
            if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                    .getBoolean(MainActivity.SCAN_ONLY, true)) return;
            Candidate c = overlayCandidate;
            if (c == null || c.button == null || !c.button.refresh() || !c.button.isVisibleToUser()) return;
            pendingCard = c; pendingUntil = SystemClock.elapsedRealtime() + 15000L; manualPendingConfirm = true;
            if (c.button.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                record("Overlay DECLINE pressed: " + describe(c, currentShoppingMinimum()));
                scheduleExamine(500);
            } else { manualPendingConfirm = false; pendingUntil = 0L; }
        });
        overlayClose.setOnClickListener(v -> {
            if (overlayCandidate != null) overlaySuppressedSignature = signature(overlayCandidate);
            hideOverlay();
        });
        overlayAccept.setOnClickListener(v -> {
            if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                    .getBoolean(MainActivity.SCAN_ONLY, true)) return;
            Candidate c = overlayCandidate;
            AccessibilityNodeInfo a = c == null ? null : matchingAccept(c.button);
            if (a != null && a.refresh() && a.isVisibleToUser() && a.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                record("Overlay ACCEPT pressed: " + describe(c, currentShoppingMinimum()));
                hideOverlay();
            }
        });
    }

    private void hideOverlay() {
        overlayCandidate = null;
        if (overlayView != null && overlayView.getParent() != null) {
            try { windowManager.removeView(overlayView); } catch (Exception ignored) {}
        }
    }

    private AccessibilityNodeInfo findDetailsTarget(AccessibilityNodeInfo node) {
        if (node == null) return null;
        String id = node.getViewIdResourceName();
        if (node.isClickable() && id != null && (id.endsWith(":id/clickableLayout") || id.endsWith(":id/buttonDetailsCta")))
            return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo found = findDetailsTarget(child);
            if (found != null) return found;
        }
        return null;
    }

    private String signature(Candidate c) { return c.store + "/" + c.decision.pay + "/" + c.decision.miles; }
    private String describe(Candidate c, BigDecimal shoppingMinimum) {
        Decision d = c.decision;
        if (d.result == Decision.Result.UNKNOWN) return "REVIEW REQUIRED: " + d.explanation
                + "; pay=" + d.pay + "; no verified trip mileage/rating";
        if (c.store == null) return "SKIP: store number missing or conflicting; $" + d.pay + " / " + d.miles + " mi";
        boolean storeRejected = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getStringSet(MainActivity.REJECT_STORES, java.util.Collections.emptySet()).contains(c.store);
        String extra = "";
        if (c.shopping) {
            if (c.items == null) extra = " / Shopping items: open details to check";
            else {
                BigDecimal perItem = Decision.dollarsPerItem(d.pay, c.items);
                extra = " / Shopping " + c.items + " items" + (perItem == null ? "" : " / $" + perItem + "/item")
                        + " (min $" + shoppingMinimum + "/item)";
            }
        }
        String reason;
        if (storeRejected) reason = "store is on auto-reject list";
        else if (d.result == Decision.Result.REJECT) reason = d.explanation;
        else if (c.shopping && c.items != null && action(c, shoppingMinimum) == Decision.Result.REJECT) reason = "Below Shopping $/item minimum";
        else reason = d.explanation;
        return action(c, shoppingMinimum) + " #" + c.store + " $" + d.pay + " / " + d.miles + " mi / $" + d.perMile + "/mi"
                + extra + " — " + reason;
    }

    // Diagnostic-only discovery. Do not tap unknown controls, ACCEPT or REJECT.
    // The item-list entry point varies with Spark revisions, so first record
    // verifiable labels/IDs and capture a local screenshot for follow-up.
    private void discoverShoppingItems(AccessibilityNodeInfo root, Candidate candidate) {
        String key = signature(candidate);
        if (key.equals(lastItemDiscoverySignature)) return;
        lastItemDiscoverySignature = key;
        List<String> entryPoints = new ArrayList<>();
        discoverItemControls(root, entryPoints);
        String found = entryPoints.isEmpty() ? "No identifiable item-list entry point in current details" :
                "Possible item-list controls: " + String.join("; ", entryPoints);
        appendActivity("SHOPPING ITEM DISCOVERY: " + found);
        updateScanOverlay("SHOPPING ITEM DISCOVERY\n" + candidate.items + " items; no automatic actions\n" +
                (entryPoints.isEmpty() ? "Item-list entry not identified" : "Item-list controls recorded"));
        captureDebugScreenshotOnFailure("Shopping item-list discovery for store #" + candidate.store);
    }

    private void discoverItemControls(AccessibilityNodeInfo node, List<String> found) {
        if (node == null || found.size() >= 12) return;
        String id = node.getViewIdResourceName();
        CharSequence tx = node.getText();
        CharSequence cd = node.getContentDescription();
        String label = (tx == null ? "" : tx.toString()) + " " +
                (cd == null ? "" : cd.toString());
        String match = ((id == null ? "" : id) + " " + label).toLowerCase(Locale.US);
        // Only list controls explicitly identified as an item/product link;
        // never inspect addresses, customer names or map nodes.
        if (node.isVisibleToUser() && (match.contains("item") || match.contains("product"))
                && (node.isClickable() || node.isScrollable()) && label.length() < 110) {
            found.add("id=" + (id == null ? "none" : id) + " label=" + label.trim()
                    + " clickable=" + node.isClickable() + " scrollable=" + node.isScrollable());
        }
        for (int i = 0; i < node.getChildCount() && found.size() < 12; i++)
            discoverItemControls(node.getChild(i), found);
    }

    private BigDecimal currentShoppingMinimum() {
        try { return new BigDecimal(getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getString(MainActivity.SHOPPING_DOLLARS_PER_ITEM, "1.00")); }
        catch (NumberFormatException e) { return new BigDecimal("1.00"); }
    }

    // Screenshot API exists on Android 11+; save only the latest in internal storage.
    // Never upload automatically, and never write to shared gallery storage.
    private void captureDebugScreenshotOnFailure(String reason) {
        if (!getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.AUTO_SCREENSHOT, true)) return;
        captureDebugScreenshot(reason);
    }

    private void captureDebugScreenshot(String reason) {
        captureDebugScreenshot(reason, "cheese-debug-screen.png", () -> { });
    }

    private void captureDebugScreenshot(String reason, String filename, Runnable finished) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastDebugCaptureAt < 2500L || android.os.Build.VERSION.SDK_INT < 30) {
            appendActivity("Screenshot skipped (cooldown or Android version): " + reason);
            finished.run(); return;
        }
        lastDebugCaptureAt = now;
        try {
            takeScreenshot(android.view.Display.DEFAULT_DISPLAY, getMainExecutor(),
                    new TakeScreenshotCallback() {
                        @Override public void onSuccess(ScreenshotResult result) {
                            HardwareBuffer buffer = result.getHardwareBuffer();
                            if (buffer == null) { appendActivity("Screenshot returned no buffer: " + reason); finished.run(); return; }
                            Bitmap hardware = null;
                            Bitmap bitmap = null;
                            try {
                                hardware = Bitmap.wrapHardwareBuffer(buffer, result.getColorSpace());
                                if (hardware != null) bitmap = hardware.copy(Bitmap.Config.ARGB_8888, false);
                                if (bitmap != null) {
                                    try (FileOutputStream out = new FileOutputStream(
                                            new File(getFilesDir(), filename))) {
                                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                                    }
                                    appendActivity("Screenshot saved locally: " + reason);
                                }
                            } catch (Exception e) { appendActivity("Screenshot save failed: " + e.getMessage()); }
                            finally {
                                if (bitmap != null) bitmap.recycle();
                                if (hardware != null) hardware.recycle();
                                buffer.close();
                                finished.run();
                            }
                        }
                        @Override public void onFailure(int errorCode) {
                            appendActivity("Screenshot not available (Android error " + errorCode + "): " + reason);
                            finished.run();
                        }
                    });
        } catch (Exception e) { appendActivity("Screenshot capture unavailable: " + e.getMessage()); finished.run(); }
    }

    private void appendActivity(String line) {
        android.content.SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        String stamp = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        String previous = prefs.getString(MainActivity.ACTIVITY_LOG, "");
        String updated = previous + stamp + "  " + line.replace('\n', ' ') + "\n";
        if (updated.length() > 14000) updated = updated.substring(updated.length() - 14000);
        prefs.edit().putString(MainActivity.ACTIVITY_LOG, updated).apply();
    }

    private void record(String value) {
        if (!value.equals(getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.LAST, ""))) {
            getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit().putString(MainActivity.LAST, value).apply();
            appendActivity(value);
        }
    }

    private void recordDiagnostic(String value) {
        if (!value.equals(getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.LAST_DIAGNOSTIC, "")))
            getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit().putString(MainActivity.LAST_DIAGNOSTIC, value).apply();
    }

    private void scan(AccessibilityNodeInfo node, List<String> fields,
                      List<AccessibilityNodeInfo> reject, List<AccessibilityNodeInfo> accept,
                      List<AccessibilityNodeInfo> confirm, List<AccessibilityNodeInfo> keep) {
        CharSequence text = node.getText(), description = node.getContentDescription();
        String viewId = node.getViewIdResourceName();
        // On Spark's opened offer-detail screen, estimatedValueView is the
        // actual total offer pay. Other nearby dollar values can be base pay,
        // surge, or tip. Add a synthetic labeled field so Decision.evaluate()
        // can identify the total without confusing those components.
        if (text != null && text.length() > 0 && viewId != null
                && viewId.endsWith(":id/estimatedValueView")) {
            fields.add("Estimated pay " + text.toString());
        }
        if (text != null && text.length() > 0) fields.add(text.toString());
        if (description != null && description.length() > 0 && (text == null || !description.toString().contentEquals(text))) fields.add(description.toString());
        String label = text != null ? text.toString().trim() : description != null ? description.toString().trim() : "";
        String normalized = label.toLowerCase(Locale.US).replaceAll("\\s+", " ");
        List<AccessibilityNodeInfo> buttons = null;
        if (normalized.matches("reject|decline")) buttons = reject;
        else if (normalized.equals("accept")) buttons = accept;
        else if (normalized.equals("reject offer")) buttons = confirm;
        else if (normalized.equals("keep offer")) buttons = keep;
        if (buttons != null && node.isEnabled()) {
            AccessibilityNodeInfo clickable = node;
            for (int i = 0; i < 2 && clickable != null && !clickable.isClickable(); i++) clickable = clickable.getParent();
            if (clickable != null && clickable.isClickable() && !buttons.contains(clickable)) buttons.add(clickable);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) scan(child, fields, reject, accept, confirm, keep);
        }
    }
    @Override public void onInterrupt() {
        appendActivity("Accessibility interrupted; scan cancelled");
        handler.removeCallbacksAndMessages(null); examineScheduled = false;
        scrollGestureInFlight = false; resetFullListScan(); hideOverlay();
        handler.postDelayed(scanWatchdog, 2000L);
    }

    @Override public void onDestroy() {
        hideOverlay();
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
