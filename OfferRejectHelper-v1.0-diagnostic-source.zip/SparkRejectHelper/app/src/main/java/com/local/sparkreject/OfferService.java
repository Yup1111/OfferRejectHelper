package com.local.sparkreject;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class OfferService extends AccessibilityService {
    private static final String SPARK = "com.walmart.sparkdriver";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private AccessibilityNodeInfo handledButton = null;
    private String handledOffer = null;
    private long pendingUntil = 0L;
    private boolean busy = false;
    private Candidate pendingCard;
    private String cardDiagnostic = "";

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        record("Accessibility service active; waiting for a Spark offer");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getPackageName() == null || !SPARK.contentEquals(event.getPackageName())) return;
        if (!getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.OBSERVE, true)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.DIAGNOSTIC, true)) return;
        if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.LAST, "").contains("waiting for a Spark offer"))
            record("Spark event received; waiting for an offer card");
        if (busy) return;
        busy = true;
        handler.postDelayed(() -> { busy = false; examine(); }, 350);
    }

    private void examine() {
        if (!getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.OBSERVE, true)
                && !getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.DIAGNOSTIC, true)) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) { record("Spark event received, but no readable window"); return; }
        if (root.getPackageName() == null || !SPARK.contentEquals(root.getPackageName())) {
            // A delayed Spark event can run after the user switches back to
            // this helper. Preserve the last Spark observation in that case.
            return;
        }
        if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.DIAGNOSTIC, true))
            recordDiagnostic(AccessibilityDiagnostics.snapshot(root));
        List<String> fields = new ArrayList<>();
        List<AccessibilityNodeInfo> rejectButtons = new ArrayList<>();
        List<AccessibilityNodeInfo> acceptButtons = new ArrayList<>();
        List<AccessibilityNodeInfo> confirmButtons = new ArrayList<>();
        List<AccessibilityNodeInfo> keepButtons = new ArrayList<>();
        scan(root, fields, rejectButtons, acceptButtons, confirmButtons, keepButtons);
        String visibleText = String.join(" ", fields).toLowerCase(Locale.US).replaceAll("\\s+", " ");

        if (getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false)
                && pendingUntil > SystemClock.elapsedRealtime()
                && pendingCard != null && action(pendingCard) == Decision.Result.REJECT
                && visibleText.contains("are you sure you want to reject this offer")
                && visibleText.contains("once you reject an offer")
                && keepButtons.size() == 1 && confirmButtons.size() == 1
                && confirmButtons.get(0).isVisibleToUser()) {
            pendingUntil = 0L; // Do not click this dialog twice if it redraws.
            boolean clicked = confirmButtons.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK);
            record(clicked ? "Confirmed automatic rejection" : "Could not click Reject Offer confirmation");
            if (clicked) handler.postDelayed(this::examine, 700);
            return;
        }
        boolean automatic = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false);
        if (!automatic) pendingUntil = 0L;
        if (pendingUntil > SystemClock.elapsedRealtime()) return;
        pendingUntil = 0L;
        // Never act on underlying cards while a confirmation is open.
        if (!confirmButtons.isEmpty()) return;
        BigDecimal minimum;
        try { minimum = new BigDecimal(getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.MINIMUM, "2.00")); }
        catch (NumberFormatException e) { record("Invalid minimum dollars per mile"); return; }
        if (handledButton != null && !rejectButtons.contains(handledButton)) {
            handledButton = null;
            handledOffer = null;
        }
        List<String> summaries = new ArrayList<>();
        Candidate chosen = null;
        int unreadable = 0;
        for (AccessibilityNodeInfo button : rejectButtons) {
            if (!button.isVisibleToUser()) continue;
            Candidate card = findCard(button, minimum);
            if (card == null || card.store == null) {
                Candidate positioned = findPositionedCard(root, button, minimum);
                if (positioned != null) card = positioned;
            }
            if (card == null) { unreadable++; summaries.add("Unreadable card: " + cardDiagnostic); continue; }
            summaries.add(describe(card));
            if (chosen == null && action(card) == Decision.Result.REJECT
                    && !(button.equals(handledButton) && signature(card).equals(handledOffer))) chosen = card;
        }
        record((automatic ? "Auto: " : "Check only: ") + String.join("; ", summaries)
                + (unreadable > 0 ? "; skipped " + unreadable + " card(s)" : "")
                + (summaries.isEmpty() && unreadable == 0 ? "Waiting for visible offer cards" : ""));
        if (!automatic || chosen == null) return;
        // Re-read the same card immediately before clicking; arrivals can change the list.
        if (!chosen.button.refresh() || !chosen.button.isVisibleToUser()) return;
        AccessibilityNodeInfo freshRoot = getRootInActiveWindow();
        if (freshRoot == null || freshRoot.getPackageName() == null || !SPARK.contentEquals(freshRoot.getPackageName())) return;
        Candidate fresh = findCard(chosen.button, minimum);
        if (fresh == null || fresh.store == null) {
            Candidate positioned = findPositionedCard(freshRoot, chosen.button, minimum);
            if (positioned != null) fresh = positioned;
        }
        if (fresh == null || action(fresh) != Decision.Result.REJECT
                || !signature(fresh).equals(signature(chosen))) return;
        if (!getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.ENABLED, false)) return;
        handledButton = fresh.button;
        handledOffer = signature(fresh);
        pendingCard = fresh;
        pendingUntil = SystemClock.elapsedRealtime() + 15000L;
        if (!fresh.button.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            pendingUntil = 0L;
            record("Reject button click failed: " + describe(fresh));
        } else {
            record("Pressed Reject; waiting for confirmation: " + describe(fresh));
            handler.postDelayed(this::examine, 700);
        }
    }

    private static final class Candidate {
        final AccessibilityNodeInfo button;
        final Decision decision;
        final String store;
        Candidate(AccessibilityNodeInfo button, Decision decision, List<String> fields) { this.button = button; this.decision = decision; this.store = StoreRule.identify(fields); }
    }

    private Candidate findCard(AccessibilityNodeInfo button, BigDecimal minimum) {
        cardDiagnostic = "No ancestor with one Reject/Accept pair";
        String lastPair = "no single-button pair found";
        AccessibilityNodeInfo scope = button;
        for (int depth = 0; scope != null && depth < 30; depth++, scope = scope.getParent()) {
            List<String> fields = new ArrayList<>();
            List<AccessibilityNodeInfo> reject = new ArrayList<>(), accept = new ArrayList<>();
            List<AccessibilityNodeInfo> confirm = new ArrayList<>(), keep = new ArrayList<>();
            scan(scope, fields, reject, accept, confirm, keep);
            // Count even offscreen buttons for boundaries: never join neighboring cards.
            if (reject.size() > 1 || accept.size() > 1 || !confirm.isEmpty()) {
                cardDiagnostic = "Reached shared container (Reject=" + reject.size() + ", Accept=" + accept.size()
                        + "). Last individual scope: " + lastPair;
                return null;
            }
            if (reject.size() == 1 && reject.get(0).equals(button) && accept.size() == 1) {
                lastPair = Decision.diagnostic(fields, minimum);
                cardDiagnostic = lastPair;
                Decision decision = Decision.evaluate(fields, minimum);
                if (decision.result != Decision.Result.UNKNOWN) return new Candidate(button, decision, fields);
            }
        }
        return null;
    }

    private Candidate findPositionedCard(AccessibilityNodeInfo root, AccessibilityNodeInfo button, BigDecimal minimum) {
        List<String> all = new ArrayList<>();
        List<AccessibilityNodeInfo> reject = new ArrayList<>(), accept = new ArrayList<>();
        List<AccessibilityNodeInfo> confirm = new ArrayList<>(), keep = new ArrayList<>();
        scan(root, all, reject, accept, confirm, keep);
        if (!confirm.isEmpty() || !reject.contains(button)) return null;
        Rect target = new Rect(), window = new Rect();
        button.getBoundsInScreen(target);
        root.getBoundsInScreen(window);
        if (target.isEmpty() || !window.contains(target)) return null;
        int top = window.top;
        for (AccessibilityNodeInfo other : reject) {
            if (other.equals(button)) continue;
            Rect r = new Rect(); other.getBoundsInScreen(r);
            if (r.isEmpty()) continue;
            // Reject overlapping rows: these could be duplicate or side-by-side cards.
            if (r.top < target.bottom && r.bottom > target.top) {
                cardDiagnostic = "Overlapping Reject buttons; cannot identify a single row";
                return null;
            }
            if (r.bottom <= target.top) top = Math.max(top, r.bottom);
        }
        int paired = 0;
        for (AccessibilityNodeInfo other : accept) {
            if (!other.isVisibleToUser()) continue;
            Rect r = new Rect(); other.getBoundsInScreen(r);
            int overlap = Math.min(r.bottom, target.bottom) - Math.max(r.top, target.top);
            if (!r.isEmpty() && r.left >= target.right && overlap > 0
                    && overlap * 2 >= Math.min(r.height(), target.height())) paired++;
        }
        if (paired != 1) { cardDiagnostic = "Position check: matching Accept buttons=" + paired; return null; }
        List<OfferRegion.Text> positioned = new ArrayList<>();
        scanPositions(root, positioned);
        List<String> fields = OfferRegion.select(positioned, window.left, top, window.right, target.top);
        Decision decision = Decision.evaluate(fields, minimum);
        cardDiagnostic = "Position check: " + Decision.diagnostic(fields, minimum);
        return decision.result == Decision.Result.UNKNOWN ? null : new Candidate(button, decision, fields);
    }

    private void scanPositions(AccessibilityNodeInfo node, List<OfferRegion.Text> fields) {
        if (node.isVisibleToUser()) {
            Rect r = new Rect(); node.getBoundsInScreen(r);
            CharSequence text = node.getText(), description = node.getContentDescription();
            if (text != null && text.length() > 0) fields.add(new OfferRegion.Text(text.toString(), r.left, r.top, r.right, r.bottom));
            if (description != null && description.length() > 0 && (text == null || !description.toString().contentEquals(text)))
                fields.add(new OfferRegion.Text(description.toString(), r.left, r.top, r.right, r.bottom));
        }
        for (int i=0; i<node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) scanPositions(child, fields);
        }
    }

    private Decision.Result action(Candidate c) {
        return StoreRule.result(c.store, getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getStringSet(MainActivity.ALLOWED_STORES, MainActivity.defaultAllowed()), c.decision);
    }
    private String signature(Candidate c) { return c.store + "/" + c.decision.pay + "/" + c.decision.miles; }
    private String describe(Candidate c) {
        Decision d = c.decision;
        if (c.store == null) return "SKIP: store number missing or conflicting; $" + d.pay + " / " + d.miles + " mi";
        boolean allowed = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getStringSet(MainActivity.ALLOWED_STORES, MainActivity.defaultAllowed()).contains(c.store);
        return action(c) + " #" + c.store + " $" + d.pay + " / " + d.miles + " mi / $" + d.perMile + "/mi"
                + (allowed ? " — " + d.explanation : " — store switched off or unlisted");
    }

    private void record(String value) {
        if (!value.equals(getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.LAST, "")))
            getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit().putString(MainActivity.LAST, value).apply();
    }

    private void recordDiagnostic(String value) {
        if (!value.equals(getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.LAST_DIAGNOSTIC, "")))
            getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit().putString(MainActivity.LAST_DIAGNOSTIC, value).apply();
    }

    private void scan(AccessibilityNodeInfo node, List<String> fields,
                      List<AccessibilityNodeInfo> reject, List<AccessibilityNodeInfo> accept,
                      List<AccessibilityNodeInfo> confirm, List<AccessibilityNodeInfo> keep) {
        CharSequence text = node.getText(), description = node.getContentDescription();
        if (text != null && text.length() > 0) fields.add(text.toString());
        if (description != null && description.length() > 0 && (text == null || !description.toString().contentEquals(text))) fields.add(description.toString());
        String label = text != null ? text.toString().trim() : description != null ? description.toString().trim() : "";
        String normalized = label.toLowerCase(Locale.US).replaceAll("\\s+", " ");
        List<AccessibilityNodeInfo> buttons = null;
        if (normalized.matches("reject|decline")) buttons = reject;
        else if (normalized.equals("accept")) buttons = accept;
        else if (normalized.equals("reject offer")) buttons = confirm;
        else if (normalized.equals("keep offer")) buttons = keep;
        if (buttons != null && node.isEnabled()) {
            AccessibilityNodeInfo clickable = node;
            for (int i = 0; i < 2 && clickable != null && !clickable.isClickable(); i++) clickable = clickable.getParent();
            if (clickable != null && clickable.isClickable() && !buttons.contains(clickable)) buttons.add(clickable);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) scan(child, fields, reject, accept, confirm, keep);
        }
    }
    @Override public void onInterrupt() { handler.removeCallbacksAndMessages(null); busy = false; }
}
