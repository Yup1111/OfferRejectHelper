package com.local.sparkreject;

import java.util.Locale;

/** Pure checks shared by the accessibility adapter and regression fixtures. */
public final class ScanEvidence {
    public static boolean newOffersBanner(String text) {
        if (text == null) return false;
        return text.toLowerCase(Locale.US).trim().replace("(s)", "s")
                .replaceAll("\\s+", " ").matches("you have new offers? available[.!]?");
    }
    public static boolean bottom(int listTop, int listBottom, int cardTop, int cardBottom,
            int margin, boolean totalVisible, boolean buttonsVisible, int[][] regions) {
        if (!totalVisible || !buttonsVisible || cardBottom <= cardTop
                || cardTop < listTop || cardBottom > listBottom - margin) return false;
        for (int[] region : regions) {
            // Even a partially visible, unparsed card below the candidate disproves bottom.
            if (region[1] > listTop && region[0] < listBottom
                    && region[1] > cardBottom) return false;
        }
        return true;
    }
    public static String recovery(long now, boolean gesture, long gestureStart,
            boolean capture, long captureStart, boolean scheduled, long due, long lastCheck) {
        if (gesture && now - gestureStart >= 4000L) return "gesture";
        if (capture && now - captureStart >= 4000L) return "capture";
        if (gesture || capture) return "none";
        if ((!scheduled && now - lastCheck >= 3000L) || (scheduled && now - due >= 1500L)) return "schedule";
        return "none";
    }
    public static final class RefreshGate {
        private boolean attempted;
        private long lastAttempt = -10000L;
        public void observe(boolean visible) { if (!visible) attempted = false; }
        public boolean canAttempt(long now) { return !attempted && now - lastAttempt >= 5000L; }
        public void attempted(long now) { attempted = true; lastAttempt = now; }
    }
}
