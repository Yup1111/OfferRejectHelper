package com.local.sparkreject;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public final class StoreRule {
    private static final Pattern STORE = Pattern.compile("(?i)\\b(?:walmart|sam['’]?s(?:\\s+club)?)\\b[^#\\r\\n]{0,100}#\\s*([0-9]{1,5})(?![0-9])");
    private static final Pattern NAME = Pattern.compile("(?i)^(?:walmart|sam['’]?s(?:\\s+club)?)\\b[^#\\r\\n]{0,100}$");
    public static String identify(List<String> fields) {
        Set<String> ids = new HashSet<>();
        for (int i=0; i<fields.size(); i++) {
            String value = fields.get(i).trim();
            Matcher m = STORE.matcher(value);
            while (m.find()) ids.add(Integer.toString(Integer.parseInt(m.group(1))));
            if (NAME.matcher(value).matches() && i+1 < fields.size() && fields.get(i+1).trim().matches("#\\s*[0-9]{1,5}")) {
                ids.add(Integer.toString(Integer.parseInt(fields.get(i+1).replaceAll("[^0-9]", ""))));
            }
        }
        return ids.size()==1 ? ids.iterator().next() : null;
    }
    public static Decision.Result result(String store, Set<String> rejected, Decision decision) {
        if (decision == null || decision.result == Decision.Result.UNKNOWN) return Decision.Result.UNKNOWN;
        if (store != null && rejected.contains(store)) return Decision.Result.REJECT;
        return decision.result;
    }
}
