#!/usr/bin/env bash
set -euo pipefail

# Requires JDK 17 and Android SDK Platform/Build Tools 35.
sdk="${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK path}"
tools="$sdk/build-tools/35.0.0"
android_jar="$sdk/platforms/android-35/android.jar"
project="$(cd "$(dirname "$0")" && pwd)"
work="$project/manual-build"
mkdir -p "$work/res" "$work/gen" "$work/classes" "$work/dex" "$work/output"

"$tools/aapt2" compile --dir "$project/app/src/main/res" -o "$work/res/compiled.zip"
"$tools/aapt2" link -o "$work/output/unsigned-unaligned.apk" \
  -I "$android_jar" --manifest "$project/app/src/main/AndroidManifest.xml" \
  --java "$work/gen" --min-sdk-version 26 --target-sdk-version 35 \
  --version-code 10 --version-name 1.0-diagnostic \
  "$work/res/compiled.zip"
find "$project/app/src/main/java" "$work/gen" -name '*.java' -print0 | \
  xargs -0 javac -source 17 -target 17 -classpath "$android_jar" -d "$work/classes"
(cd "$work/classes" && jar cf "$work/classes.jar" .)
"$tools/d8" --lib "$android_jar" --min-api 26 --output "$work/dex" "$work/classes.jar"
(cd "$work/dex" && zip -q "$work/output/unsigned-unaligned.apk" classes.dex)
"$tools/zipalign" -f 4 "$work/output/unsigned-unaligned.apk" "$work/output/unsigned.apk"
if [[ ! -f "$work/local-debug.p12" ]]; then
  keytool -genkeypair -keystore "$work/local-debug.p12" -storetype PKCS12 \
    -alias localdebug -storepass changeit -keypass changeit -keyalg RSA -keysize 3072 \
    -validity 3650 -dname 'CN=Local Debug Build' >/dev/null 2>&1
fi
"$tools/apksigner" sign --ks "$work/local-debug.p12" --ks-key-alias localdebug \
  --ks-pass pass:changeit --key-pass pass:changeit \
  --out "$work/output/OfferRejectHelper.apk" "$work/output/unsigned.apk"
"$tools/apksigner" verify "$work/output/OfferRejectHelper.apk"
echo "$work/output/OfferRejectHelper.apk"
