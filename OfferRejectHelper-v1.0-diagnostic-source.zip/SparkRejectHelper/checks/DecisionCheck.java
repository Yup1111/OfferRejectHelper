import com.local.sparkreject.Decision;
import java.math.BigDecimal;
import java.util.List;

public final class DecisionCheck {
    private static void check(Decision.Result expected, String... fields) {
        Decision actual = Decision.evaluate(List.of(fields), new BigDecimal("2.00"));
        if (actual.result != expected) throw new AssertionError(expected + " but got " + actual.result + ": " + actual.explanation);
    }
    public static void main(String[] args) {
        check(Decision.Result.REJECT, "Estimated earnings", "$15.00", "Trip distance", "10 mi", "Reject");
        check(Decision.Result.KEEP, "Estimated earnings $22.00", "Total distance 11 miles");
        check(Decision.Result.UNKNOWN, "$15.00", "10 mi", "Reject");
        check(Decision.Result.UNKNOWN, "Estimated earnings $15.00", "Tip $3.00", "Trip distance 10 mi", "Trip distance 12 mi");
        check(Decision.Result.UNKNOWN, "Estimated earnings $15.00", "Trip distance 0 mi");
        check(Decision.Result.REJECT, "$37.88", "Total includes", "$8.67 estimated tip", "9 stops · 26.3 miles · 1hr, 24 mins", "40–50 lb item", "Apartment", "REJECT", "ACCEPT");
        check(Decision.Result.UNKNOWN, "$37.88", "$20.00", "9 stops · 26.3 miles · 1hr, 24 mins", "REJECT", "ACCEPT");
        check(Decision.Result.REJECT, "$9.00", "2 stops • 4.6 miles • 32 mins", "REJECT", "ACCEPT");
        check(Decision.Result.REJECT, "$9.00", "2 stops", "4.6 miles", "32 mins");
        check(Decision.Result.KEEP, "$24.71", "2 stops", "5 miles");
        check(Decision.Result.UNKNOWN, "$9.00", "$24.71", "2 stops", "4.6 miles", "5 miles");
        check(Decision.Result.UNKNOWN, "$9.00", "2 stops", "4.6 miles", "5 miles");
        check(Decision.Result.KEEP, "$23.41", "$10 estimated tip", "3 stops", "• 10.5 miles • 40 mins");
        check(Decision.Result.REJECT, "$19.00", "3 stops", "• 10.5 miles • 40 mins");
        check(Decision.Result.UNKNOWN, "$23.41", "3 stops", "• 10.5 miles • 40 mins", "Pickup 2 miles away");
        check(Decision.Result.UNKNOWN, "$23.41", "3 stops", "Trip distance 10.5 miles", "Other distance 12 miles");
        Decision sample = Decision.evaluate(List.of("$23.41", "$10 estimated tip", "3 stops", "• 10.5 miles • 40 mins"), new BigDecimal("2"));
        if (!new BigDecimal("10.5").equals(sample.miles) || !new BigDecimal("2.23").equals(sample.perMile)) throw new AssertionError("Incorrect mileage/rate");
        // Regression: report showed 5 list miles becoming 0.1 in details.
        Decision detail = Decision.evaluate(List.of("Estimated pay $18.74", "Trip distance 0.1 mi"), new BigDecimal("2"));
        Decision guarded = Decision.verifyDetail(detail, new BigDecimal("18.74"), new BigDecimal("5"), true);
        if (guarded.result != Decision.Result.UNKNOWN || guarded.miles != null || guarded.perMile != null)
            throw new AssertionError("Conflicting detail mileage must not produce a rating");
        Decision matching = Decision.evaluate(List.of("Estimated pay $18.74", "Trip distance 5 mi"), new BigDecimal("2"));
        if (Decision.verifyDetail(matching, new BigDecimal("18.740"), new BigDecimal("5.0"), true).result != Decision.Result.KEEP)
            throw new AssertionError("Verified matching offer should retain its rating");
        if (Decision.verifyDetail(matching, new BigDecimal("18.74"), new BigDecimal("5"), false).result != Decision.Result.UNKNOWN)
            throw new AssertionError("Stale or mismatched store context must not validate details");
        if (Decision.verifyDetail(matching, new BigDecimal("19.74"), new BigDecimal("5"), true).result != Decision.Result.UNKNOWN)
            throw new AssertionError("Changed pay needs fresh verification");
        if (Decision.verifyDetail(matching, null, null, true).result != Decision.Result.UNKNOWN)
            throw new AssertionError("Missing list reference must require review");
        System.out.println("Decision checks passed, including detail mileage regression");
    }
}
