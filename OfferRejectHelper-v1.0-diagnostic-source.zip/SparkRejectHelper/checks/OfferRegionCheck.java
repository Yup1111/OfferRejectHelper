import com.local.sparkreject.OfferRegion;
import com.local.sparkreject.Decision;
import java.math.BigDecimal;
import java.util.List;
public final class OfferRegionCheck {
    static OfferRegion.Text t(String value, int top, int bottom) { return new OfferRegion.Text(value, 20, top, 500, bottom); }
    static void check(Decision.Result result, String pay, List<OfferRegion.Text> fields, int top, int bottom) {
        Decision d = Decision.evaluate(OfferRegion.select(fields, 0, top, 700, bottom), new BigDecimal("2"));
        if (d.result != result || (pay != null && !new BigDecimal(pay).equals(d.pay))) throw new AssertionError(d.result+" "+d.pay);
    }
    public static void main(String[] args) {
        List<OfferRegion.Text> cards = List.of(t("$22.00",200,250), t("2 stops • 15.1 miles",300,340),
            t("$22.41",700,750),t("2 stops • 9.2 miles",800,840),
            t("$22.00 $22.41 15.1 miles 9.2 miles",100,1000));
        check(Decision.Result.REJECT,"22.00",cards,0,600);
        check(Decision.Result.KEEP,"22.41",cards,650,1000);
        check(Decision.Result.UNKNOWN,null,cards,0,1000);
        check(Decision.Result.UNKNOWN,null,cards,260,600); // clipped/missing total
        check(Decision.Result.UNKNOWN,null,List.of(t("$22.00",200,250),t("$22.41",260,280),t("2 stops • 15.1 miles",300,340)),0,600);
        System.out.println("Offer region checks passed");
    }
}
