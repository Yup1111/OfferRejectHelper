import com.local.sparkreject.ScanEvidence;
public final class ScanEvidenceCheck {
    private static void require(boolean value, String message) { if (!value) throw new AssertionError(message); }
    public static void main(String[] args) {
        require(ScanEvidence.newOffersBanner("You have new offer(s) available."), "Observed banner");
        require(ScanEvidence.newOffersBanner("You have new offers available"), "Plural banner");
        require(!ScanEvidence.newOffersBanner("Offer unavailable"), "Different popup");
        require(!ScanEvidence.newOffersBanner("Refresh your account"), "Unrelated refresh");
        ScanEvidence.RefreshGate gate = new ScanEvidence.RefreshGate();
        require(gate.canAttempt(100), "First attempt"); gate.attempted(100);
        require(!gate.canAttempt(9000), "Persistent banner must not get repeated taps");
        gate.observe(false); require(!gate.canAttempt(3000), "Cooldown on quick reappearance");
        require(gate.canAttempt(6000), "New banner after cooldown");
        // Reported screen: earlier readable card ends at 1526, next body reaches 2340.
        require(!ScanEvidence.bottom(578,2340,578,1550,30,true,true,
                new int[][]{{578,1363},{1642,2340}}), "Clipped following offer disproves bottom");
        require(ScanEvidence.bottom(505,2340,779,2100,30,true,true,
                new int[][]{{779,1903},{779,1224}}), "One full offer with bottom space");
        require(!ScanEvidence.bottom(505,2340,779,2340,30,true,true,
                new int[][]{{779,2340}}), "No bottom padding");
        require(!ScanEvidence.bottom(505,2340,505,2000,30,false,true,
                new int[][]{{505,1900}}), "Clipped pay header is not a full card");
        require(!ScanEvidence.bottom(505,2340,779,2100,30,true,false,
                new int[][]{{779,1903}}), "Buttons missing");
        require(ScanEvidence.recovery(5000,true,1000,false,0,false,0,0).equals("gesture"), "Missing gesture callback");
        require(ScanEvidence.recovery(4999,true,1000,false,0,false,0,0).equals("none"), "Do not interrupt pending gesture");
        require(ScanEvidence.recovery(5000,false,0,true,1000,false,0,0).equals("capture"), "Missing screenshot callback");
        require(ScanEvidence.recovery(5000,false,0,false,0,true,30000,1000).equals("none"), "Respect deliberate backoff");
        require(ScanEvidence.recovery(5000,false,0,false,0,false,0,1000).equals("schedule"), "Recover lost next check");
        require(ScanEvidence.recovery(5000,false,0,false,0,true,3400,1000).equals("schedule"), "Recover overdue check");
        require(ScanEvidence.recovery(5000,false,0,false,0,false,0,4500).equals("none"), "Recent check needs no recovery");
        System.out.println("Refresh, partial-card bottom, and recovery timing checks passed");
    }
}
