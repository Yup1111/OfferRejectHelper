import com.local.sparkreject.StoreRule;
import com.local.sparkreject.Decision;
import java.util.List;
import java.util.Set;
import java.math.BigDecimal;
public final class StoreRuleCheck {
    static void identify(String expected, String... fields) {
        String actual=StoreRule.identify(List.of(fields));
        if (!java.util.Objects.equals(expected,actual)) throw new AssertionError(expected+" != "+actual);
    }
    static void rule(Decision.Result expected, String store, Set<String> rejected, String pay) {
        Decision d=Decision.evaluate(List.of(pay,"2 stops • 10 miles"),new BigDecimal("2"));
        if(StoreRule.result(store,rejected,d)!=expected) throw new AssertionError("Wrong store rule");
    }
    public static void main(String[] args) {
        identify("3726","Walmart GRAND BLANC #3726");
        identify("2273","Walmart BURTON #2273");
        identify("3726","Walmart GRAND BLANC", "#3726");
        identify("3726","Walmart GRAND BLANC #03726", "Walmart GRAND BLANC #3726");
        identify("1234","Sam’s Club #1234");
        identify(null,"Walmart GRAND BLANC #3726","Walmart BURTON #2273");
        identify(null,"Apartment #3726");
        identify(null,"Grand Blanc", "$23.41");
        rule(Decision.Result.REJECT,"3726",Set.of("3726"),"$100.00");
        rule(Decision.Result.KEEP,"3726",Set.of(),"$100.00");
        rule(Decision.Result.REJECT,"2273",Set.of("2273"),"$100.00");
        rule(Decision.Result.KEEP,"2273",Set.of("3726"),"$100.00");
        rule(Decision.Result.REJECT,"2273",Set.of("3726"),"$19.00");
        rule(Decision.Result.KEEP,null,Set.of("3726"),"$100.00");
        rule(Decision.Result.UNKNOWN,"2273",Set.of("3726"),"unreadable");
        System.out.println("Store rule checks passed");
    }
}
